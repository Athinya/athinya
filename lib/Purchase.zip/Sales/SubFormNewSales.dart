import 'package:product_restaurantapp/Settings/StaffDetails.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:product_restaurantapp/Database/IpAddress.dart';
import 'package:product_restaurantapp/Modules/Responsive.dart';
import 'package:product_restaurantapp/Modules/Style.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';
import 'package:product_restaurantapp/Sales/NewSales.dart';
import 'package:product_restaurantapp/Settings/AddProductsDetails.dart';
import 'package:product_restaurantapp/Settings/GstDetails.dart';
import 'package:shared_preferences/shared_preferences.dart';

TextEditingController FinallyyyAmounttts = TextEditingController();

class salestableview extends StatefulWidget {
  final TextEditingController ProductSalesTypeController;
  final List<Map<String, dynamic>> SALEStabledata;
  final TextEditingController BillNOreset;
  final TextEditingController tableno;

  final TextEditingController customername;

  final TextEditingController customercontact;

  final TextEditingController scode;

  final TextEditingController sname;

  final TextEditingController paytype;

  final Function(TextEditingController) onFinalAmountButtonPressed;

  final FocusNode codeFocusNode;

  salestableview({
    required this.ProductSalesTypeController,
    required this.BillNOreset,
    required this.tableno,
    required this.customername,
    required this.customercontact,
    required this.scode,
    required this.sname,
    required this.paytype,
    required this.SALEStabledata,
    required this.onFinalAmountButtonPressed,
    required this.codeFocusNode,
  });

  @override
  State<salestableview> createState() => _salestableviewState();
  // Widget finalamtRS() {
  //   return _salestableviewState().finalamtRS();
  // }
}

class _salestableviewState extends State<salestableview> {
  String? selectItem;

  TextEditingController ProductCodeController = TextEditingController();
  TextEditingController ProductNameController = TextEditingController();
  TextEditingController ProductAmountController = TextEditingController();
  TextEditingController QuantityController = TextEditingController();
  TextEditingController TotalAmtController = TextEditingController();
  TextEditingController ProductMakingCostController = TextEditingController();

  TextEditingController CGSTperccontroller = TextEditingController();
  TextEditingController SGSTPercController = TextEditingController();
  TextEditingController CGSTAmtController = TextEditingController();
  TextEditingController SGSTAmtController = TextEditingController();
  TextEditingController FinalAmtController = TextEditingController();

  TextEditingController Taxableamountcontroller = TextEditingController();
  TextEditingController SalesGstMethodController = TextEditingController();
  TextEditingController ProductCategoryController = TextEditingController();

  late List<Map<String, dynamic>> tableData;
  double totalAmount = 0.0;

  // FocusNode codeFocusNode = FocusNode();
  FocusNode itemFocusNode = FocusNode();
  FocusNode amountFocusNode = FocusNode();
  FocusNode quantityFocusNode = FocusNode();
  FocusNode finaltotalFocusNode = FocusNode();
  FocusNode addbuttonFocusNode = FocusNode();

  FocusNode discountpercFocusNode = FocusNode();
  FocusNode discountAmtFocusNode = FocusNode();
  FocusNode FinalAmtFocusNode = FocusNode();
  FocusNode SavebuttonFocusNode = FocusNode();

  void _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  @override
  void initState() {
    super.initState();
    fetchProductNameList();
    fetchGSTMethod();
    tableData = widget.SALEStabledata;
    TotalAmtController.text = "0";
    QuantityController.text = "0";
    ProductAmountController.text = "0";
    SalesDisPercentageController.text = "0";
    FinalAmtController.text = "0";
    SalesDisAMountController.text = "0";
    FinallllAmttControllerrrr.addListener(() {
      double someAmount =
          double.tryParse(FinallllAmttControllerrrr.text) ?? 0.0;
      calFinaltotalAmount(someAmount);
    });
  }

  @override
  void dispose() {
    // codeFocusNode.dispose();
    itemFocusNode.dispose();
    amountFocusNode.dispose();
    quantityFocusNode.dispose();
    finaltotalFocusNode.dispose();
    addbuttonFocusNode.dispose();
    discountpercFocusNode.dispose();
    discountAmtFocusNode.dispose();
    FinalAmtFocusNode.dispose();
    SavebuttonFocusNode.dispose();
    FinallllAmttControllerrrr.dispose();
    FinallllAmttNotifierrrrrrr.dispose();
    super.dispose();
  }

  List<String> ProductNameList = [];

  Future<void> fetchProductNameList() async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String url = '$IpAddress/Settings_ProductDetails/$cusid/';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          ProductNameList.addAll(
              results.map<String>((item) => item['name'].toString()));
          // print("payment List : $ProductNameList");

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
        } else {
          throw Exception(
              'Failed to load categories: ${response.reasonPhrase}');
        }
      }

      // print('All product categories: $ProductNameList');
    } catch (e) {
      print('Error fetching categories: $e');
      rethrow; // Rethrow the error to propagate it further
    }
  }

  String? ProductNameSelected;

  int? _selectedProductnameIndex;

  bool _isProductnameOptionsVisible = false;
  int? _ProductnamehoveredIndex;
  Widget _buildProductnameDropdown() {
    return Padding(
      padding: const EdgeInsets.only(top: 3.0),
      child: Row(
        children: [
          Icon(
            Icons.person,
            size: 15,
          ),
          SizedBox(width: 3),
          Container(
            // width: 120,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    color: Colors.grey[100],
                    height: 23,
                    width: Responsive.isDesktop(context)
                        ? MediaQuery.of(context).size.width * 0.095
                        : MediaQuery.of(context).size.width * 0.25,
                    child: ProductnameDropdown()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: InkWell(
              onTap: () {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    return Dialog(
                      child: Container(
                        width: 1350,
                        height: 800,
                        padding: EdgeInsets.all(16),
                        child: Stack(
                          children: [
                            AddProductDetailsPage(),
                            Positioned(
                              right: 0.0,
                              top: 0.0,
                              child: IconButton(
                                icon: Icon(Icons.cancel,
                                    color: Colors.red, size: 23),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                  fetchproductName();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
              child: Container(
                decoration: BoxDecoration(color: subcolor),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 6, right: 6, top: 2, bottom: 2),
                  child: Text(
                    "+",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget ProductnameDropdown() {
    return RawKeyboardListener(
      focusNode: FocusNode(),
      onKey: (RawKeyEvent event) {
        if (event is RawKeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
            // Handle arrow down event
            int currentIndex =
                ProductNameList.indexOf(ProductNameController.text);
            if (currentIndex < ProductNameList.length - 1) {
              setState(() {
                _selectedProductnameIndex = currentIndex + 1;
                ProductNameController.text = ProductNameList[currentIndex + 1];
                _isProductnameOptionsVisible = false;
              });
            }
          } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
            // Handle arrow up event
            int currentIndex =
                ProductNameList.indexOf(ProductNameController.text);
            if (currentIndex > 0) {
              setState(() {
                _selectedProductnameIndex = currentIndex - 1;
                ProductNameController.text = ProductNameList[currentIndex - 1];
                _isProductnameOptionsVisible = false;
              });
            }
          } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
            FocusScope.of(context).requestFocus(widget.codeFocusNode);
          }
        }
      },
      child: TypeAheadFormField<String>(
        textFieldConfiguration: TextFieldConfiguration(
          focusNode: itemFocusNode,
          onSubmitted: (String? suggestion) async {
            // if (isProductAlreadyExists(ProductNameSelected!)) {
            //   ProductNameSelected = '';
            //   _fieldFocusChange(context, itemFocusNode, codeFocusNode);
            //   productalreadyexist();
            // } else {

            widget.ProductSalesTypeController.text;
            await fetchproductcode();
            updateTotal();
            updatetaxableamount();
            updateCGSTAmount();
            updateSGSTAmount();
            updateFinalAmount();
            _fieldFocusChange(context, itemFocusNode, quantityFocusNode);
          },
          controller: ProductNameController,
          decoration: const InputDecoration(
            border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 1.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black, width: 1.0),
            ),
            contentPadding: EdgeInsets.only(bottom: 10, left: 5),
            labelStyle: DropdownTextStyle,
            suffixIcon: Icon(
              Icons.keyboard_arrow_down,
              size: 18,
            ),
          ),
          style: DropdownTextStyle,
          onChanged: (text) async {
            setState(() {
              _isProductnameOptionsVisible = true;
              ProductNameSelected = text.isEmpty ? null : text;
            });
          },
        ),
        suggestionsCallback: (pattern) {
          if (_isProductnameOptionsVisible && pattern.isNotEmpty) {
            return ProductNameList.where(
                (item) => item.toLowerCase().contains(pattern.toLowerCase()));
          } else {
            return ProductNameList;
          }
        },
        itemBuilder: (context, suggestion) {
          final index = ProductNameList.indexOf(suggestion);
          return MouseRegion(
            onEnter: (_) => setState(() {
              _ProductnamehoveredIndex = index;
            }),
            onExit: (_) => setState(() {
              _ProductnamehoveredIndex = null;
            }),
            child: Container(
              color: _selectedProductnameIndex == index
                  ? Colors.grey.withOpacity(0.3)
                  : _selectedProductnameIndex == null &&
                          ProductNameList.indexOf(ProductNameController.text) ==
                              index
                      ? Colors.grey.withOpacity(0.1)
                      : Colors.transparent,
              height: 28,
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10.0,
                ),
                dense: true,
                title: Padding(
                  padding: const EdgeInsets.only(bottom: 5.0),
                  child: Text(
                    suggestion,
                    style: DropdownTextStyle,
                  ),
                ),
              ),
            ),
          );
        },
        suggestionsBoxDecoration: const SuggestionsBoxDecoration(
          constraints: BoxConstraints(maxHeight: 150),
        ),
        onSuggestionSelected: (String? suggestion) async {
          setState(() {
            // if (isProductAlreadyExists(ProductNameSelected!)) {
            //   ProductNameSelected = '';
            //   _fieldFocusChange(context, itemFocusNode, codeFocusNode);
            //   productalreadyexist();
            // } else {

            widget.ProductSalesTypeController.text;
            fetchproductcode();
            updateTotal();
            updatetaxableamount();
            updateCGSTAmount();
            updateSGSTAmount();
            updateFinalAmount();
            ProductNameController.text = suggestion!;
            ProductNameSelected = suggestion;
            _isProductnameOptionsVisible = false;

            FocusScope.of(context).requestFocus(quantityFocusNode);
          });
        },
        noItemsFoundBuilder: (context) => Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            'No Items Found!!!',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),
      ),
    );
  }

  bool isProductAlreadyExists(String productName) {
    // Assuming table data is stored in a List<Map<String, dynamic>> called tableData
    for (var item in tableData) {
      if (item['productName'] == productName) {
        return true;
      }
    }
    return false;
  }

  void productalreadyexist() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.yellow,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.warning, color: maincolor),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'This product is already in the table data.',
                style: TextStyle(fontSize: 12, color: maincolor),
              ),
            ],
          ),
        );
      },
    );

    // Close the dialog automatically after 2 seconds
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pop();
    });
  }

  Future<void> fetchproductName() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/Settings_ProductDetails/$cusid/';
    String ProductCode =
        ProductCodeController.text.toLowerCase(); // Convert to lowercase
    bool contactFound = false;
    // print("ProductCodeController Name: $ProductCode");

    String salestype = widget.ProductSalesTypeController.text;

    try {
      String url = baseUrl;

      while (!contactFound) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          // Iterate through each customer entry
          for (var entry in results) {
            if (entry['code'].toString().toLowerCase() == ProductCode) {
              // Convert to lowercase
              // Retrieve the contact number and address for the customer
              String amount = '';
              if (salestype == 'DineIn') {
                amount = entry['amount'];
              } else if (salestype == 'TakeAway') {
                amount = entry['wholeamount'];
              }
              String name = entry['name'];
              String agentId = entry['id'].toString();
              String makingcost = entry['makingcost'];
              String category = entry['category'];

              String cgstperc = entry['cgstper'];
              String sgstperc = entry['sgstper'];

              if (ProductCode.isNotEmpty) {
                ProductNameController.text = name;
                ProductAmountController.text = amount;
                ProductMakingCostController.text = makingcost;
                ProductCategoryController.text = category;
                CGSTperccontroller.text = cgstperc;
                SGSTPercController.text = sgstperc;

                contactFound = true;
                break; // Exit the loop once the contact number is found
              }
            }
          }

          // print("CGst Percentages:${CGSTperccontroller.text}");
          // print("Sgst Percentages:${SGSTPercController.text}");
          // Check if there are more pages
          if (!contactFound && data['next'] != null) {
            url = data['next'];
          } else {
            // Exit the loop if no more pages or contact number found
            break;
          }
        } else {
          throw Exception(
              'Failed to load customer contact information: ${response.reasonPhrase}');
        }
      }

      // Print a message if contact number not found
      if (!contactFound) {}
    } catch (e) {
      print('Error fetching customer contact information: $e');
    }
  }

  Future<void> fetchproductcode() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/Settings_ProductDetails/$cusid/';
    String productName =
        ProductNameController.text.toLowerCase(); // Convert to lowercase
    bool contactFound = false;
    // print("ProductNameController Name: $productName");
    String salestype = widget.ProductSalesTypeController.text;

    try {
      String url = baseUrl;

      while (!contactFound) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          // Iterate through each product entry
          for (var entry in results) {
            if (entry['name'].toString().toLowerCase() == productName) {
              // Convert to lowercase
              // Retrieve the code and id for the product
              String code = entry['code'];
              String agentId = entry['id'].toString();

              // Determine the amount based on the salestype
              String amount = '';
              if (salestype == 'DineIn') {
                amount = entry['amount'];
              } else if (salestype == 'TakeAway') {
                amount = entry['wholeamount'];
              }

              String makingcost = entry['makingcost'];
              String category = entry['category'];
              String cgstperc = entry['cgstper'];
              String sgstperc = entry['sgstper'];

              if (productName.isNotEmpty) {
                ProductCodeController.text = code;
                CGSTperccontroller.text = cgstperc;
                ProductMakingCostController.text = makingcost;
                ProductCategoryController.text = category;

                SGSTPercController.text = sgstperc;
                ProductAmountController.text = amount;

                contactFound = true;
                break; // Exit the loop once the product information is found
              }
            }
          }

          // Check if there are more pages
          if (!contactFound && data['next'] != null) {
            url = data['next'];
          } else {
            // Exit the loop if no more pages or product information found
            break;
          }
        } else {
          throw Exception(
              'Failed to load product information: ${response.reasonPhrase}');
        }
      }

      // Print a message if product information not found
      if (!contactFound) {
        // print("No product information found for $productName");
      }
    } catch (e) {
      print('Error fetching product information: $e');
    }
  }

  Future<void> fetchGSTMethod() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/GstDetails/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var jsonData = json.decode(response.body);

    String gstMethod = ''; // Initialize GST method to empty string

    // Iterate through each entry in the JSON data
    for (var entry in jsonData) {
      // Check if the name is "Sales"
      if (entry['name'] == "Sales") {
        // Retrieve the GST method for "Sales"
        gstMethod = entry['gst'];
        break; // Exit the loop once the entry is found
      }
    }

    // Update rateController if needed
    if (gstMethod.isNotEmpty) {
      SalesGstMethodController.text = gstMethod;
      // print("GST method for Sales: ${SalesGstMethodController.text}");
      // print("GST method for Sales: $gstMethod");
    } else {
      print("No GST method found for Sales");
    }
  }

  void updateCGSTAmount() {
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double cgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double numerator = (taxableAmount * cgstPercentage);
    // Calculate the CGST amount
    double cgstAmount = numerator / 100;

    // Update the CGST amount controller
    CGSTAmtController.text = cgstAmount.toStringAsFixed(2);
    // print("CGST amont = ${CGSTAmtController.text}");
  }

  void updateSGSTAmount() {
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double sgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double numerator = (taxableAmount * sgstPercentage);
    // Calculate the CGST amount
    double sgstAmount = numerator / 100;

    // Update the CGST amount controller
    SGSTAmtController.text = sgstAmount.toStringAsFixed(2);
    // print("SGZGST amont = ${SGSTAmtController.text}");
  }

  void updateTotal() {
    double rate = double.tryParse(ProductAmountController.text) ?? 0;
    double quantity = double.tryParse(QuantityController.text) ?? 0;
    double total = rate * quantity;
    TotalAmtController.text =
        total.toStringAsFixed(2); // Format total to 2 decimal places
    // Taxableamountcontroller.text = total.toStringAsFixed(2);
  }

  void updatetaxableamount() {
    double total = double.tryParse(TotalAmtController.text) ?? 0;
    double cgstAmount = double.tryParse(CGSTAmtController.text) ?? 0;
    double sgstAmount = double.tryParse(SGSTAmtController.text) ?? 0;
    double cgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double sgstPercentage = double.tryParse(SGSTPercController.text) ?? 0;

    double numeratorPart1 = total;

    if (SalesGstMethodController.text == "Excluding") {
      // Calculate taxable amount excluding GST
      double taxableAmount = numeratorPart1;
      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    } else if (SalesGstMethodController.text == "Including") {
      double cgstsgst = cgstPercentage + sgstPercentage;
      double cgstnumerator = numeratorPart1 * cgstPercentage;
      double cgstdenominator = 100 + cgstsgst;
      double cgsttaxable = cgstnumerator / cgstdenominator;
      double sgstnumerator = numeratorPart1 * sgstPercentage;
      double sgstdenominator = 100 + cgstsgst;
      double sgsttaxable = sgstnumerator / sgstdenominator;

      double taxableAmount = numeratorPart1 - (cgsttaxable + sgsttaxable);

      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("cgst taxable amount : $cgsttaxable");
      // print("sgst taxable amount : $sgsttaxable");
      // print("Total taxable amount : $taxableAmount");
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    } else {
      double taxableAmount = numeratorPart1;
      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    }
  }

  void updateFinalAmount() {
    double total = double.tryParse(TotalAmtController.text) ?? 0;

    double cgstAmount = double.tryParse(CGSTAmtController.text) ?? 0;
    double sgstAmount = double.tryParse(SGSTAmtController.text) ?? 0;
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double denominator = cgstAmount + sgstAmount;

    if (SalesGstMethodController.text == "Excluding") {
      double finalAmount = taxableAmount + denominator;
      // print("FIanl amount = ${taxableAmount} + ${denominator}");

      // Update the final amount controller
      FinalAmtController.text = finalAmount.toStringAsFixed(2);
      // print("FIanl amount = ${FinalAmtController.text}");
    } else if (SalesGstMethodController.text == "Including") {
      double totalfinalamount = total;
      FinalAmtController.text = totalfinalamount.toStringAsFixed(2);
    } else {
      double taxableAmount = total;
      FinalAmtController.text = taxableAmount.toStringAsFixed(2);
    }
  }

  int nextId = 1;
  bool updateenable = false;
  void saveData() {
    // Check if any required field is empty
    if (ProductCodeController.text.isEmpty ||
        ProductNameController.text.isEmpty ||
        ProductAmountController.text.isEmpty ||
        QuantityController.text.isEmpty ||
        FinalAmtController.text.isEmpty) {
      // Show error message
      WarninngMessage(context);
      return;
    } else if (QuantityController.text == '0' ||
        QuantityController.text == '') {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Quantity Check'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text('Kindly enter the quantity , Quantity must above 0'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(quantityFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else if (widget.paytype.text.toLowerCase() == 'credit' &&
        widget.customername.text.isEmpty) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Check Details'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text(
                'Kindly enter the Customer Details , when you select Paytype Credit'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(widget.codeFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else {
      String productCode = ProductCodeController.text;

      String productName = ProductNameController.text;
      String amount = ProductAmountController.text;
      String quantity = QuantityController.text;
      String makingcost = ProductMakingCostController.text;
      String category = ProductCategoryController.text;
      String totalamt = FinalAmtController.text;
      String taxable = Taxableamountcontroller.text;

      String cgstPercentage = SalesGstMethodController.text == "NonGst"
          ? '0'
          : CGSTperccontroller.text;
      String sgstPercentage = SalesGstMethodController.text == "NonGst"
          ? '0'
          : SGSTPercController.text;
      String cgstAmount = SalesGstMethodController.text == "NonGst"
          ? '0'
          : CGSTAmtController.text;
      String sgstAmount = SalesGstMethodController.text == "NonGst"
          ? '0'
          : SGSTAmtController.text;

      bool productExists = false;

      for (var item in tableData) {
        if (item['productName'] == productName) {
          item['quantity'] =
              (int.parse(item['quantity']) + int.parse(quantity)).toString();

          item['Amount'] =
              (double.parse(item['Amount']) + double.parse(totalamt))
                  .toString();
          item['retail'] =
              (double.parse(item['retail']) + double.parse(taxable)).toString();
          item['cgstAmt'] =
              (double.parse(item['cgstAmt']) + double.parse(cgstAmount))
                  .toString();
          item['sgstAmt'] =
              (double.parse(item['sgstAmt']) + double.parse(sgstAmount))
                  .toString();
          productExists = true;
          break;
        }
      }

      if (!productExists) {
        setState(() {
          tableData.add({
            'id': nextId++,
            'productCode': productCode,
            'productName': productName,
            'amount': amount,
            'quantity': quantity,
            "cgstAmt": cgstAmount,
            "sgstAmt": sgstAmount,
            "Amount": totalamt,
            "retail": taxable,
            "retailrate": amount,
            "cgstperc": cgstPercentage,
            "sgstperc": sgstPercentage,
            "makingcost": makingcost,
            "category": category,
          });
        });
      }

      setState(() {
        ProductCodeController.clear();
        ProductNameController.clear();
        ProductAmountController.clear();
        QuantityController.clear();
        FinalAmtController.clear();
        ProductNameSelected = '';
        updateenable = false;
      });
      updatefinaltabletotalAmount();
      processNewSalesEntry(context, FINALAMTCONTROLLWE);
    }
  }

  TextEditingController FinallllAmttControllerrrr = TextEditingController();
  final ValueNotifier<String> FinallllAmttNotifierrrrrrr =
      ValueNotifier<String>("0");

  void calFinaltotalAmount(double finalamountcontroller) {
    FinallllAmttNotifierrrrrrr.value = finalamountcontroller.toString();
    TextEditingController finalamtcontrollersimply =
        TextEditingController(text: finalamountcontroller.toString());

    // Pass the text value of the TextEditingController to the callback
    widget.onFinalAmountButtonPressed(finalamtcontrollersimply);

    // Print the updated value to the console
    print("finalamountttttttttt ${finalamtcontrollersimply.text}");
  }

  Widget finalamtRS() {
    return Padding(
      padding: const EdgeInsets.only(left: 0, top: 15),
      child: Container(
        width: Responsive.isDesktop(context)
            ? 580
            : MediaQuery.of(context).size.width * 0.75,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              height: 45,
              width: Responsive.isDesktop(context)
                  ? 260
                  : MediaQuery.of(context).size.width * 0.75,
              color: Color.fromARGB(255, 225, 225, 225),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        left: Responsive.isDesktop(context) ? 0 : 0, top: 0),
                    child: Container(
                      width: Responsive.isDesktop(context) ? 70 : 70,
                      height: 45,
                      child: ElevatedButton(
                        onPressed: () {
                          // Handle button action
                        },
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(2.0),
                          ),
                          backgroundColor: subcolor,
                          minimumSize: Size(45.0, 31.0),
                        ),
                        child: Text(
                          'RS. ',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: Responsive.isDesktop(context) ? 20 : 20, top: 11),
                    child: Container(
                      width: Responsive.isDesktop(context) ? 85 : 85,
                      child: ValueListenableBuilder<String>(
                        valueListenable: FinallllAmttNotifierrrrrrr,
                        builder: (context, value, child) {
                          return Container(
                            height: 24,
                            width: 100,
                            child: Text(
                              "${NumberFormat.currency(symbol: '', decimalDigits: 0).format(double.tryParse(value) ?? 0)} /-",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  TextEditingController UpdateidController = TextEditingController();

  void UpdateData() {
    // Check if any required field is empty
    if (ProductCodeController.text.isEmpty ||
        ProductNameController.text.isEmpty ||
        ProductAmountController.text.isEmpty ||
        QuantityController.text.isEmpty ||
        FinalAmtController.text.isEmpty ||
        UpdateidController.text.isEmpty) {
      // Show error message
      WarninngMessage(context);
      return;
    } else if (QuantityController.text == '0' ||
        QuantityController.text == '') {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Quantity Check'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text('Kindly enter the quantity, Quantity must be above 0'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(quantityFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else if (widget.paytype.text.toLowerCase() == 'credit' &&
        widget.customername.text.isEmpty) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Check Details'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text(
                'Kindly enter the Customer Details, when you select Paytype Credit'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(widget.codeFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else {
      String productCode = ProductCodeController.text;
      String productName = ProductNameController.text;
      String amount = ProductAmountController.text;
      String quantity = QuantityController.text;
      String makingcost = ProductMakingCostController.text;
      String category = ProductCategoryController.text;
      String totalamt = FinalAmtController.text;
      String taxable = Taxableamountcontroller.text;

      String cgstPercentage = SalesGstMethodController.text == "NonGst"
          ? '0'
          : CGSTperccontroller.text;
      String sgstPercentage = SalesGstMethodController.text == "NonGst"
          ? '0'
          : SGSTPercController.text;
      String cgstAmount = SalesGstMethodController.text == "NonGst"
          ? '0'
          : CGSTAmtController.text;
      String sgstAmount = SalesGstMethodController.text == "NonGst"
          ? '0'
          : SGSTAmtController.text;

      // Convert UpdateidController.text to integer
      int idToUpdate = int.tryParse(UpdateidController.text) ?? -1;

      if (idToUpdate == -1) {
        WarninngMessage(context); // Invalid ID
        return;
      }

      bool entryExists = false;
      setState(() {
        for (var entry in tableData) {
          if (entry['id'] == idToUpdate) {
            // Update the existing entry
            entry['productCode'] = productCode;
            entry['productName'] = productName;
            entry['amount'] = amount;
            entry['quantity'] = quantity;
            entry['cgstAmt'] = cgstAmount;
            entry['sgstAmt'] = sgstAmount;
            entry['Amount'] = totalamt;
            entry['retail'] = taxable;
            entry['retailrate'] = amount;
            entry['cgstperc'] = cgstPercentage;
            entry['sgstperc'] = sgstPercentage;
            entry['makingcost'] = makingcost;
            entry['category'] = category;
            entryExists = true;
            break;
          }
        }

        if (!entryExists) {
          WarninngMessage(context); // ID not found
        }
      });

      // Clear text fields
      setState(() {
        updateenable = false;
        ProductCodeController.clear();
        ProductNameController.clear();
        ProductAmountController.clear();
        QuantityController.clear();
        FinalAmtController.clear();
        ProductNameSelected = '';
      });

      updatefinaltabletotalAmount();
      processNewSalesEntry(context, FINALAMTCONTROLLWE);
    }
  }

  Widget tableView() {
    double screenHeight = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 0, top: 5),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
            // height: 200,
            height: Responsive.isDesktop(context) ? screenHeight * 0.55 : 320,
            // height: Responsive.isDesktop(context) ? 300 : 240,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Container(
                width: Responsive.isDesktop(context)
                    ? MediaQuery.of(context).size.width * 0.7
                    : MediaQuery.of(context).size.width * 1.8,
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 0.0, right: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.fastfood,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 1),
                                  Text("Item",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.attach_money,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Rate",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add_box,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Qty",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.local_atm,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Cgst ₹",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.local_atm,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Sgst ₹",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Center(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.currency_exchange_outlined,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text("Amount",
                                        textAlign: TextAlign.center,
                                        style: commonLabelTextStyle),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.currency_exchange_outlined,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Retail",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        // Container(
                        //   height: Responsive.isDesktop(context) ? 25 : 30,
                        //   width: 80,
                        //   decoration: TableHeaderColor,
                        //   child: Center(
                        //     child: Row(
                        //       mainAxisAlignment: MainAxisAlignment.start,
                        //       children: [
                        //         Icon(
                        //           Icons.currency_exchange_sharp,
                        //           size: 15,
                        //           color: Colors.blue,
                        //         ),
                        //         SizedBox(width: 5),
                        //         Text("RetailRate",
                        //             textAlign: TextAlign.center,
                        //             style: commonLabelTextStyle),
                        //       ],
                        //     ),
                        //   ),
                        // ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 365.0,
                            decoration: TableHeaderColor,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Center(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.pie_chart,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text("CGST %",
                                        textAlign: TextAlign.center,
                                        style: commonLabelTextStyle),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Center(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.pie_chart,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text("SGST %",
                                        textAlign: TextAlign.center,
                                        style: commonLabelTextStyle),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.delete,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Action",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // if (tableData.isNotEmpty)
                  //   ...tableData.map((data) {
                  if (tableData.isNotEmpty)
                    ...tableData.asMap().entries.map((entry) {
                      int index = entry.key;

                      Map<String, dynamic> data = entry.value;

                      var id = data['id'].toString();
                      var productCode = data['productCode'].toString();

                      var productName = data['productName'].toString();
                      var amount = data['amount'].toString();
                      var quantity = data['quantity'].toString();
                      var cgstAmt = data['cgstAmt'].toString();
                      var sgstAmt = data['sgstAmt'].toString();
                      var Amount = data['Amount'].toString();
                      var retail = data['retail'].toString();
                      var retailrate = data['retailrate'] ?? 0;

                      var cgstperc = data['cgstperc'].toString();
                      var sgstperc = data['sgstperc'] ?? 0;
                      var makingcost = data['makingcost'] ?? 0;
                      var category = data['category'].toString();
                      // print("categoryyy: $category");
                      bool isEvenRow = tableData.indexOf(data) % 2 == 0;
                      Color? rowColor = isEvenRow
                          ? Color.fromARGB(224, 255, 255, 255)
                          : Color.fromARGB(224, 255, 255, 255);

                      return Padding(
                        padding: const EdgeInsets.only(
                            left: 0.0, top: 3, bottom: 3, right: 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(productName,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(amount,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(quantity,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(cgstAmt,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(sgstAmt,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(Amount,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(retail,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            // Flexible(
                            //   child: Container(
                            //     height: 30,
                            //     width: 265.0,
                            //     decoration: BoxDecoration(
                            //       color: rowColor,
                            //       border: Border.all(
                            //         color: Color.fromARGB(255, 226, 225, 225),
                            //       ),
                            //     ),
                            //     child: Center(
                            //       child: Text(retailrate,
                            //           textAlign: TextAlign.center,
                            //           style: TableRowTextStyle),
                            //     ),
                            //   ),
                            // ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(cgstperc,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(sgstperc,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 255.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          child: IconButton(
                                            icon: Icon(
                                              Icons.edit_square,
                                              color: Colors.blue,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              print(
                                                  "print the ungiueeeee : $id");
                                              ProductCodeController.text =
                                                  data['productCode']
                                                      .toString();
                                              ProductNameController.text =
                                                  data['productName']
                                                      .toString();
                                              ProductAmountController.text =
                                                  data['amount'].toString();
                                              QuantityController.text =
                                                  data['quantity'].toString();
                                              FinalAmtController.text =
                                                  data['Amount'].toString();
                                              UpdateidController.text =
                                                  data['id'].toString();
                                              setState(() {
                                                updateenable = true;
                                                FocusScope.of(context)
                                                    .requestFocus(
                                                        quantityFocusNode);
                                              });
                                            },
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          child: IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              _showDeleteConfirmationDialog(
                                                  index);
                                            },
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList()
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  int getProductCount(List<Map<String, dynamic>> tableData) {
    return tableData.length;
  }

  double getTotalTaxable(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['retail']!) ?? 0.0;
      totalQuantity += quantity;
    }
    totalQuantity = double.parse(totalQuantity.toStringAsFixed(2));
    return totalQuantity;
  }

  double gettabletotalqty(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['quantity']!) ?? 0.0;
      totalQuantity += quantity;
    }
    totalQuantity = double.parse(totalQuantity.toStringAsFixed(2));
    return totalQuantity;
  }

  double getTotalFinalTaxable(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['retail']!) ?? 0.0;
      totalQuantity += quantity;
    }
    totalQuantity = double.parse(totalQuantity.toStringAsFixed(2));
    return totalQuantity;
  }

  double getTotalCGSTAmt(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['cgstAmt']!) ?? 0.0;
      totalQuantity += quantity;
    }
    return totalQuantity;
  }

  double getTotalSGSTAmt(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['sgstAmt']!) ?? 0.0;
      totalQuantity += quantity;
    }
    return totalQuantity;
  }

  double getTotalFinalAmt(List<Map<String, dynamic>> tableData) {
    double totalQuantity = 0.0;
    for (var data in tableData) {
      double quantity = double.tryParse(data['Amount']!) ?? 0.0;
      totalQuantity += quantity;
    }
    return totalQuantity;
  }

  double gettaxableAmtCGST0(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      if (cgstPercentage != null && cgstPercentage == 0) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }
    }
    return taxableAmount;
  }

  double gettaxableAmtCGST25(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      if (cgstPercentage != null && cgstPercentage == 2.5) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }
    }
    return taxableAmount;
  }

  double gettaxableAmtCGST6(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      if (cgstPercentage != null && cgstPercentage == 6) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }
    }
    return taxableAmount;
  }

  double gettaxableAmtCGST9(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      if (cgstPercentage != null && cgstPercentage == 9) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }
    }
    return taxableAmount;
  }

  double gettaxableAmtCGST14(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      if (cgstPercentage != null && cgstPercentage == 14) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }
    }
    return taxableAmount;
  }

  double gettaxableAmtSGST0(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      if (sgstPercentage != null && sgstPercentage == 0) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }

      // print("SGSt 0 :$taxableAmount ");
    }
    return taxableAmount;
  }

  double gettaxableAmtSGST25(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      if (sgstPercentage != null && sgstPercentage == 2.5) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }

      // print("SGSt 2.5 :$taxableAmount ");
    }
    return taxableAmount;
  }

  double gettaxableAmtSGST6(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      if (sgstPercentage != null && sgstPercentage == 6) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }

      // print("SGSt 6 :$taxableAmount ");
    }
    return taxableAmount;
  }

  double gettaxableAmtSGST9(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      if (sgstPercentage != null && sgstPercentage == 9) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }

      // print("SGSt 9 :$taxableAmount ");
    }
    return taxableAmount;
  }

  double gettaxableAmtSGST14(List<Map<String, dynamic>> tableData) {
    double taxableAmount = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      if (sgstPercentage != null && sgstPercentage == 14) {
        // Parse 'taxableAmount' to double before adding it to taxableAmount
        double? parsedTaxableAmount = double.tryParse(data['retail']);
        if (parsedTaxableAmount != null) {
          taxableAmount += parsedTaxableAmount;
        }
      }

      // print("SGSt 14 :$taxableAmount ");
    }
    return taxableAmount;
  }

  double getFinalAmtCGST0(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (cgstPercentage != null && cgstPercentage == 0) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    // print("Total amount with CGST 0%: $totalAmountCGST0 ");
    return totalAmountCGST0;
  }

  double getFinalAmtCGST25(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (cgstPercentage != null && cgstPercentage == 2.5) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtCGST6(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (cgstPercentage != null && cgstPercentage == 6) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtCGST9(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (cgstPercentage != null && cgstPercentage == 9) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtCGST14(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? cgstPercentage = double.tryParse(data['cgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (cgstPercentage != null && cgstPercentage == 14) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtSGST0(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (sgstPercentage != null && sgstPercentage == 0) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtSGST25(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (sgstPercentage != null && sgstPercentage == 2.5) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtSGST6(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (sgstPercentage != null && sgstPercentage == 6) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtSGST9(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (sgstPercentage != null && sgstPercentage == 9) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  double getFinalAmtSGST14(List<Map<String, dynamic>> tableData) {
    double totalAmountCGST0 = 0.0;
    for (var data in tableData) {
      double? sgstPercentage = double.tryParse(data['sgstperc'] ?? '0');
      double? parsedFinalAmount = double.tryParse(data['Amount'] ?? '0');

      if (sgstPercentage != null && sgstPercentage == 14) {
        if (parsedFinalAmount != null) {
          totalAmountCGST0 += parsedFinalAmount;
        }
      }
    }
    return totalAmountCGST0;
  }

  TextEditingController SalesDisAMountController = TextEditingController();
  TextEditingController SalesDisPercentageController = TextEditingController();
  TextEditingController CGSTPercent0 = TextEditingController();

  TextEditingController CGSTPercent25 = TextEditingController();

  TextEditingController CGSTPercent6 = TextEditingController();

  TextEditingController CGSTPercent9 = TextEditingController();

  TextEditingController CGSTPercent14 = TextEditingController();
  TextEditingController SGSTPercent0 = TextEditingController();

  TextEditingController SGSTPercent25 = TextEditingController();

  TextEditingController SGSTPercent6 = TextEditingController();

  TextEditingController SGSTPercent9 = TextEditingController();

  TextEditingController SGSTPercent14 = TextEditingController();
  TextEditingController FINALAMTCONTROLLWE = TextEditingController();

  void updatefinaltabletotalAmount() {
    double finaltotalamount = getTotalFinalAmt(tableData);
    FINALAMTCONTROLLWE.text = finaltotalamount.toStringAsFixed(2);
  }

  Widget bottomcontainer() {
    TextEditingController QuantityContController = TextEditingController(
      // Set the initial text to the count of items
      text: gettabletotalqty(tableData).toString(),
    );
    TextEditingController itemCountController = TextEditingController(
      // Set the initial text to the count of items
      text: getProductCount(tableData).toString(),
    );
    TextEditingController taxableamountController = TextEditingController(
      // Set the initial text to the count of items
      text: getTotalTaxable(tableData).toString(),
    );
    TextEditingController finaltaxablecontroller = TextEditingController(
      // Set the initial text to the count of items
      text: getTotalFinalTaxable(tableData).toString(),
    );
    TextEditingController cgstamtcontroller = TextEditingController(
      // Set the initial text to the count of items
      text: getTotalCGSTAmt(tableData).toString(),
    );
    TextEditingController sgstamtcontroller = TextEditingController(
      // Set the initial text to the count of items
      text: getTotalSGSTAmt(tableData).toString(),
    );
    TextEditingController finalamtcontroller = TextEditingController(
      // Set the initial text to the count of items
      text: getTotalFinalAmt(tableData).toString(),
    );

    void calculateDiscountAmount() {
      // Parse discount percentage
      double disPercentage =
          double.tryParse(SalesDisPercentageController.text.toString()) ?? 0.0;

      if (SalesGstMethodController.text == "Excluding") {
        double cgst0 =
            double.tryParse(gettaxableAmtSGST0(tableData).toString()) ?? 0.0;
        double cgst25 =
            double.tryParse(gettaxableAmtSGST25(tableData).toString()) ?? 0.0;
        double cgst6 =
            double.tryParse(gettaxableAmtSGST6(tableData).toString()) ?? 0.0;
        double cgst9 =
            double.tryParse(gettaxableAmtSGST9(tableData).toString()) ?? 0.0;
        double cgst14 =
            double.tryParse(gettaxableAmtSGST14(tableData).toString()) ?? 0.0;
        // print("Cgst 000:$cgst0");
        // print("Cgst 255:$cgst25");

        // print("Cgst 6666:$cgst6");
        // print("Cgst 9999:$cgst9");
        // print("Cgst 1444:$cgst14");

        // Perform calculations
        double part1 = cgst0 * disPercentage / 100;
        double part2 = cgst25 * disPercentage / 100;
        double part3 = cgst6 * disPercentage / 100;
        double part4 = cgst9 * disPercentage / 100;
        double part5 = cgst14 * disPercentage / 100;

        // Calculate total discount amount
        double discountAmount = part1 + part2 + part3 + part4 + part5;

        // Update the discount amount in the text controller
        SalesDisAMountController.text = discountAmount.toStringAsFixed(2);
        print("SalesDisAMountController   :${SalesDisAMountController.text}");
      } else if (SalesGstMethodController.text == "Including") {
        double cgst0 =
            double.tryParse(getFinalAmtCGST0(tableData).toString()) ?? 0.0;
        double cgst25 =
            double.tryParse(getFinalAmtCGST25(tableData).toString()) ?? 0.0;
        double cgst6 =
            double.tryParse(getFinalAmtCGST6(tableData).toString()) ?? 0.0;
        double cgst9 =
            double.tryParse(getFinalAmtCGST9(tableData).toString()) ?? 0.0;
        double cgst14 =
            double.tryParse(getFinalAmtCGST14(tableData).toString()) ?? 0.0;

        // print("Cgst 000:$cgst0");
        // print("Cgst 255:$cgst25");

        // print("Cgst 6666:$cgst6");
        // print("Cgst 9999:$cgst9");
        // print("Cgst 1444:$cgst14");
        // Perform calculations
        double part1 = cgst0 * disPercentage / 100;
        double part2 = cgst25 * disPercentage / 100;
        double part3 = cgst6 * disPercentage / 100;
        double part4 = cgst9 * disPercentage / 100;
        double part5 = cgst14 * disPercentage / 100;

        // Calculate total discount amount
        double discountAmount = part1 + part2 + part3 + part4 + part5;

        // Update the discount amount in the text controller
        SalesDisAMountController.text = discountAmount.toStringAsFixed(2);
        // print("DiscountAmount : ${SalesDisAMountController.text}");
      } else {
        double taxableamount =
            double.tryParse(getTotalFinalTaxable(tableData).toString()) ?? 0.0;

        double discountamount = taxableamount * disPercentage / 100;

        SalesDisAMountController.text = discountamount.toStringAsFixed(2);
      }
    }

    void calculateDiscountPercentage() {
      // Get the discount amount from the controller
      double discountAmount =
          double.tryParse(SalesDisAMountController.text) ?? 0.0;

      if (SalesGstMethodController.text == "Excluding") {
        // Get the total taxable amount from the widget
        double totalTaxable =
            double.tryParse(getTotalTaxable(tableData).toString()) ?? 0.0;

        // Calculate the discount percentage
        double discountPercentage = (discountAmount * 100) / totalTaxable;

        // Update the discount percentage in the appropriate controller
        SalesDisPercentageController.text =
            discountPercentage.toStringAsFixed(2);
      } else if (SalesGstMethodController.text == "Including") {
        double totalTaxable =
            double.tryParse(getTotalFinalAmt(tableData).toString()) ?? 0.0;

        // Calculate the discount percentage
        double discountPercentage = (discountAmount * 100) / totalTaxable;

        // Update the discount percentage in the appropriate controller
        SalesDisPercentageController.text =
            discountPercentage.toStringAsFixed(2);
      } else {
        double taxableamount =
            double.tryParse(getTotalFinalTaxable(tableData).toString()) ?? 0.0;

        double discountamount = discountAmount * 100 / taxableamount;

        SalesDisPercentageController.text = discountamount.toStringAsFixed(2);
      }
    }

    void CalculateCGSTFinalAmount() {
      // Parse discount percentage
      double disPercentage =
          double.tryParse(SalesDisPercentageController.text.toString()) ?? 0.0;

      if (SalesGstMethodController.text == "Excluding") {
        double cgst0 =
            double.tryParse(gettaxableAmtCGST0(tableData).toString()) ?? 0.0;
        double cgst25 =
            double.tryParse(gettaxableAmtCGST25(tableData).toString()) ?? 0.0;
        double cgst6 =
            double.tryParse(gettaxableAmtCGST6(tableData).toString()) ?? 0.0;
        double cgst9 =
            double.tryParse(gettaxableAmtCGST9(tableData).toString()) ?? 0.0;
        double cgst14 =
            double.tryParse(gettaxableAmtCGST14(tableData).toString()) ?? 0.0;
        // Perform calculations
        double cgst0part1 = cgst0 * disPercentage / 100;
        double cgst25part2 = cgst25 * disPercentage / 100;
        double cgst6part3 = cgst6 * disPercentage / 100;
        double cgst9part4 = cgst9 * disPercentage / 100;
        double cgst14part5 = cgst14 * disPercentage / 100;

        double finalcgst0amt = cgst0 - cgst0part1;
        double finalcgst25amt = cgst25 - cgst25part2;
        double finalcgst6amt = cgst6 - cgst6part3;
        double finalcgst9amt = cgst9 - cgst9part4;
        double finalcgst14amt = cgst14 - cgst14part5;

        double FinameFormulaCGST0 = finalcgst0amt * 0 / 100;
        double FinameFormulaCGST25 = finalcgst25amt * 2.5 / 100;
        double FinameFormulaCGST6 = finalcgst6amt * 6 / 100;
        double FinameFormulaCGST9 = finalcgst9amt * 9 / 100;
        double FinameFormulaCGST14 = finalcgst14amt * 14 / 100;

        CGSTPercent0.text = FinameFormulaCGST0.toStringAsFixed(2);
        CGSTPercent25.text = FinameFormulaCGST25.toStringAsFixed(2);
        CGSTPercent6.text = FinameFormulaCGST6.toStringAsFixed(2);
        CGSTPercent9.text = FinameFormulaCGST9.toStringAsFixed(2);
        CGSTPercent14.text = FinameFormulaCGST14.toStringAsFixed(2);

        double FinalCGSTAmounts = FinameFormulaCGST0 +
            FinameFormulaCGST25 +
            FinameFormulaCGST6 +
            FinameFormulaCGST9 +
            FinameFormulaCGST14;

        cgstamtcontroller.text = FinalCGSTAmounts.toStringAsFixed(2);
      } else if (SalesGstMethodController.text == "Including") {
        double cgst0 =
            double.tryParse(getFinalAmtCGST0(tableData).toString()) ?? 0.0;
        double cgst25 =
            double.tryParse(getFinalAmtCGST25(tableData).toString()) ?? 0.0;
        double cgst6 =
            double.tryParse(getFinalAmtCGST6(tableData).toString()) ?? 0.0;
        double cgst9 =
            double.tryParse(getFinalAmtCGST9(tableData).toString()) ?? 0.0;
        double cgst14 =
            double.tryParse(getFinalAmtCGST14(tableData).toString()) ?? 0.0;

        // Perform calculations
        double cgst0part1 = cgst0 * disPercentage / 100;
        double cgst25part2 = cgst25 * disPercentage / 100;
        double cgst6part3 = cgst6 * disPercentage / 100;
        double cgst9part4 = cgst9 * disPercentage / 100;
        double cgst14part5 = cgst14 * disPercentage / 100;

        double finalcgst0amt = cgst0 - cgst0part1;
        double finalcgst25amt = cgst25 - cgst25part2;
        double finalcgst6amt = cgst6 - cgst6part3;
        double finalcgst9amt = cgst9 - cgst9part4;
        double finalcgst14amt = cgst14 - cgst14part5;

        double denominator0 = 100 + 0;
        double denominator25 = 100 + 5;
        double denominator6 = 100 + 12;
        double denominator9 = 100 + 18;
        double denominator14 = 100 + 28;

        double FinameFormulaCGST0 = finalcgst0amt * 0 / denominator0;
        double FinameFormulaCGST25 = finalcgst25amt * 2.5 / denominator25;
        double FinameFormulaCGST6 = finalcgst6amt * 6 / denominator6;
        double FinameFormulaCGST9 = finalcgst9amt * 9 / denominator9;
        double FinameFormulaCGST14 = finalcgst14amt * 14 / denominator14;

        CGSTPercent0.text = FinameFormulaCGST0.toStringAsFixed(2);
        CGSTPercent25.text = FinameFormulaCGST25.toStringAsFixed(2);
        CGSTPercent6.text = FinameFormulaCGST6.toStringAsFixed(2);
        CGSTPercent9.text = FinameFormulaCGST9.toStringAsFixed(2);
        CGSTPercent14.text = FinameFormulaCGST14.toStringAsFixed(2);

        // print("cgsttttttt 00000 : ${CGSTPercent0.text}");
        // print("cgsttttttt 25555 : ${CGSTPercent25.text}");
        // print("cgsttttttt 6666 : ${CGSTPercent6.text}");
        // print("cgsttttttt 999 : ${CGSTPercent9.text}");
        // print("cgsttttttt 14444 : ${CGSTPercent14.text}");

        double FinalCGSTAmounts = FinameFormulaCGST0 +
            FinameFormulaCGST25 +
            FinameFormulaCGST6 +
            FinameFormulaCGST9 +
            FinameFormulaCGST14;

        cgstamtcontroller.text = FinalCGSTAmounts.toStringAsFixed(2);
      } else {
        CGSTPercent0.text = 0.toStringAsFixed(2);
        CGSTPercent25.text = 0.toStringAsFixed(2);
        CGSTPercent6.text = 0.toStringAsFixed(2);
        CGSTPercent9.text = 0.toStringAsFixed(2);
        CGSTPercent14.text = 0.toStringAsFixed(2);

        double FinalCGSTAmounts = 0;

        cgstamtcontroller.text = FinalCGSTAmounts.toStringAsFixed(2);
      }
    }

    void CalculateSGSTFinalAmount() {
      // Parse discount percentage
      double disPercentage =
          double.tryParse(SalesDisPercentageController.text.toString()) ?? 0.0;

      if (SalesGstMethodController.text == "Excluding") {
        double sgst0 =
            double.tryParse(gettaxableAmtSGST0(tableData).toString()) ?? 0.0;
        double sgst25 =
            double.tryParse(gettaxableAmtSGST25(tableData).toString()) ?? 0.0;
        double sgst6 =
            double.tryParse(gettaxableAmtSGST6(tableData).toString()) ?? 0.0;
        double sgst9 =
            double.tryParse(gettaxableAmtSGST9(tableData).toString()) ?? 0.0;
        double sgst14 =
            double.tryParse(gettaxableAmtSGST14(tableData).toString()) ?? 0.0;
        // Perform calculations
        // Perform calculations
        double sgst0part1 = sgst0 * disPercentage / 100;
        double sgst25part2 = sgst25 * disPercentage / 100;
        double sgst6part3 = sgst6 * disPercentage / 100;
        double sgst9part4 = sgst9 * disPercentage / 100;
        double sgst14part5 = sgst14 * disPercentage / 100;

        double finalsgst0amt = sgst0 - sgst0part1;
        double finalsgst25amt = sgst25 - sgst25part2;
        double finalsgst6amt = sgst6 - sgst6part3;
        double finalsgst9amt = sgst9 - sgst9part4;
        double finalsgst14amt = sgst14 - sgst14part5;
        double FinameFormulaSGST0 = finalsgst0amt * 0 / 100;
        double FinameFormulaSGST25 = finalsgst25amt * 2.5 / 100;
        double FinameFormulaSGST6 = finalsgst6amt * 6 / 100;
        double FinameFormulaSGST9 = finalsgst9amt * 9 / 100;
        double FinameFormulaSGST14 = finalsgst14amt * 14 / 100;

        SGSTPercent0.text = FinameFormulaSGST0.toStringAsFixed(2);
        SGSTPercent25.text = FinameFormulaSGST25.toStringAsFixed(2);
        SGSTPercent6.text = FinameFormulaSGST6.toStringAsFixed(2);
        SGSTPercent9.text = FinameFormulaSGST9.toStringAsFixed(2);
        SGSTPercent14.text = FinameFormulaSGST14.toStringAsFixed(2);

        double FinalSGSTAmounts = FinameFormulaSGST0 +
            FinameFormulaSGST25 +
            FinameFormulaSGST6 +
            FinameFormulaSGST9 +
            FinameFormulaSGST14;

        sgstamtcontroller.text = FinalSGSTAmounts.toStringAsFixed(2);
      } else if (SalesGstMethodController.text == "Including") {
        double sgst0 =
            double.tryParse(getFinalAmtSGST0(tableData).toString()) ?? 0.0;
        double sgst25 =
            double.tryParse(getFinalAmtSGST25(tableData).toString()) ?? 0.0;
        double sgst6 =
            double.tryParse(getFinalAmtSGST6(tableData).toString()) ?? 0.0;
        double sgst9 =
            double.tryParse(getFinalAmtSGST9(tableData).toString()) ?? 0.0;
        double sgst14 =
            double.tryParse(getFinalAmtSGST14(tableData).toString()) ?? 0.0;

        // Perform calculations
        double sgst0part1 = sgst0 * disPercentage / 100;
        double sgst25part2 = sgst25 * disPercentage / 100;
        double sgst6part3 = sgst6 * disPercentage / 100;
        double sgst9part4 = sgst9 * disPercentage / 100;
        double sgst14part5 = sgst14 * disPercentage / 100;

        double finalsgst0amt = sgst0 - sgst0part1;
        double finalsgst25amt = sgst25 - sgst25part2;
        double finalsgst6amt = sgst6 - sgst6part3;
        double finalsgst9amt = sgst9 - sgst9part4;
        double finalsgst14amt = sgst14 - sgst14part5;
        double denominator0 = 100 + 0;
        double denominator25 = 100 + 5;
        double denominator6 = 100 + 12;
        double denominator9 = 100 + 18;
        double denominator14 = 100 + 28;

        double FinameFormulaSGST0 = finalsgst0amt * 0 / denominator0;
        double FinameFormulaSGST25 = finalsgst25amt * 2.5 / denominator25;
        double FinameFormulaSGST6 = finalsgst6amt * 6 / denominator6;
        double FinameFormulaSGST9 = finalsgst9amt * 9 / denominator9;
        double FinameFormulaSGST14 = finalsgst14amt * 14 / denominator14;

        SGSTPercent0.text = FinameFormulaSGST0.toStringAsFixed(2);
        SGSTPercent25.text = FinameFormulaSGST25.toStringAsFixed(2);
        SGSTPercent6.text = FinameFormulaSGST6.toStringAsFixed(2);
        SGSTPercent9.text = FinameFormulaSGST9.toStringAsFixed(2);
        SGSTPercent14.text = FinameFormulaSGST14.toStringAsFixed(2);

        double FinalSGSTAmounts = FinameFormulaSGST0 +
            FinameFormulaSGST25 +
            FinameFormulaSGST6 +
            FinameFormulaSGST9 +
            FinameFormulaSGST14;

        sgstamtcontroller.text = FinalSGSTAmounts.toStringAsFixed(2);
      } else {
        SGSTPercent0.text = 0.toStringAsFixed(2);
        SGSTPercent25.text = 0.toStringAsFixed(2);
        SGSTPercent6.text = 0.toStringAsFixed(2);
        SGSTPercent9.text = 0.toStringAsFixed(2);
        SGSTPercent14.text = 0.toStringAsFixed(2);

        double FinalSGSTAmounts = 0;

        sgstamtcontroller.text = FinalSGSTAmounts.toStringAsFixed(2);
      }
    }

    void calculateFinaltotalAmount() {
      if (SalesGstMethodController.text == "Excluding") {
        // Get the total taxable amount from the widget
        double finaltotalTaxable =
            double.tryParse(finaltaxablecontroller.text) ?? 0.0;
        double finalCGSTAmount = double.tryParse(cgstamtcontroller.text) ?? 0.0;
        double finalSGSTAmount = double.tryParse(sgstamtcontroller.text) ?? 0.0;

        // Perform calculation
        double TotalAmount =
            finaltotalTaxable + finalCGSTAmount + finalSGSTAmount;

        finalamtcontroller.text = TotalAmount.toStringAsFixed(2);
        FinallyyyAmounttts.text = TotalAmount.toStringAsFixed(2);
      } else if (SalesGstMethodController.text == "Including") {
        double totalFInalAMount =
            double.tryParse(getTotalFinalAmt(tableData).toString()) ?? 0.0;
        double discountamount =
            double.tryParse(SalesDisAMountController.text) ?? 0.0;

        double FinalTotlaAmount = totalFInalAMount - discountamount;

        finalamtcontroller.text = FinalTotlaAmount.toStringAsFixed(2);

        FinallyyyAmounttts.text = FinalTotlaAmount.toStringAsFixed(2);
      } else {
        double totalFInalAMount =
            double.tryParse(getTotalFinalAmt(tableData).toString()) ?? 0.0;
        double discountamount =
            double.tryParse(SalesDisAMountController.text) ?? 0.0;

        double FinalTotlaAmount = totalFInalAMount - discountamount;

        finalamtcontroller.text = FinalTotlaAmount.toStringAsFixed(2);
        FinallyyyAmounttts.text = FinalTotlaAmount.toStringAsFixed(2);
      }
    }

    void calculateFinalTaxableAmount() {
      // Parse discount percentage

      double discountAmount =
          double.tryParse(SalesDisAMountController.text) ?? 0.0;
      if (SalesGstMethodController.text == "Excluding") {
        // Get the total taxable amount from the widget
        double totalTaxable =
            double.tryParse(getTotalFinalTaxable(tableData).toString()) ?? 0.0;

        double FinalTaxableAMount = totalTaxable - discountAmount;
        finaltaxablecontroller.text = FinalTaxableAMount.toStringAsFixed(2);
      } else if (SalesGstMethodController.text == "Including") {
        double totalFInalAMount =
            double.tryParse(getTotalFinalAmt(tableData).toString()) ?? 0.0;
        double discountamount =
            double.tryParse(SalesDisAMountController.text) ?? 0.0;

        double FinalTotlaAmount = totalFInalAMount - discountamount;

        double finalAmount = FinalTotlaAmount;
        double cgsttotalamount =
            double.tryParse(cgstamtcontroller.text.toString()) ?? 0.0;
        double sgsttotalamount =
            double.tryParse(sgstamtcontroller.text.toString()) ?? 0.0;

        double totalgstamount = cgsttotalamount + sgsttotalamount;

        double finaltaxableamount = finalAmount - totalgstamount;
        finaltaxablecontroller.text = finaltaxableamount.toStringAsFixed(2);
      } else {
        double totalTaxable =
            double.tryParse(getTotalTaxable(tableData).toString()) ?? 0.0;
        double discountAmount =
            double.tryParse(SalesDisAMountController.text) ?? 0.0;

        double finaltaxableamount = totalTaxable - discountAmount;
        finaltaxablecontroller.text = finaltaxableamount.toStringAsFixed(2);
      }
    }

    Future<void> postDataWithIncrementedSerialNo() async {
      // Parse the serial number from the text field
      String? incrementedSerialNo;
      try {
        incrementedSerialNo = widget.BillNOreset.text.toString();
      } catch (e) {
        print('Failed to parse serial number: $e');
        return; // Exit the function if parsing fails
      }

      // print("Bill no: $incrementedSerialNo");

      String? cusid = await SharedPrefs.getCusId();
      // Prepare the data to be sent
      Map<String, dynamic> postData = {
        "cusid": "$cusid",
        "serialno": incrementedSerialNo,
      };

      // Convert the data to JSON format
      String jsonData = jsonEncode(postData);

      try {
        // Send the POST request
        var response = await http.post(
          Uri.parse('$IpAddress/Sales_serialnoalldatas/'),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonData,
        );

        // Check the response status
        if (response.statusCode == 201) {
          // print('Data posted successfully');
        } else {
          // print('Response body: ${response.statusCode}');
          // successfullySavedMessage();
        }
      } catch (e) {
        // print('Failed to post data. Error: $e');
      }
    }

    Future<void> Post_SaesRoundtbl() async {
      try {
        CalculateCGSTFinalAmount();
        CalculateSGSTFinalAmount();
        calculateFinalTaxableAmount();
        calculateFinaltotalAmount();

        DateTime currentDate = DateTime.now();
        DateTime currentDatetime = DateTime.now();

        // Format the date in 'yyyy-MM-dd' format
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);
        String formattedDateTime =
            DateFormat('yyyy-MM-dd hh:mm:ss a').format(currentDatetime);
        String gstcontorller = SalesGstMethodController.text;
        String gstMethod = '';
        if (gstcontorller == 'Including' || gstcontorller == 'Excluding') {
          gstMethod = 'Gst';
        } else {
          gstMethod = 'NonGst';
        }

        String cgstperc = cgstamtcontroller.text;
        String sgstperc = sgstamtcontroller.text;

        double cgst = double.tryParse(cgstperc) ?? 0.0;
        double sgst = double.tryParse(sgstperc) ?? 0.0;

        double gstamt = cgst + sgst;

        String? cusid = await SharedPrefs.getCusId();
        Map<String, dynamic> postData = {
          "cusid": "$cusid",
          "billno": widget.BillNOreset.text,
          "dt": formattedDate,
          "type": widget.ProductSalesTypeController.text,
          "tableno": widget.tableno.text.isEmpty ? "null" : widget.tableno.text,
          "servent": widget.sname.text.isEmpty ? "null" : widget.sname.text,
          "count": itemCountController.text,
          "amount": getTotalFinalAmt(tableData).toString(),
          "discount": SalesDisAMountController.text,
          "vat": gstamt,
          "finalamount": finalamtcontroller.text,
          "cgst0": CGSTPercent0.text,
          "cgst25": CGSTPercent25.text,
          "cgst6": CGSTPercent6.text,
          "cgst9": CGSTPercent9.text,
          "cgst14": CGSTPercent14.text,
          "sgst0": SGSTPercent0.text,
          "sgst25": SGSTPercent25.text,
          "sgst6": SGSTPercent6.text,
          "sgst9": SGSTPercent9.text,
          "sgst14": SGSTPercent14.text,
          "totcgst": cgstamtcontroller.text,
          "totsgst": sgstamtcontroller.text,
          "paidamount":
              widget.paytype.text == "Credit" ? "0" : finalamtcontroller.text,
          "scode": widget.scode.text.isEmpty ? "null" : widget.scode.text,
          "sname": widget.sname.text.isEmpty ? "null" : widget.sname.text,
          "cusname": widget.customername.text.isEmpty
              ? "null"
              : widget.customername.text,
          "contact": widget.customercontact.text.isEmpty
              ? "null"
              : widget.customercontact.text,
          "paytype": widget.paytype.text,
          "disperc": SalesDisPercentageController.text,
          "famount": finalamtcontroller.text,
          // "vendorname": "0",
          // "vendorcomPerc": "0.0",
          // "CommisionAmt": "0.0",
          // "VendorDisPerc": "0.0",
          // "VendorDisamt": "0.0",
          // "FinalAmt": "1000.0",
          // "TotalAmount": "1000.0",
          "Status": "Normal",
          // "OrderNo": null,
          // "PointDis": null,
          // "login": null,
          "gststatus": gstMethod,
          "time": formattedDateTime,
          // "customeramount": null,
          // "customerchange": null,
          "taxstatus": gstcontorller,
          // "serialno": null,
          "taxable": taxableamountController.text,
          "finaltaxable": finaltaxablecontroller.text
        };

        // Convert the data to JSON format
        String jsonData = jsonEncode(postData);

        // Send the POST request
        var response = await http.post(
          Uri.parse('$IpAddress/SalesRoundDetailsalldatas/'),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonData,
        );

        // Check the response status
        if (response.statusCode == 200) {
          // print('Data posted successfully');
        } else {
          // Print the response body if available
          // print('Failed to post data. Error code: ${response.statusCode}');
          if (response.body != null && response.body.isNotEmpty) {
            // print('Response body: ${response.body}');
          }
        }
      } catch (e) {
        // Print any exceptions that occur
        // print('Failed to post data. Error: $e');
      }
    }

    Future<void> Post_salesIncometbl() async {
      try {
        if (widget.paytype != 'Credit') {
          DateTime currentDate = DateTime.now();

          // Format the date in 'yyyy-MM-dd' format
          String formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);

          String? cusid = await SharedPrefs.getCusId();
          Map<String, dynamic> postData = {
            "cusid": "$cusid",
            "description": "Sales Bill:${widget.BillNOreset.text}",
            "dt": formattedDate,
            "amount": finalamtcontroller.text
          };

          // Convert the data to JSON format
          String jsonData = jsonEncode(postData);

          // Send the POST request
          var response = await http.post(
            Uri.parse('$IpAddress/Sales_IncomeDetails/'),
            headers: <String, String>{
              'Content-Type': 'application/json; charset=UTF-8',
            },
            body: jsonData,
          );

          // Check the response status
          if (response.statusCode == 200) {
            // print('Data posted successfully');
          } else {
            // Print the response body if available
            // print('Failed to post data. Error code: ${response.statusCode}');
            if (response.body != null && response.body.isNotEmpty) {
              // print('Response body: ${response.body}');
            }
          }
        }
      } catch (e) {
        // Print any exceptions that occur
        // print('Failed to post data. Error: $e');Error:
      }
    }

    Future<void> post_stockItems(List<Map<String, dynamic>> tableData) async {
      for (var data in tableData) {
        String productName = data['productName'];
        int quantity = int.tryParse(data['quantity'].toString()) ??
            0; // Retrieve quantity from tableData

        try {
          List<Map<String, dynamic>> productList = await salesProductList();

          Map<String, dynamic>? product = productList.firstWhere(
            (element) => element['name'] == productName,
            orElse: () => {'stock': 'no', 'id': -1},
          );

          String stockStatus = product['stock'];
          int productId = product['id'];
          // print("StockStatus for product '$productName': $stockStatus");
          // print("Id  for product '$productName': $productId");

          if (stockStatus == 'Yes') {
            double stockValue =
                double.tryParse(product['stockvalue'].toString()) ?? 0;

            // Subtract the quantity from the stock value
            double updatedStockValue = stockValue - quantity;

            String? cusid = await SharedPrefs.getCusId();
            // Prepare the data to be sent to the server
            Map<String, dynamic> putData = {
              "cusid": "$cusid",
              "stockvalue": updatedStockValue.toString(),
            };

            // Convert the data to JSON format
            String jsonData = jsonEncode(putData);

            // Send the PUT request to update the stock value
            var response = await http.put(
              Uri.parse(
                  '$IpAddress/SettingsProductDetailsalldatas/$productId/'),
              headers: <String, String>{
                'Content-Type': 'application/json; charset=UTF-8',
              },
              body: jsonData,
            );

            // Check the response status
            if (response.statusCode == 200) {
              // print(
              //     'Stock value updated successfully for product: $productName');
              // Proceed with further actions if needed
            } else {
              print(
                  'Failed to update stock value for product: $productName. Error code: ${response.statusCode}');
              if (response.body != null && response.body.isNotEmpty) {
                // print('Response body: ${response.body}');
              }
            }
          }
        } catch (error) {
          print('Error retrieving product list: $error');
        }
      }
    }

    Future<void> Post_SalesDetailsRound() async {
      try {
        // CalculateCGSTFinalAmount();
        CalculateSGSTFinalAmount();
        calculateFinalTaxableAmount();
        calculateFinaltotalAmount();
        DateTime currentDate = DateTime.now();
        DateTime currentDatetime = DateTime.now();

        // Format the date in 'yyyy-MM-dd' format
        String formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);

        String formattedDateTime =
            DateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(currentDatetime);
        // String formattedDateTime =
        //     DateFormat('yyyy-MM-dd hh:mm:ss a').format(currentDatetime);
        String gstcontorller = SalesGstMethodController.text;
        String gstMethod = '';
        if (gstcontorller == 'Including' || gstcontorller == 'Excluding') {
          gstMethod = 'Gst';
        } else {
          gstMethod = 'NonGst';
        }

        String cgstperc = sgstamtcontroller.text;
        String sgstperc = sgstamtcontroller.text;

        double cgst = double.tryParse(cgstperc) ?? 0.0;
        double sgst = double.tryParse(sgstperc) ?? 0.0;

        double gstamt = cgst + sgst;
        List<String> productDetails = [];
        for (var data in tableData) {
          // Format each product detail as "{productName},{amount}"
          productDetails.add(
              "{salesbillno:${widget.BillNOreset.text},category:${data['category']},dt:$formattedDate,Itemname:${data['productName']},rate:${data['amount']},qty:${data['quantity']},amount:${data['Amount']},retailrate:${data['retailrate']},retail:${data['retail']},cgst:${data['cgstAmt']},sgst:${data['sgstAmt']},serialno:1,sgstperc:${data['sgstperc']},cgstperc:${data['cgstperc']},makingcost:${data['makingcost']},status:Normal,sno:1.0}");
        }

        // Join all product details into a single string
        String productDetailsString = productDetails.join('');

        String? cusid = await SharedPrefs.getCusId();
        Map<String, dynamic> postData = {
          "cusid": "$cusid",
          "billno": widget.BillNOreset.text,
          "dt": formattedDate,
          "type": widget.ProductSalesTypeController.text,
          "tableno": widget.tableno.text.isEmpty ? "null" : widget.tableno.text,
          "servent": widget.sname.text.isEmpty ? "null" : widget.sname.text,
          "count": itemCountController.text,
          "amount": getTotalFinalAmt(tableData).toString(),
          "discount": SalesDisAMountController.text,
          "vat": gstamt,
          "finalamount": finalamtcontroller.text,
          "cgst0": SGSTPercent0.text,
          "cgst25": SGSTPercent25.text,
          "cgst6": SGSTPercent6.text,
          "cgst9": SGSTPercent9.text,
          "cgst14": SGSTPercent14.text,
          "sgst0": SGSTPercent0.text,
          "sgst25": SGSTPercent25.text,
          "sgst6": SGSTPercent6.text,
          "sgst9": SGSTPercent9.text,
          "sgst14": SGSTPercent14.text,
          "totcgst": cgstamtcontroller.text,
          "totsgst": sgstamtcontroller.text,
          "paidamount":
              widget.paytype.text == "Credit" ? "0" : finalamtcontroller.text,

          "scode": widget.scode.text.isEmpty ? "null" : widget.scode.text,
          "sname": widget.sname.text.isEmpty ? "null" : widget.sname.text,
          "cusname": widget.customername.text.isEmpty
              ? "null"
              : widget.customername.text,
          "contact": widget.customercontact.text.isEmpty
              ? "null"
              : widget.customercontact.text,
          "paytype": widget.paytype.text,
          "disperc": SalesDisPercentageController.text,
          "famount": finalamtcontroller.text,
          // "vendorname": "0",
          // "vendorcomPerc": "0.0",
          // "CommisionAmt": "0.0",
          // "VendorDisPerc": "0.0",
          // "VendorDisamt": "0.0",
          // "FinalAmt": "1000.0",
          // "TotalAmount": "1000.0",
          "Status": "Normal",
          // "OrderNo": null,
          // "PointDis": null,
          // "login": null,
          "gststatus": gstMethod,
          "time": formattedDateTime,
          // "customeramount": null,
          // "customerchange": null,
          "taxstatus": gstcontorller,
          // "serialno": null,
          "taxable": taxableamountController.text,
          "finaltaxable": finaltaxablecontroller.text,
          "SalesDetails": productDetailsString
        };

        // Convert the data to JSON format
        String jsonData = jsonEncode(postData);

        // Send the POST request
        var response = await http.post(
          Uri.parse('$IpAddress/SalesRoundDetailsalldatas/'),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonData,
        );
        // Check the response status
        if (response.statusCode == 201) {
          print('Data posted successfully');
        } else {
          // Print the response body if available
          print('Failed to post data. Error code: ${response.statusCode}');

          if (response.body != null && response.body.isNotEmpty) {
            print('Response body: ${response.body}');
          }
        }
      } catch (e) {
        // Print any exceptions that occur
        print('Failed to post data. Error: $e');
      }
    }

    TextEditingController _pointController = TextEditingController();

    Future<void> calculatePoints(String finalAmountText) async {
      String? cusid = await SharedPrefs.getCusId();
      double finalAmount = double.tryParse(finalAmountText) ?? 0.0;

      final url = Uri.parse('$IpAddress/PointSetting/$cusid/');
      try {
        final response = await http.get(url);
        if (response.statusCode == 200) {
          List<dynamic> data = jsonDecode(response.body);
          if (data.isNotEmpty) {
            var pointSetting =
                data[0]; // Assuming there's only one item in the list
            double point = double.parse(pointSetting['point']);
            double amount = double.parse(pointSetting['amount']);
            if (finalAmount >= amount) {
              double calculatedPoints = (finalAmount / amount) * point;
              setState(() {
                _pointController.text = calculatedPoints.toString();
              });
              print("point amount : ${_pointController.text}");
              return;
            }
          }
        }
        setState(() {
          _pointController.text =
              '0.0'; // Default to 0 points if no valid point setting found or final amount is less than required
        });
      } catch (e) {
        print('Error fetching point setting: $e');
        setState(() {
          _pointController.text = '0.0'; // Handle error case
        });
      }
    }

    Future<void> updatePointsOnServer(int customerId, double newPoints) async {
      final updateUrl =
          Uri.parse('$IpAddress/SalesCustomeralldatas/$customerId/');
      print("url data : $updateUrl");
      try {
        final response = await http.patch(
          updateUrl,
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(<String, dynamic>{
            'Points': newPoints.toString(),
          }),
        );

        if (response.statusCode == 200) {
          print('Points updated successfully on the server.');
        } else {
          print(
              'Failed to update points on the server: ${response.statusCode}   ${response.body}');
        }
      } catch (e) {
        print('Error updating points on the server: $e');
      }
    }

    Future<void> updateCustomerPoints() async {
      // Calculate points based on final amount
      await calculatePoints(finalamtcontroller.text);
      String customerName = widget.customername.text.trim();
      print("Points value: ${_pointController.text}");
      print("Customer name: $customerName");

      if (customerName.isEmpty) {
        // Handle empty customer name input
        return;
      }
      String? cusid = await SharedPrefs.getCusId();

      final url = Uri.parse('$IpAddress/SalesCustomer/$cusid');
      try {
        final response = await http.get(url);
        if (response.statusCode == 200) {
          var data = jsonDecode(response.body);
          var results = data['results'] as List<dynamic>;

          // Find the customer with the given name
          var customer = results.firstWhere(
            (element) =>
                element['cusname'].toLowerCase() == customerName.toLowerCase(),
            orElse: () => null,
          );

          if (customer != null) {
            // Update points for the found customer
            double existingPoints = double.tryParse(customer['Points']) ?? 0.0;
            double newPoints =
                existingPoints + double.parse(_pointController.text);
            print("New points value: $newPoints");

            // Update points on the server
            await updatePointsOnServer(customer['id'], newPoints);
          } else {
            // Customer not found in the data
            setState(() {
              _pointController.text = 'Customer not found';
            });
          }
        } else {
          // Handle HTTP error
          print(
              'Failed to fetch data: ${response.statusCode} ${response.body}');
        }
      } catch (e) {
        // Handle other errors
        print('Error fetching customer data: $e');
      }
    }

    Future<void> _printResult() async {
      try {
        DateTime currentDate = DateTime.now();
        DateTime currentDatetime = DateTime.now();
        String formattedDate = DateFormat('dd.MM.yyyy').format(currentDate);
        String formattedDateTime =
            DateFormat('hh:mm a').format(currentDatetime);
        String billno = widget.BillNOreset.text;
        String date = formattedDate;
        String paytype = widget.paytype.text;
        String time = formattedDateTime;
        String Customername = widget.customername.text;
        String CustomerContact = widget.customercontact.text;
        String Tableno = widget.tableno.text;
        String tableservent = widget.sname.text;
        String count = itemCountController.text;
        String totalQty = QuantityContController.text;
        String totalamt = getTotalFinalAmt(tableData).toString();
        String discount = SalesDisAMountController.text;
        String FinalAmt = finalamtcontroller.text;

        String sgst25;
        if (SGSTPercent25.text == "0.00") {
          sgst25 = "";
        } else {
          sgst25 = SGSTPercent25.text;
        }
        String sgst6;
        if (SGSTPercent6.text == "0.00") {
          sgst6 = "";
        } else {
          sgst6 = SGSTPercent6.text;
        }
        String sgst9;
        if (SGSTPercent9.text == "0.00") {
          sgst9 = "";
        } else {
          sgst9 = SGSTPercent9.text;
        }
        String sgst14;
        if (SGSTPercent14.text == "0.00") {
          sgst14 = "";
        } else {
          sgst14 = SGSTPercent14.text;
        }

        List<String> productDetails = [];
        for (var data in tableData) {
          // Format each product detail as "{productName},{amount}"
          productDetails.add(
              "${data['productName']}-${data['amount']}-${data['quantity']}");
        }

        String productDetailsString = productDetails.join(',');
        // print("product details : $productDetailsString   ");
        // print(
        //     "billno : $billno   , date : $date ,  paytype : $paytype ,    time :$time    ,customername : $Customername,  customercontact : $CustomerContact  ,    table No : $Tableno,   Tableservent : $tableservent,    total count :  $count,  total qty : $totalQty,    totalamt : $totalamt,    discount amt : $discount,    finalamount:  $FinalAmt");
        print(
            "url : $IpAddress/SalesPrint3Inch/$billno-$date-$paytype-$time/$Customername-$CustomerContact/$Tableno-$tableservent/$count-$totalQty-$totalamt-$discount-$FinalAmt-$sgst25-$sgst6-$sgst9-$sgst14/$productDetailsString");

        print(
            "sgst25 : $sgst25  ,  sgst6 :   $sgst6 , sgst 9 :   $sgst9  ,   sgst14:   $sgst14");

        final response = await http.get(Uri.parse(
            '$IpAddress/SalesPrint3Inch/$billno-$date-$paytype-$time/$Customername-$CustomerContact/$Tableno-$tableservent/$count-$totalQty-$totalamt-$discount-$FinalAmt-$sgst25-$sgst6-$sgst9-$sgst14/$productDetailsString'));

        if (response.statusCode == 200) {
          // If the server returns a 200 OK response, print the response body.
          print('Response: ${response.body}');
        } else {
          // If the server did not return a 200 OK response, print the status code.
          print('Failed with status code: ${response.statusCode}');
        }
      } catch (e) {
        // Handle any potential errors.
        print('Error: $e');
      }
    }

    return Padding(
      padding: EdgeInsets.only(
        right: Responsive.isDesktop(context) ? 20 : 0,
        left: !Responsive.isDesktop(context) ? 00 : 0,
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 10),
        child: Container(
            color: Color.fromARGB(255, 255, 255, 255),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  flex: 12,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            left: Responsive.isMobile(context) ||
                                    Responsive.isTablet(context)
                                ? 15
                                : 15,
                            right: 0,
                            bottom: 5),
                        child: Column(
                          children: [
                            Wrap(
                              alignment: WrapAlignment.start,
                              children: [
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("No.Of.Items: ",
                                            // "No.Of.Items: ${getProductCountCallback(tableData)}",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .align_vertical_center_sharp, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: TextFormField(
                                                    controller:
                                                        itemCountController,
                                                    readOnly: true,
                                                    onChanged: (value) {
                                                      print(
                                                          "NO of itemis changed into the new value ");
                                                    },
                                                    decoration: InputDecoration(
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                        vertical: 4.0,
                                                        horizontal: 7.0,
                                                      ),
                                                    ),
                                                    style: textStyle),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("Taxable Amt ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .add_business_outlined, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: TextField(
                                                    readOnly: true,
                                                    controller:
                                                        taxableamountController,
                                                    onChanged: (newvalue) {},
                                                    decoration: InputDecoration(
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                        vertical: 4.0,
                                                        horizontal: 7.0,
                                                      ),
                                                    ),
                                                    style: textStyle),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (Responsive.isDesktop(context))
                                  SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("Discount %",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .discount, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text
                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,
                                                color: Colors.grey[100],
                                                child: Focus(
                                                  onKey: (FocusNode node,
                                                      RawKeyEvent event) {
                                                    if (event
                                                        is RawKeyDownEvent) {
                                                      if (event.logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowDown) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                FinalAmtFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowRight) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                discountAmtFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowUp) {
                                                        FocusScope.of(context)
                                                            .requestFocus(widget
                                                                .codeFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .enter) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                FinalAmtFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      }
                                                    }
                                                    return KeyEventResult
                                                        .ignored;
                                                  },
                                                  child: TextFormField(
                                                      controller:
                                                          SalesDisPercentageController,
                                                      textInputAction:
                                                          TextInputAction.next,
                                                      focusNode:
                                                          discountpercFocusNode,
                                                      onFieldSubmitted: (_) =>
                                                          _fieldFocusChange(
                                                              context,
                                                              discountpercFocusNode,
                                                              discountAmtFocusNode),
                                                      onChanged: (newValue) {
                                                        calculateDiscountAmount();
                                                        CalculateCGSTFinalAmount();
                                                        CalculateSGSTFinalAmount();
                                                        calculateFinalTaxableAmount();
                                                        calculateFinaltotalAmount();

                                                        double someAmount =
                                                            double.tryParse(
                                                                    finalamtcontroller
                                                                        .text) ??
                                                                0.0;
                                                        // calFinaltotalAmount(
                                                        //     someAmount);
                                                        // //     finalamtcontroller);

                                                        SalesDisPercentageController
                                                                .selection =
                                                            TextSelection.fromPosition(
                                                                TextPosition(
                                                                    offset: SalesDisPercentageController
                                                                        .text
                                                                        .length));
                                                      },
                                                      decoration:
                                                          InputDecoration(
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          180,
                                                                          180,
                                                                          180),
                                                                  width: 1.0),
                                                        ),
                                                        focusedBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Colors
                                                                      .black,
                                                                  width: 1.0),
                                                        ),
                                                        contentPadding:
                                                            EdgeInsets
                                                                .symmetric(
                                                          vertical: 4.0,
                                                          horizontal: 7.0,
                                                        ),
                                                      ),
                                                      style: textStyle),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("Discount ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .rate_review, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: Focus(
                                                  onKey: (FocusNode node,
                                                      RawKeyEvent event) {
                                                    if (event
                                                        is RawKeyDownEvent) {
                                                      if (event.logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowDown) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                FinalAmtFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowLeft) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                discountpercFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowUp) {
                                                        FocusScope.of(context)
                                                            .requestFocus(widget
                                                                .codeFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .enter) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                FinalAmtFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      }
                                                    }
                                                    return KeyEventResult
                                                        .ignored;
                                                  },
                                                  child: TextFormField(
                                                      textInputAction:
                                                          TextInputAction.next,
                                                      focusNode:
                                                          discountAmtFocusNode,
                                                      onFieldSubmitted: (_) =>
                                                          _fieldFocusChange(
                                                              context,
                                                              discountAmtFocusNode,
                                                              FinalAmtFocusNode),
                                                      controller:
                                                          SalesDisAMountController,
                                                      onChanged: (newvalue) {
                                                        calculateDiscountPercentage();
                                                        CalculateCGSTFinalAmount();
                                                        CalculateSGSTFinalAmount();

                                                        calculateFinaltotalAmount();
                                                        // calculatetotalAmount();
                                                        calculateFinalTaxableAmount();
                                                        // print(
                                                        //     "finalamount :: ${FinallyyyAmounttts.text}");
                                                        SalesDisAMountController
                                                                .selection =
                                                            TextSelection.fromPosition(
                                                                TextPosition(
                                                                    offset: SalesDisAMountController
                                                                        .text
                                                                        .length));
                                                      },
                                                      decoration:
                                                          InputDecoration(
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          180,
                                                                          180,
                                                                          180),
                                                                  width: 1.0),
                                                        ),
                                                        focusedBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Colors
                                                                      .black,
                                                                  width: 1.0),
                                                        ),
                                                        contentPadding:
                                                            EdgeInsets
                                                                .symmetric(
                                                          vertical: 4.0,
                                                          horizontal: 7.0,
                                                        ),
                                                      ),
                                                      style: textStyle),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (Responsive.isDesktop(context))
                                  SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("Final Taxable ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .rotate_90_degrees_cw_outlined, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: TextField(
                                                    readOnly: true,
                                                    controller:
                                                        finaltaxablecontroller,
                                                    decoration: InputDecoration(
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                        vertical: 4.0,
                                                        horizontal: 7.0,
                                                      ),
                                                    ),
                                                    style: textStyle),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("CGST ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .attach_money_rounded, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.27,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: TextField(
                                                    readOnly: true,
                                                    controller:
                                                        cgstamtcontroller,
                                                    decoration: InputDecoration(
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                        vertical: 4.0,
                                                        horizontal: 7.0,
                                                      ),
                                                    ),
                                                    style: textStyle),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (Responsive.isDesktop(context))
                                  SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("SGST ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .add_moderator_outlined, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: TextField(
                                                    readOnly: true,
                                                    controller:
                                                        sgstamtcontroller,
                                                    decoration: InputDecoration(
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            color: Colors.white,
                                                            width: 1.0),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                        vertical: 4.0,
                                                        horizontal: 7.0,
                                                      ),
                                                    ),
                                                    style: textStyle),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                                Container(
                                  // color:subcolor,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 0, top: 5),
                                        child: Text("Final Amount ₹",
                                            style: commonLabelTextStyle),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 4),
                                        child: Container(
                                          width: Responsive.isDesktop(context)
                                              ? MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.11
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.37,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons
                                                    .auto_mode_rounded, // Your icon here
                                                size: 17,
                                              ),
                                              SizedBox(
                                                  width:
                                                      5), // Adjust spacing between icon and text

                                              Container(
                                                height: 24,
                                                width: Responsive.isDesktop(
                                                        context)
                                                    ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.09
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                        0.28,

                                                color: Colors.grey[100],
                                                // color: Colors.grey[100],
                                                child: Focus(
                                                  onKey: (FocusNode node,
                                                      RawKeyEvent event) {
                                                    if (event
                                                        is RawKeyDownEvent) {
                                                      if (event.logicalKey ==
                                                          LogicalKeyboardKey
                                                              .arrowUp) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                discountpercFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      } else if (event
                                                              .logicalKey ==
                                                          LogicalKeyboardKey
                                                              .enter) {
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                SavebuttonFocusNode);
                                                        return KeyEventResult
                                                            .handled;
                                                      }
                                                    }
                                                    return KeyEventResult
                                                        .ignored;
                                                  },
                                                  child: TextFormField(
                                                      textInputAction:
                                                          TextInputAction.next,
                                                      focusNode:
                                                          FinalAmtFocusNode,
                                                      onFieldSubmitted: (_) {
                                                        // Move focus to the save button
                                                        FocusScope.of(context)
                                                            .requestFocus(
                                                                SavebuttonFocusNode);
                                                      },
                                                      controller:
                                                          finalamtcontroller,
                                                      onChanged: (newvalue) {},
                                                      decoration:
                                                          InputDecoration(
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          180,
                                                                          180,
                                                                          180),
                                                                  width: 1.0),
                                                        ),
                                                        focusedBorder:
                                                            OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                                  color: Colors
                                                                      .black,
                                                                  width: 1.0),
                                                        ),
                                                        contentPadding:
                                                            EdgeInsets
                                                                .symmetric(
                                                          vertical: 4.0,
                                                          horizontal: 7.0,
                                                        ),
                                                      ),
                                                      style: textStyle),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 25),
                                  child: Container(
                                    // color: Colors.green,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left:
                                                  Responsive.isDesktop(context)
                                                      ? 10
                                                      : 6,
                                              top: 0),
                                          child: Container(
                                            child: ElevatedButton(
                                              focusNode: SavebuttonFocusNode,
                                              onPressed: () async {
                                                if (SalesDisAMountController
                                                        .text.isEmpty ||
                                                    SalesDisPercentageController
                                                        .text.isEmpty ||
                                                    widget
                                                        .paytype.text.isEmpty ||
                                                    tableData.isEmpty) {
                                                  // Show error message
                                                  WarninngMessage(context);
                                                  return;
                                                }

                                                // Post_SaesRoundtbl();
                                                // Post_SaesDetailstbl(tableData);

                                                postDataWithIncrementedSerialNo();
                                                Post_salesIncometbl();
                                                post_stockItems(tableData);
                                                Post_SalesDetailsRound();
                                                updateCustomerPoints();

                                                Navigator.pushReplacement(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        NewSalesEntry(
                                                      Fianlamount:
                                                          TextEditingController(),
                                                      cusnameController:
                                                          TextEditingController(
                                                              text: ''),
                                                      TableNoController:
                                                          TextEditingController(
                                                              text: ''),
                                                      cusaddressController:
                                                          TextEditingController(
                                                              text: ''),
                                                      cuscontactController:
                                                          TextEditingController(
                                                              text: ''),
                                                      scodeController:
                                                          TextEditingController(
                                                              text: ''),
                                                      snameController:
                                                          TextEditingController(
                                                              text: ''),
                                                      TypeController:
                                                          TextEditingController(
                                                              text: ''),
                                                      salestableData: [],
                                                      isSaleOn: true,
                                                    ),
                                                  ),
                                                );

                                                _printResult();
                                                successfullySavedMessage(
                                                    context);
                                              },
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.0),
                                                ),
                                                backgroundColor: subcolor,
                                                minimumSize: Size(45.0,
                                                    31.0), // Set width and height
                                              ),
                                              child: Text('Save',
                                                  style: commonWhiteStyle),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                // Padding(
                                //   padding: const EdgeInsets.only(top: 25),
                                //   child: Container(
                                //     // color: Colors.green,
                                //     child: Column(
                                //       crossAxisAlignment:
                                //           CrossAxisAlignment.start,
                                //       children: [
                                //         Padding(
                                //           padding: EdgeInsets.only(
                                //               left:
                                //                   Responsive.isDesktop(context)
                                //                       ? 10
                                //                       : 6,
                                //               top: 0),
                                //           child: Container(
                                //             child: ElevatedButton(
                                //               onPressed: () {
                                //                 // Handle form submission
                                //               },
                                //               style: ElevatedButton.styleFrom(
                                //                 shape: RoundedRectangleBorder(
                                //                   borderRadius:
                                //                       BorderRadius.circular(
                                //                           2.0),
                                //                 ),
                                //                 backgroundColor: subcolor,
                                //                 minimumSize: Size(45.0,
                                //                     31.0), // Set width and height
                                //               ),
                                //               child: Text(
                                //                 'Preview',
                                //                 style: TextStyle(
                                //                   color: Colors.white,
                                //                   fontSize: 12,
                                //                 ),
                                //               ),
                                //             ),
                                //           ),
                                //         ),
                                //       ],
                                //     ),
                                //   ),
                                // ),

                                Padding(
                                  padding: const EdgeInsets.only(top: 25),
                                  child: Container(
                                    // color: Colors.green,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left:
                                                  Responsive.isDesktop(context)
                                                      ? 10
                                                      : 6,
                                              top: 0),
                                          child: Container(
                                            child: ElevatedButton(
                                              onPressed: () {
                                                showDialog(
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return AlertDialog(
                                                      contentPadding:
                                                          EdgeInsets.zero,
                                                      content: Container(
                                                        width: 1100,
                                                        child: GstDetailsForm(),
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.0),
                                                ),
                                                backgroundColor: subcolor,
                                                minimumSize: Size(45.0,
                                                    31.0), // Set width and height
                                              ),
                                              child: Text('Add Gst',
                                                  style: commonWhiteStyle),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 25),
                                  child: Container(
                                    // color: Colors.green,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left:
                                                  Responsive.isDesktop(context)
                                                      ? 10
                                                      : 6,
                                              top: 0),
                                          child: Container(
                                            child: ElevatedButton(
                                              onPressed: () {
                                                Navigator.pushReplacement(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        NewSalesEntry(
                                                      Fianlamount:
                                                          TextEditingController(),
                                                      cusnameController:
                                                          TextEditingController(),
                                                      TableNoController:
                                                          TextEditingController(),
                                                      cusaddressController:
                                                          TextEditingController(),
                                                      cuscontactController:
                                                          TextEditingController(),
                                                      scodeController:
                                                          TextEditingController(),
                                                      snameController:
                                                          TextEditingController(),
                                                      TypeController:
                                                          TextEditingController(),
                                                      salestableData: [],
                                                      isSaleOn: true,
                                                    ),
                                                  ),
                                                );
                                              },
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.0),
                                                ),
                                                backgroundColor: subcolor,
                                                minimumSize: Size(45.0,
                                                    31.0), // Set width and height
                                              ),
                                              child: Text('Refresh',
                                                  style: commonWhiteStyle),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 5),
              ],
            )),
      ),
    );
  }

  List<Map<String, dynamic>> productList = [];

  Future<List<Map<String, dynamic>>> salesProductList() async {
    try {
      String? cusid = await SharedPrefs.getCusId();
      String url = '$IpAddress/Settings_ProductDetails/$cusid/';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          for (var product in results) {
            // Extracting required fields and creating a map
            Map<String, dynamic> productMap = {
              'id': product['id'],
              'name': product['name'],
              'stock': product['stock'],
              'stockvalue': product['stockvalue']
            };

            // Adding the map to the list
            productList.add(productMap);
          }
          // print("product list : $productList");

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
        } else {
          throw Exception(
              'Failed to load product details: ${response.reasonPhrase}');
        }
      }
    } catch (e) {
      print('Error fetching product details: $e');
      rethrow;
    }

    return productList;
  }

  void processNewSalesEntry(
      BuildContext context, TextEditingController finalamtcontroller) {
    // Find the ancestor widget of type finalamount
    final currentWidget = context.findAncestorWidgetOfExactType<finalamount>();

    if (currentWidget == null) {
      widget.onFinalAmountButtonPressed(finalamtcontroller);
      print("Current widget is not finalamount ${finalamtcontroller.text}");
      return;
    }

    // Update the state of the finalamount widget
    currentWidget.updateFinalAmountforall(finalamtcontroller.text);

    print("Final Amount: ${finalamtcontroller.text}");
  }

  stockcheck(value) {
    print("new auantity entered amount is $value");
    String productName = ProductNameController.text;
    int quantity = int.tryParse(value) ?? 0;

    salesProductList().then((List<Map<String, dynamic>> productList) {
      Map<String, dynamic>? product = productList.firstWhere(
        (element) => element['name'] == productName,
        orElse: () => {'stock': 'no'},
      );

      String stockStatus = product['stock'];

      if (stockStatus == 'No') {
        FocusScope.of(context).requestFocus(addbuttonFocusNode);
      } else if (stockStatus == 'Yes') {
        double stockValue =
            double.tryParse(product['stockvalue'].toString()) ?? 0;

        if (quantity > stockValue) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => AlertDialog(
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Stock Check'),
                  IconButton(
                    icon: Icon(Icons.close),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
              content: Container(
                width: 500,
                child: Text(
                    'The entered quantity exceeds the available stock value (${stockValue}). '
                    'Do you want to proceed by deducting this excess quantity from the stock?'),
              ),
              actions: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();

                        FocusScope.of(context).requestFocus(quantityFocusNode);
                      },
                      child: Text('Yes Add'),
                    ),
                    TextButton(
                      onPressed: () {
                        QuantityController.text = stockValue.toString();
                        Navigator.of(context).pop();
                        FocusScope.of(context).requestFocus(quantityFocusNode);
                      },
                      child: Text('Skip'),
                    ),
                  ],
                ),
              ],
            ),
          );
        } else {
          _fieldFocusChange(context, widget.codeFocusNode, itemFocusNode);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double desktopcontainerdwidth = MediaQuery.of(context).size.width * 0.1;
    double desktoptextfeildwidth = MediaQuery.of(context).size.width * 0.07;
    return Wrap(
      alignment: WrapAlignment.start,
      runSpacing: 2,
      children: [
        Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 10 : 10, top: 0),
                child: Text("Code", style: commonLabelTextStyle),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 20 : 20, top: 4),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.38,
                  child: Row(
                    children: [
                      Icon(
                        Icons.numbers, // Your icon here
                        size: 17,
                      ),
                      SizedBox(
                          width: 5), // Adjust spacing between icon and text

                      Container(
                          height: 24,
                          width: Responsive.isDesktop(context)
                              ? desktoptextfeildwidth
                              : MediaQuery.of(context).size.width * 0.26,
                          color: Colors.grey[100],
                          child: Focus(
                            onKey: (FocusNode node, RawKeyEvent event) {
                              if (event is RawKeyDownEvent) {
                                if (event.logicalKey ==
                                    LogicalKeyboardKey.arrowDown) {
                                  FocusScope.of(context)
                                      .requestFocus(discountpercFocusNode);
                                  return KeyEventResult.handled;
                                } else if (event.logicalKey ==
                                    LogicalKeyboardKey.enter) {
                                  FocusScope.of(context)
                                      .requestFocus(itemFocusNode);
                                  return KeyEventResult.handled;
                                }
                              }
                              return KeyEventResult.ignored;
                            },
                            child: TextFormField(
                              controller: ProductCodeController,
                              textInputAction: TextInputAction.next,
                              focusNode: widget.codeFocusNode,
                              onFieldSubmitted: (_) => _fieldFocusChange(
                                  context, widget.codeFocusNode, itemFocusNode),
                              onChanged: (newValue) {
                                widget.ProductSalesTypeController.text;
                                fetchproductName();
                                updateTotal();
                                updateFinalAmount();
                              },
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 180, 180, 180),
                                      width: 1.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 1.0),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 4.0,
                                  horizontal: 7.0,
                                ),
                              ),
                              style: textStyle,
                            ),
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 10 : 20, top: 0),
                child: Text("Item", style: commonLabelTextStyle),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 20 : 20, top: 0),
                child: Container(
                    width: Responsive.isDesktop(context)
                        ? MediaQuery.of(context).size.width * 0.13
                        : MediaQuery.of(context).size.width * 0.38,
                    child: _buildProductnameDropdown()),
              ),
            ],
          ),
        ),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 20 : 10, top: 0),
                child: Text("Amount", style: commonLabelTextStyle),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 30 : 15, top: 4),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.38,
                  child: Row(
                    children: [
                      Icon(
                        Icons.note_alt_outlined, // Your icon here
                        size: 17,
                      ),
                      SizedBox(
                          width: 5), // Adjust spacing between icon and text

                      Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? desktoptextfeildwidth
                            : MediaQuery.of(context).size.width * 0.285,

                        color: Colors.grey[100],
                        // color: Colors.grey[100],
                        child: TextFormField(
                            readOnly: true,
                            controller: ProductAmountController,
                            onChanged: (newValue) {
                              fetchproductName();
                              updatetaxableamount();
                              updateCGSTAmount();
                              updateSGSTAmount();
                            },
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromARGB(255, 180, 180, 180),
                                    width: 1.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: const Color.fromARGB(0, 0, 0, 0),
                                    width: 1.0),
                              ),
                              contentPadding: EdgeInsets.symmetric(
                                vertical: 4.0,
                                horizontal: 7.0,
                              ),
                            ),
                            style: textStyle),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 10 : 20, top: 0),
                child: Text("Quantity", style: commonLabelTextStyle),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 20 : 25, top: 4),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.38,
                  child: Row(
                    children: [
                      Icon(
                        Icons.add_alert_sharp, // Your icon here
                        size: 17,
                      ),
                      SizedBox(
                          width: 5), // Adjust spacing between icon and text

                      Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? desktoptextfeildwidth
                            : MediaQuery.of(context).size.width * 0.285,

                        color: Colors.grey[100],
                        // color: Colors.grey[100],
                        child: Focus(
                          onKey: (FocusNode node, RawKeyEvent event) {
                            if (event is RawKeyDownEvent) {
                              if (event.logicalKey ==
                                  LogicalKeyboardKey.arrowDown) {
                                FocusScope.of(context)
                                    .requestFocus(discountpercFocusNode);
                                return KeyEventResult.handled;
                              } else if (event.logicalKey ==
                                  LogicalKeyboardKey.arrowLeft) {
                                FocusScope.of(context)
                                    .requestFocus(itemFocusNode);
                                return KeyEventResult.handled;
                              } else if (event.logicalKey ==
                                  LogicalKeyboardKey.enter) {
                                FocusScope.of(context)
                                    .requestFocus(addbuttonFocusNode);
                                return KeyEventResult.handled;
                              }
                            }
                            return KeyEventResult.ignored;
                          },
                          child: TextFormField(
                              controller: QuantityController,
                              focusNode: quantityFocusNode,
                              textInputAction: TextInputAction.next,
                              onFieldSubmitted: (value) {
                                _fieldFocusChange(context, quantityFocusNode,
                                    addbuttonFocusNode);
                              },
                              onChanged: (newValue) {
                                stockcheck(newValue);
                                updateTotal();
                                updatetaxableamount();
                                updateCGSTAmount();
                                updateSGSTAmount();
                                updateFinalAmount();
                              },
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 180, 180, 180),
                                      width: 1.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 1.0),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 4.0,
                                  horizontal: 7.0,
                                ),
                              ),
                              style: textStyle),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 10 : 10, top: 0),
                child: Text("Total", style: commonLabelTextStyle),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 20 : 15, top: 4),
                child: Container(
                  width: Responsive.isDesktop(context)
                      ? MediaQuery.of(context).size.width * 0.14
                      : MediaQuery.of(context).size.width * 0.38,
                  child: Row(
                    children: [
                      Icon(
                        Icons.paid_outlined, // Your icon here
                        size: 17,
                      ),
                      SizedBox(
                          width: 5), // Adjust spacing between icon and text

                      Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? MediaQuery.of(context).size.width * 0.1
                            : MediaQuery.of(context).size.width * 0.31,
                        color: Colors.grey[100],
                        child: Focus(
                          onKey: (FocusNode node, RawKeyEvent event) {
                            if (event is RawKeyDownEvent) {
                              if (event.logicalKey ==
                                  LogicalKeyboardKey.arrowDown) {
                                FocusScope.of(context)
                                    .requestFocus(discountpercFocusNode);
                                return KeyEventResult.handled;
                              } else if (event.logicalKey ==
                                  LogicalKeyboardKey.arrowLeft) {
                                FocusScope.of(context)
                                    .requestFocus(quantityFocusNode);
                                return KeyEventResult.handled;
                              } else if (event.logicalKey ==
                                  LogicalKeyboardKey.enter) {
                                // FocusScope.of(context)
                                //     .requestFocus(addbuttonFocusNode);
                                return KeyEventResult.handled;
                              }
                            }
                            return KeyEventResult.ignored;
                          },
                          child: TextFormField(
                              readOnly: true,
                              controller: FinalAmtController,
                              focusNode: finaltotalFocusNode,
                              textInputAction: TextInputAction.next,
                              onFieldSubmitted: (_) {
                                // Move focus to the save button
                                // FocusScope.of(context)
                                //     .requestFocus(addbuttonFocusNode);
                              },
                              onChanged: (newValue) {},
                              decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 180, 180, 180),
                                      width: 1.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      color: Colors.black, width: 1.0),
                                ),
                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 4.0,
                                  horizontal: 7.0,
                                ),
                              ),
                              style: AmountTextStyle),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    left: Responsive.isDesktop(context) ? 10 : 20,
                    top: Responsive.isDesktop(context) ? 23 : 4),
                child: Container(
                  width: Responsive.isDesktop(context)
                      ? (updateenable ? 83 : 60)
                      : 60,
                  child: ElevatedButton(
                    focusNode: addbuttonFocusNode,
                    onPressed: () {
                      updateenable ? UpdateData() : saveData();
                      setState(() {
                        FocusScope.of(context)
                            .requestFocus(widget.codeFocusNode);
                      });

                      // print("finalamount :: ${FinallyyyAmounttts.text}");
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2.0),
                      ),
                      backgroundColor: subcolor,
                      minimumSize: Size(45.0, 31.0), // Set width and height
                    ),
                    child: Text(updateenable ? 'Update' : 'Add',
                        style: commonWhiteStyle),
                  ),
                ),
              ),
            ],
          ),
        ),
        // finalamtRS(),
        Padding(
          padding: EdgeInsets.only(
              top: Responsive.isDesktop(context)
                  ? MediaQuery.of(context).size.width * 0.01
                  : 0,
              bottom: Responsive.isDesktop(context)
                  ? MediaQuery.of(context).size.width * 0.01
                  : 0),
          child: tableView(),
        ),
        bottomcontainer()
      ],
    );
  }

  void _deleteRow(int index) {
    setState(() {
      tableData.removeAt(index);
    });
    updatefinaltabletotalAmount();
    processNewSalesEntry(context, FINALAMTCONTROLLWE);
    successfullyDeleteMessage(context);
  }

  Future<bool?> _showDeleteConfirmationDialog(index) async {
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.delete, size: 18),
                  SizedBox(
                    width: 4,
                  ),
                  Text('Confirm Delete',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
              IconButton(
                icon: Icon(Icons.cancel, color: Colors.grey),
                onPressed: () => Navigator.of(context).pop(false),
              ),
            ],
          ),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Are you sure you want to delete this data?',
                style: TextStyle(fontSize: 13),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                _deleteRow(index!);
                Navigator.pop(context);
                successfullyDeleteMessage(context);
              },
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(2.0),
                ),
                backgroundColor: subcolor,
                minimumSize: Size(30.0, 28.0), // Set width and height
              ),
              child: Text('Delete',
                  style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ],
        );
      },
    );
  }
}

class tablesalesview extends StatefulWidget {
  final TextEditingController ProductSalesTypeController;
  final TextEditingController SalesPaytype;

  tablesalesview({
    required this.ProductSalesTypeController,
    required this.SalesPaytype,
  });
  @override
  State<tablesalesview> createState() => _tablesalesviewState();
}

class _tablesalesviewState extends State<tablesalesview> {
  String? selectedValue;

  List<dynamic> _tableData = [];
  TextEditingController TableNoController = TextEditingController();

  TextEditingController SCodeController = TextEditingController();
  TextEditingController SNameController = TextEditingController();
  TextEditingController TableCusNameController = TextEditingController();
  TextEditingController TableContactController = TextEditingController();
  TextEditingController TableAddressController = TextEditingController();
  TextEditingController TableCodeController = TextEditingController();
  TextEditingController TableItemController = TextEditingController();
  TextEditingController TableAmountController = TextEditingController();
  TextEditingController TableProdutMakingCostController =
      TextEditingController();
  TextEditingController TableProdutCategoryController = TextEditingController();

  TextEditingController TableQuantityController = TextEditingController();

  TextEditingController TotalAmtController = TextEditingController();
  TextEditingController CGSTperccontroller = TextEditingController();
  TextEditingController SGSTPercController = TextEditingController();
  TextEditingController CGSTAmtController = TextEditingController();
  TextEditingController SGSTAmtController = TextEditingController();
  TextEditingController FinalAmtController = TextEditingController();

  TextEditingController Taxableamountcontroller = TextEditingController();
  TextEditingController SalesGstMethodController = TextEditingController();
  TextEditingController salestypecontroller = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchData();
    fetchProductNameList();
    fetchGSTMethod();
    salestypecontroller = widget.ProductSalesTypeController;
    _loadSavedData();
  }

  FocusNode scodeFocusNode = FocusNode();
  FocusNode snameFocusNode = FocusNode();
  FocusNode CusnameFocusNode = FocusNode();
  FocusNode CusContactFocusNode = FocusNode();

  FocusNode CusAddressFocusNode = FocusNode();

  FocusNode codeFocusNode = FocusNode();
  FocusNode itemFocusNode = FocusNode();
  FocusNode amountFocusNode = FocusNode();
  FocusNode quantityFocusNode = FocusNode();
  FocusNode finaltotFocusNode = FocusNode();

  FocusNode addbuttonFocusNode = FocusNode();

  void _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  List<String> ProductNameList = [];

  Future<void> fetchProductNameList() async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String url = '$IpAddress/Settings_ProductDetails/$cusid/';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          ProductNameList.addAll(
              results.map<String>((item) => item['name'].toString()));
          // print("payment List : $ProductNameList");

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
        } else {
          throw Exception(
              'Failed to load categories: ${response.reasonPhrase}');
        }
      }

      // print('All product categories: $ProductNameList');
    } catch (e) {
      print('Error fetching categories: $e');
      rethrow; // Rethrow the error to propagate it further
    }
  }

  String? ProductNameSelected;

  int? _selectedProductnameIndex;

  bool _isProductnameOptionsVisible = false;
  int? _ProductnamehoveredIndex;
  Widget _buildProductnameDropdown() {
    return Padding(
      padding: const EdgeInsets.only(top: 3.0),
      child: Row(
        children: [
          Icon(
            Icons.person,
            size: 15,
          ),
          SizedBox(width: 3),
          Container(
            // width: 120,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    color: Colors.grey[100],
                    height: 23,
                    width: Responsive.isDesktop(context)
                        ? MediaQuery.of(context).size.width * 0.08
                        : MediaQuery.of(context).size.width * 0.2,
                    child: ProductnameDropdown()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: InkWell(
              onTap: () {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (BuildContext context) {
                    return Dialog(
                      child: Container(
                        width: 1350,
                        height: 800,
                        padding: EdgeInsets.all(16),
                        child: Stack(
                          children: [
                            AddProductDetailsPage(),
                            Positioned(
                              right: 0.0,
                              top: 0.0,
                              child: IconButton(
                                icon: Icon(Icons.cancel,
                                    color: Colors.red, size: 23),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                  fetchproductName();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
              child: Container(
                decoration: BoxDecoration(color: subcolor),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 6, right: 6, top: 2, bottom: 2),
                  child: Text(
                    "+",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget ProductnameDropdown() {
    return RawKeyboardListener(
      focusNode: FocusNode(),
      onKey: (RawKeyEvent event) {
        if (event is RawKeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
            // Handle arrow down event
            int currentIndex =
                ProductNameList.indexOf(TableItemController.text);
            if (currentIndex < ProductNameList.length - 1) {
              setState(() {
                _selectedProductnameIndex = currentIndex + 1;
                TableItemController.text = ProductNameList[currentIndex + 1];
                _isProductnameOptionsVisible = false;
              });
            }
          } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
            // Handle arrow up event
            int currentIndex =
                ProductNameList.indexOf(TableItemController.text);
            if (currentIndex > 0) {
              setState(() {
                _selectedProductnameIndex = currentIndex - 1;
                TableItemController.text = ProductNameList[currentIndex - 1];
                _isProductnameOptionsVisible = false;
              });
            }
          }
        }
      },
      child: TypeAheadFormField<String>(
        textFieldConfiguration: TextFieldConfiguration(
          focusNode: itemFocusNode,
          onSubmitted: (String? suggestion) async {
            await fetchproductcode();
            _fieldFocusChange(context, itemFocusNode, quantityFocusNode);
          },
          controller: TableItemController,
          decoration: const InputDecoration(
            border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 1.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.black, width: 1.0),
            ),
            contentPadding: EdgeInsets.only(bottom: 10, left: 5),
            labelStyle: DropdownTextStyle,
            suffixIcon: Icon(
              Icons.keyboard_arrow_down,
              size: 18,
            ),
          ),
          style: DropdownTextStyle,
          onChanged: (text) async {
            setState(() {
              _isProductnameOptionsVisible = true;
              ProductNameSelected = text.isEmpty ? null : text;
            });
          },
        ),
        suggestionsCallback: (pattern) {
          if (_isProductnameOptionsVisible && pattern.isNotEmpty) {
            return ProductNameList.where(
                (item) => item.toLowerCase().contains(pattern.toLowerCase()));
          } else {
            return ProductNameList;
          }
        },
        itemBuilder: (context, suggestion) {
          final index = ProductNameList.indexOf(suggestion);
          return MouseRegion(
            onEnter: (_) => setState(() {
              _ProductnamehoveredIndex = index;
            }),
            onExit: (_) => setState(() {
              _ProductnamehoveredIndex = null;
            }),
            child: Container(
              color: _selectedProductnameIndex == index
                  ? Colors.grey.withOpacity(0.3)
                  : _selectedProductnameIndex == null &&
                          ProductNameList.indexOf(TableItemController.text) ==
                              index
                      ? Colors.grey.withOpacity(0.1)
                      : Colors.transparent,
              height: 28,
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10.0,
                ),
                dense: true,
                title: Padding(
                  padding: const EdgeInsets.only(bottom: 5.0),
                  child: Text(
                    suggestion,
                    style: DropdownTextStyle,
                  ),
                ),
              ),
            ),
          );
        },
        suggestionsBoxDecoration: const SuggestionsBoxDecoration(
          constraints: BoxConstraints(maxHeight: 150),
        ),
        onSuggestionSelected: (String? suggestion) async {
          setState(() {
            fetchproductcode();

            TableItemController.text = suggestion!;
            ProductNameSelected = suggestion;
            _isProductnameOptionsVisible = false;

            FocusScope.of(context).requestFocus(quantityFocusNode);
          });
        },
        noItemsFoundBuilder: (context) => Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            'No Items Found!!!',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),
      ),
    );
  }

  bool isProductAlreadyExists(String productName) {
    // Assuming table data is stored in a List<Map<String, dynamic>> called tableData
    for (var item in salestableData) {
      if (item['productName'] == productName) {
        return true;
      }
    }
    return false;
  }

  void productalreadyexist() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.yellow,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.warning, color: maincolor),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'This product is already in the table data.',
                style: TextStyle(fontSize: 12, color: maincolor),
              ),
            ],
          ),
        );
      },
    );

    // Close the dialog automatically after 2 seconds
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pop();
    });
  }

  List<Map<String, dynamic>> productList = [];
  Future<List<Map<String, dynamic>>> salesProductList() async {
    try {
      String? cusid = await SharedPrefs.getCusId();
      String url = '$IpAddress/Settings_ProductDetails/$cusid/';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          for (var product in results) {
            // Extracting required fields and creating a map
            Map<String, dynamic> productMap = {
              'name': product['name'],
              'stock': product['stock'],
              'stockvalue': product['stockvalue']
            };

            // Adding the map to the list
            productList.add(productMap);
          }
          // print("product list : $productList");

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
        } else {
          throw Exception(
              'Failed to load product details: ${response.reasonPhrase}');
        }
      }
    } catch (e) {
      print('Error fetching product details: $e');
      rethrow;
    }

    return productList;
  }

  Future<void> fetchproductName() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/Settings_ProductDetails/$cusid/';
    String ProductCode =
        TableCodeController.text.toLowerCase(); // Convert to lowercase
    bool contactFound = false;
    // print("ProductCodeController Name: $ProductCode");

    String salestype = widget.ProductSalesTypeController.text;

    try {
      String url = baseUrl;

      while (!contactFound) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          // Iterate through each customer entry
          for (var entry in results) {
            if (entry['code'].toString().toLowerCase() == ProductCode) {
              // Convert to lowercase
              // Retrieve the contact number and address for the customer
              String amount = '';
              if (salestype == 'DineIn') {
                amount = entry['amount'];
              } else if (salestype == 'TakeAway') {
                amount = entry['wholeamount'];
              }
              String name = entry['name'];
              String agentId = entry['id'].toString();
              String makingcost = entry['makingcost'];
              String category = entry['category'];

              String cgstperc = entry['cgstper'];
              String sgstperc = entry['sgstper'];

              if (ProductCode.isNotEmpty) {
                TableItemController.text = name;
                TableAmountController.text = amount;
                TableAmountController.text = amount;
                TableProdutMakingCostController.text = makingcost;
                TableProdutCategoryController.text = category;

                CGSTperccontroller.text = cgstperc;
                SGSTPercController.text = sgstperc;

                contactFound = true;
                break; // Exit the loop once the contact number is found
              }
            }
          }

          // print("CGst Percentages:${CGSTperccontroller.text}");
          // print("Sgst Percentages:${SGSTPercController.text}");
          // Check if there are more pages
          if (!contactFound && data['next'] != null) {
            url = data['next'];
          } else {
            // Exit the loop if no more pages or contact number found
            break;
          }
        } else {
          throw Exception(
              'Failed to load customer contact information: ${response.reasonPhrase}');
        }
      }

      // Print a message if contact number not found
      if (!contactFound) {
        // print("No contact number found for $ProductCode");
      }
    } catch (e) {
      print('Error fetching customer contact information: $e');
    }
  }

  Future<void> fetchproductcode() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/Settings_ProductDetails/$cusid/';
    String productName =
        TableItemController.text.toLowerCase(); // Convert to lowercase
    bool contactFound = false;
    // print("ProductNameController Name: $productName");
    String salestype = widget.ProductSalesTypeController.text;

    try {
      String url = baseUrl;

      while (!contactFound) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          // Iterate through each product entry
          for (var entry in results) {
            if (entry['name'].toString().toLowerCase() == productName) {
              // Convert to lowercase
              // Retrieve the code and id for the product
              String code = entry['code'];
              String agentId = entry['id'].toString();

              // Determine the amount based on the salestype
              String amount = '';
              if (salestype == 'DineIn') {
                amount = entry['amount'];
              } else if (salestype == 'TakeAway') {
                amount = entry['wholeamount'];
              }
              String makingcost = entry['makingcost'];
              String category = entry['category'];

              String cgstperc = entry['cgstper'];
              String sgstperc = entry['sgstper'];

              if (productName.isNotEmpty) {
                TableCodeController.text = code;
                TableAmountController.text = amount;
                TableProdutMakingCostController.text = makingcost;
                TableProdutCategoryController.text = category;

                CGSTperccontroller.text = cgstperc;

                SGSTPercController.text = sgstperc;

                contactFound = true;
                break; // Exit the loop once the product information is found
              }
            }
          }

          // Check if there are more pages
          if (!contactFound && data['next'] != null) {
            url = data['next'];
          } else {
            // Exit the loop if no more pages or product information found
            break;
          }
        } else {
          throw Exception(
              'Failed to load product information: ${response.reasonPhrase}');
        }
      }

      // Print a message if product information not found
      if (!contactFound) {
        // print("No product information found for $productName");
      }
    } catch (e) {
      print('Error fetching product information: $e');
    }
  }

  Future<void> fetchSName() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/StaffDetails/$cusid/';
    String productCode = SCodeController.text; // Code entered by the user
    // print("Code : ${SCodeController.text}");

    try {
      String url = '$baseUrl?code=$productCode'; // Append code to URL

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List<dynamic> results = data['results'];

        if (results.isNotEmpty) {
          // Filter the results based on the entered code
          var filteredResults =
              results.where((entry) => entry['code'] == productCode);

          if (filteredResults.isNotEmpty) {
            // Clear previous names
            SNameController.clear();

            // Retrieve the product name for the specific code
            String name = filteredResults.first['serventname'];

            // Update the SNameController with the retrieved name
            SNameController.text = name;
          } else {
            // print('No product found for code: $productCode');
          }
        } else {
          // print('No products found for code: $productCode');
        }
      } else {
        throw Exception(
            'Failed to load product information: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error fetching product information: $e');
    }
  }

  Future<void> fetchcode() async {
    String? cusid = await SharedPrefs.getCusId();
    String baseUrl = '$IpAddress/StaffDetails/$cusid/';
    String productName = SNameController.text; // Code entered by the user
    // print("Code : ${SCodeController.text}");

    try {
      String url = '$baseUrl?serventname=$productName'; // Append code to URL

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List<dynamic> results = data['results'];

        if (results.isNotEmpty) {
          // Filter the results based on the entered code
          var filteredResults =
              results.where((entry) => entry['serventname'] == productName);

          if (filteredResults.isNotEmpty) {
            // Clear previous names
            SCodeController.clear();

            // Retrieve the product name for the specific code
            String code = filteredResults.first['code'];

            // Update the SNameController with the retrieved name
            SCodeController.text = code;
          } else {
            // print('No product found for code: $productName');
          }
        } else {
          // print('No products found for code: $productName');
        }
      } else {
        throw Exception(
            'Failed to load product information: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error fetching product information: $e');
    }
  }

  Future<void> fetchData() async {
    String? cusid = await SharedPrefs.getCusId();
    final response =
        await http.get(Uri.parse('$IpAddress/Sales_tableCount/$cusid/'));
    if (response.statusCode == 200) {
      setState(() {
        _tableData = json.decode(response.body)['results'];
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<void> fetchGSTMethod() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/GstDetails/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var jsonData = json.decode(response.body);

    String gstMethod = ''; // Initialize GST method to empty string

    // Iterate through each entry in the JSON data
    for (var entry in jsonData) {
      // Check if the name is "Sales"
      if (entry['name'] == "Sales") {
        // Retrieve the GST method for "Sales"
        gstMethod = entry['gst'];
        break; // Exit the loop once the entry is found
      }
    }

    // Update rateController if needed
    if (gstMethod.isNotEmpty) {
      SalesGstMethodController.text = gstMethod;
      // print("GST method for Sales: ${SalesGstMethodController.text}");
      // print("GST method for Sales: $gstMethod");
    } else {
      // print("No GST method found for Sales");
    }
  }

  void updateCGSTAmount() {
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double cgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double numerator = (taxableAmount * cgstPercentage);
    // Calculate the CGST amount
    double cgstAmount = numerator / 100;

    // Update the CGST amount controller
    CGSTAmtController.text = cgstAmount.toStringAsFixed(2);
    // print("CGST amont = ${CGSTAmtController.text}");
  }

  void updateSGSTAmount() {
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double sgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double numerator = (taxableAmount * sgstPercentage);
    // Calculate the CGST amount
    double sgstAmount = numerator / 100;

    // Update the CGST amount controller
    SGSTAmtController.text = sgstAmount.toStringAsFixed(2);
    // print("SGZGST amont = ${SGSTAmtController.text}");
  }

  void updateTotal() {
    double rate = double.tryParse(TableAmountController.text) ?? 0;
    double quantity = double.tryParse(TableQuantityController.text) ?? 0;
    double total = rate * quantity;
    TotalAmtController.text =
        total.toStringAsFixed(2); // Format total to 2 decimal places
    // Taxableamountcontroller.text = total.toStringAsFixed(2);
  }

  void updatetaxableamount() {
    double total = double.tryParse(TotalAmtController.text) ?? 0;
    double cgstAmount = double.tryParse(CGSTAmtController.text) ?? 0;
    double sgstAmount = double.tryParse(SGSTAmtController.text) ?? 0;
    double cgstPercentage = double.tryParse(CGSTperccontroller.text) ?? 0;
    double sgstPercentage = double.tryParse(SGSTPercController.text) ?? 0;

    double numeratorPart1 = total;

    if (SalesGstMethodController.text == "Excluding") {
      // Calculate taxable amount excluding GST
      double taxableAmount = numeratorPart1;
      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    } else if (SalesGstMethodController.text == "Including") {
      double cgstsgst = cgstPercentage + sgstPercentage;
      double cgstnumerator = numeratorPart1 * cgstPercentage;
      double cgstdenominator = 100 + cgstsgst;
      double cgsttaxable = cgstnumerator / cgstdenominator;
      double sgstnumerator = numeratorPart1 * sgstPercentage;
      double sgstdenominator = 100 + cgstsgst;
      double sgsttaxable = sgstnumerator / sgstdenominator;

      double taxableAmount = numeratorPart1 - (cgsttaxable + sgsttaxable);

      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("cgst taxable amount : $cgsttaxable");
      // print("sgst taxable amount : $sgsttaxable");
      // print("Total taxable amount : $taxableAmount");
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    } else {
      double taxableAmount = numeratorPart1;
      Taxableamountcontroller.text = taxableAmount.toStringAsFixed(2);
      // print("total taxable amount = ${Taxableamountcontroller.text}");
    }
  }

  void updateFinalAmount() {
    double total = double.tryParse(TotalAmtController.text) ?? 0;

    double cgstAmount = double.tryParse(CGSTAmtController.text) ?? 0;
    double sgstAmount = double.tryParse(SGSTAmtController.text) ?? 0;
    double taxableAmount = double.tryParse(Taxableamountcontroller.text) ?? 0;
    double denominator = cgstAmount + sgstAmount;

    if (SalesGstMethodController.text == "Excluding") {
      double finalAmount = taxableAmount + denominator;
      // print("FIanl amount = ${taxableAmount} + ${denominator}");

      // Update the final amount controller
      FinalAmtController.text = finalAmount.toStringAsFixed(2);
      // print("FIanl amount = ${FinalAmtController.text}");
    } else if (SalesGstMethodController.text == "Including") {
      double totalfinalamount = total;
      FinalAmtController.text = totalfinalamount.toStringAsFixed(2);
      // print("FIanl amount = ${FinalAmtController.text}");
    } else {
      double taxableAmount = total;
      FinalAmtController.text = taxableAmount.toStringAsFixed(2);
      // print("FIanl amount = ${FinalAmtController.text}");
    }
  }

  void _saveText(
    String tableno,
    String scodeValue,
    String snameValue,
    String customerNameValue,
    String customerContactValue,
    String addressValue,
    List<Map<String, dynamic>> tabledata,
  ) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String tableDataJson = jsonEncode(tabledata);
    String jsonData = jsonEncode({
      'tableno': tableno,
      'scode': scodeValue,
      'sname': snameValue,
      'customerName': customerNameValue,
      'customerContact': customerContactValue,
      'address': addressValue,
      'tableData': tableDataJson,
    });

    // Construct unique key based on table number
    String key = 'table_$tableno';

    // Save the serialized data as a string with the unique key
    prefs.setString(key, jsonData);
  }

  void deleteTableData(String tableno) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Construct unique key based on table number
    String key = 'table_$tableno';

    // Remove data associated with the key
    prefs.remove(key);
  }

  late SharedPreferences prefs;
  String selectedCode = '';
  bool showTableNo = false;
  bool isSavedInSharedPreferences = false;

  void _loadSavedData() async {
    prefs = await SharedPreferences.getInstance();

    // Construct the key based on the selected table number
    String key = 'table_$selectedCode';

    // Retrieve the data associated with the selected table number
    String? jsonData = prefs.getString(key);

    // If data exists for the selected table number
    if (jsonData != null) {
      // Decode the JSON data
      Map<String, dynamic> data = jsonDecode(jsonData);

      // Populate the text fields with the retrieved data
      setState(() {
        SCodeController.text = data['scode'] ?? '';
        SNameController.text = data['sname'] ?? '';
        TableCusNameController.text = data['customerName'] ?? '';
        TableContactController.text = data['customerContact'] ?? '';
        TableAddressController.text = data['address'] ?? '';
        isSavedInSharedPreferences = true;
        finalsalestableData =
            List<Map<String, dynamic>>.from(jsonDecode(data['tableData']));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double desktopcontainerdwidth = MediaQuery.of(context).size.width * 0.1;
    double desktoptextfeildwidth = MediaQuery.of(context).size.width * 0.07;
    double screenHeight = MediaQuery.of(context).size.height;
    TableNoController.text = selectedCode;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 6),
                  // Render buttons conditionally based on showTableNo
                  if (!showTableNo)
                    for (var data in _tableData)
                      buildTableButton(
                        data['name'],
                        List.generate(int.parse(data['count']),
                            (index) => '${data['code']}${index + 1}'),
                        data['code'], // Pass the code for comparison
                      ),
                  // Show only the selected button's details when showTableNo is true
                  if (showTableNo)
                    SingleChildScrollView(
                      child: Container(
                        color: const Color.fromARGB(255, 255, 255, 255),
                        width: !Responsive.isDesktop(context)
                            ? MediaQuery.of(context).size.width * 0.65
                            : MediaQuery.of(context).size.width * 0.6,
                        child: Center(
                          child: Column(
                            children: [
                              SizedBox(height: 15),
                              if (selectedCode.isNotEmpty)
                                Text("Table No : $selectedCode  ",
                                    style: HeadingStyle),
                              SizedBox(height: 12),
                              if (Responsive.isDesktop(context))
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    tablesalesserventdetails(
                                        context,
                                        desktopcontainerdwidth,
                                        desktoptextfeildwidth),
                                  ],
                                ),
                              if (Responsive.isDesktop(context))
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    tablesalesproductdetails(
                                        context,
                                        desktopcontainerdwidth,
                                        desktoptextfeildwidth),
                                  ],
                                ),
                              if (!Responsive.isDesktop(context))
                                Wrap(
                                  alignment: WrapAlignment.start,
                                  children: [
                                    tablesalesserventdetails(
                                        context,
                                        desktopcontainerdwidth,
                                        desktoptextfeildwidth),
                                    tablesalesproductdetails(
                                        context,
                                        desktopcontainerdwidth,
                                        desktoptextfeildwidth),
                                  ],
                                ),
                              if (!Responsive.isDesktop(context))
                                SizedBox(
                                  width: 20,
                                ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    // color:subcolor,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left:
                                                  Responsive.isDesktop(context)
                                                      ? 20
                                                      : 0,
                                              top: Responsive.isDesktop(context)
                                                  ? 17
                                                  : 14),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                right: 13),
                                            child: StatefulBuilder(builder:
                                                (BuildContext context,
                                                    StateSetter setState) {
                                              return ElevatedButton(
                                                focusNode: addbuttonFocusNode,
                                                onPressed: () {
                                                  updateTotal();
                                                  updatetaxableamount();
                                                  updateCGSTAmount();
                                                  updateSGSTAmount();
                                                  updateFinalAmount();
                                                  addButtonPressed();

                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          codeFocusNode);
                                                },
                                                style: ElevatedButton.styleFrom(
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            2.0),
                                                  ),
                                                  backgroundColor: subcolor,
                                                  minimumSize: Size(45.0,
                                                      31.0), // Set width and height
                                                ),
                                                child: Text('Add',
                                                    style: commonWhiteStyle),
                                              );
                                            }),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // SizedBox(width: 5),
                                  Container(
                                    // color:subcolor,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left:
                                                  Responsive.isDesktop(context)
                                                      ? 10
                                                      : 0,
                                              top: Responsive.isDesktop(context)
                                                  ? 17
                                                  : 14),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                right: 13),
                                            child: ElevatedButton(
                                              onPressed: () {
                                                cleardata();
                                              },
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.0),
                                                ),
                                                backgroundColor: subcolor,
                                                minimumSize: Size(45.0,
                                                    31.0), // Set width and height
                                              ),
                                              child: Text('Clear',
                                                  style: commonWhiteStyle),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // SizedBox(width: 5),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Container(
                                    width: Responsive.isDesktop(context)
                                        ? MediaQuery.of(context).size.width
                                        : MediaQuery.of(context).size.width *
                                            0.8,
                                    // color: const Color.fromARGB(255, 255, 233, 231),
                                    child: Responsive.isDesktop(context)
                                        ? Column(
                                            children: [
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                        width: Responsive
                                                                .isDesktop(
                                                                    context)
                                                            ? screenHeight * 0.6
                                                            : 480,
                                                        height: Responsive
                                                                .isDesktop(
                                                                    context)
                                                            ? screenHeight * 0.4
                                                            : 320,
                                                        // color: Colors.pink,
                                                        child:
                                                            tablesalesview()),
                                                    VerticalDivider(
                                                      color: Color.fromARGB(
                                                          255, 122, 122, 122),
                                                      thickness: 0.8,
                                                    ),
                                                    Container(
                                                        width: Responsive
                                                                .isDesktop(
                                                                    context)
                                                            ? screenHeight * 0.6
                                                            : 480,
                                                        height: Responsive
                                                                .isDesktop(
                                                                    context)
                                                            ? screenHeight * 0.4
                                                            : 320,
                                                        // color: Colors.yellow,
                                                        child:
                                                            tablesalesviewtableNo())
                                                  ]),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      width:
                                                          Responsive.isDesktop(
                                                                  context)
                                                              ? screenHeight *
                                                                  0.6
                                                              : 480,
                                                      height: 40,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .end,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    bottom: 10,
                                                                    right: 13),
                                                            child:
                                                                ElevatedButton(
                                                              onPressed: () {
                                                                _printResult();
                                                                lastsaveData();
                                                                String tableno =
                                                                    TableNoController
                                                                        .text;
                                                                String
                                                                    scodeValue =
                                                                    SCodeController
                                                                        .text;
                                                                String
                                                                    snameValue =
                                                                    SNameController
                                                                        .text;
                                                                String
                                                                    customerNameValue =
                                                                    TableCusNameController
                                                                        .text;
                                                                String
                                                                    customerContactValue =
                                                                    TableContactController
                                                                        .text;
                                                                String
                                                                    addressValue =
                                                                    TableAddressController
                                                                        .text;

                                                                List<
                                                                        Map<String,
                                                                            dynamic>>
                                                                    tabledata =
                                                                    finalsalestableData;

                                                                if (scodeValue
                                                                    .isNotEmpty) {
                                                                  _saveText(
                                                                      tableno,
                                                                      scodeValue,
                                                                      snameValue,
                                                                      customerNameValue,
                                                                      customerContactValue,
                                                                      addressValue,
                                                                      tabledata);
                                                                }
                                                                // Navigator.pop(
                                                                //     context);
                                                              },
                                                              style:
                                                                  ElevatedButton
                                                                      .styleFrom(
                                                                shape:
                                                                    RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              2.0),
                                                                ),
                                                                backgroundColor:
                                                                    subcolor,
                                                                minimumSize: Size(
                                                                    45.0,
                                                                    31.0), // Set width and height
                                                              ),
                                                              child: Text(
                                                                  'Save',
                                                                  style:
                                                                      commonWhiteStyle),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      width:
                                                          Responsive.isDesktop(
                                                                  context)
                                                              ? screenHeight *
                                                                  0.6
                                                              : 480,
                                                      height: 40,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .end,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    bottom: 10,
                                                                    right: 13),
                                                            child:
                                                                ElevatedButton(
                                                              onPressed: () {
                                                                String tableno =
                                                                    TableNoController
                                                                        .text;
                                                                deleteTableData(
                                                                    tableno);
                                                                Navigator
                                                                    .pushReplacement(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder:
                                                                        (context) =>
                                                                            NewSalesEntry(
                                                                      Fianlamount:
                                                                          TextEditingController(),
                                                                      salestableData:
                                                                          finalsalestableData,
                                                                      cusnameController:
                                                                          TableCusNameController,
                                                                      TableNoController:
                                                                          TableNoController,
                                                                      cusaddressController:
                                                                          TableAddressController,
                                                                      cuscontactController:
                                                                          TableContactController,
                                                                      scodeController:
                                                                          SCodeController,
                                                                      snameController:
                                                                          SNameController,
                                                                      TypeController:
                                                                          salestypecontroller,
                                                                      isSaleOn:
                                                                          false,
                                                                    ),
                                                                  ),
                                                                );
                                                              },
                                                              style:
                                                                  ElevatedButton
                                                                      .styleFrom(
                                                                shape:
                                                                    RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              2.0),
                                                                ),
                                                                backgroundColor:
                                                                    subcolor,
                                                                minimumSize: Size(
                                                                    45.0,
                                                                    31.0), // Set width and height
                                                              ),
                                                              child: Text(
                                                                  'Move',
                                                                  style:
                                                                      commonWhiteStyle),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    bottom: 10,
                                                                    right: 13),
                                                            child:
                                                                ElevatedButton(
                                                              onPressed: () {
                                                                // Handle form submission
                                                              },
                                                              style:
                                                                  ElevatedButton
                                                                      .styleFrom(
                                                                shape:
                                                                    RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              2.0),
                                                                ),
                                                                backgroundColor:
                                                                    subcolor,
                                                                minimumSize: Size(
                                                                    45.0,
                                                                    31.0), // Set width and height
                                                              ),
                                                              child: Text(
                                                                  'Print',
                                                                  style:
                                                                      commonWhiteStyle),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    bottom: 10,
                                                                    right: 13),
                                                            child:
                                                                ElevatedButton(
                                                              onPressed: () {
                                                                Closetabledetails();
                                                                if (showTableNo) {
                                                                  setState(() {
                                                                    showTableNo =
                                                                        false; // Close the details view
                                                                  });
                                                                }
                                                                // print(
                                                                //     "c;ose button is pressed");
                                                              },
                                                              style:
                                                                  ElevatedButton
                                                                      .styleFrom(
                                                                shape:
                                                                    RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              2.0),
                                                                ),
                                                                backgroundColor:
                                                                    subcolor,
                                                                minimumSize: Size(
                                                                    45.0,
                                                                    31.0), // Set width and height
                                                              ),
                                                              child: Text(
                                                                  'Clsse',
                                                                  style:
                                                                      commonWhiteStyle),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    )
                                                  ]),
                                            ],
                                          )
                                        : Column(
                                            children: [
                                              Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                        width: 480,
                                                        // color: Colors.pink,
                                                        child: Column(
                                                          children: [
                                                            tablesalesview(),
                                                            Container(
                                                              width: 480,
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                children: [
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        right:
                                                                            13,
                                                                        bottom:
                                                                            15,
                                                                        top:
                                                                            15),
                                                                    child:
                                                                        ElevatedButton(
                                                                      onPressed:
                                                                          () {
                                                                        _printResult();
                                                                        lastsaveData();
                                                                        String
                                                                            tableno =
                                                                            TableNoController.text;
                                                                        String
                                                                            scodeValue =
                                                                            SCodeController.text;
                                                                        String
                                                                            snameValue =
                                                                            SNameController.text;
                                                                        String
                                                                            customerNameValue =
                                                                            TableCusNameController.text;
                                                                        String
                                                                            customerContactValue =
                                                                            TableContactController.text;
                                                                        String
                                                                            addressValue =
                                                                            TableAddressController.text;

                                                                        List<Map<String, dynamic>>
                                                                            tabledata =
                                                                            finalsalestableData;

                                                                        if (scodeValue
                                                                            .isNotEmpty) {
                                                                          _saveText(
                                                                              tableno,
                                                                              scodeValue,
                                                                              snameValue,
                                                                              customerNameValue,
                                                                              customerContactValue,
                                                                              addressValue,
                                                                              tabledata);
                                                                        }
                                                                      },
                                                                      style: ElevatedButton
                                                                          .styleFrom(
                                                                        shape:
                                                                            RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(2.0),
                                                                        ),
                                                                        backgroundColor:
                                                                            subcolor,
                                                                        minimumSize: Size(
                                                                            45.0,
                                                                            31.0), // Set width and height
                                                                      ),
                                                                      child: Text(
                                                                          'Save',
                                                                          style:
                                                                              commonWhiteStyle),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        )),
                                                    Container(
                                                        width: 480,
                                                        // color: Colors.yellow,
                                                        child: Column(
                                                          children: [
                                                            tablesalesviewtableNo(),
                                                            SizedBox(
                                                              height: 10,
                                                            ),
                                                            Container(
                                                              width: 480,
                                                              child: Column(
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .end,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    children: [
                                                                      Padding(
                                                                        padding: const EdgeInsets.only(
                                                                            right:
                                                                                7,
                                                                            bottom:
                                                                                15,
                                                                            top:
                                                                                5),
                                                                        child:
                                                                            ElevatedButton(
                                                                          onPressed:
                                                                              () {
                                                                            String
                                                                                tableno =
                                                                                TableNoController.text;
                                                                            deleteTableData(tableno);
                                                                            Navigator.push(
                                                                              context,
                                                                              MaterialPageRoute(
                                                                                builder: (context) => NewSalesEntry(
                                                                                  Fianlamount: TextEditingController(),
                                                                                  salestableData: finalsalestableData,
                                                                                  cusnameController: TableCusNameController,
                                                                                  TableNoController: TableContactController,
                                                                                  cusaddressController: TableAddressController,
                                                                                  cuscontactController: TableContactController,
                                                                                  scodeController: SCodeController,
                                                                                  snameController: SNameController,
                                                                                  TypeController: salestypecontroller,
                                                                                  isSaleOn: false,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          },
                                                                          style:
                                                                              ElevatedButton.styleFrom(
                                                                            shape:
                                                                                RoundedRectangleBorder(
                                                                              borderRadius: BorderRadius.circular(2.0),
                                                                            ),
                                                                            backgroundColor:
                                                                                subcolor,
                                                                            minimumSize:
                                                                                Size(45.0, 31.0), // Set width and height
                                                                          ),
                                                                          child: Text(
                                                                              'Move',
                                                                              style: commonWhiteStyle),
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding: const EdgeInsets.only(
                                                                            right:
                                                                                7,
                                                                            bottom:
                                                                                15,
                                                                            top:
                                                                                5),
                                                                        child:
                                                                            ElevatedButton(
                                                                          onPressed:
                                                                              () {
                                                                            // Handle form submission
                                                                          },
                                                                          style:
                                                                              ElevatedButton.styleFrom(
                                                                            shape:
                                                                                RoundedRectangleBorder(
                                                                              borderRadius: BorderRadius.circular(2.0),
                                                                            ),
                                                                            backgroundColor:
                                                                                subcolor,
                                                                            minimumSize:
                                                                                Size(45.0, 31.0), // Set width and height
                                                                          ),
                                                                          child: Text(
                                                                              'Print',
                                                                              style: commonWhiteStyle),
                                                                        ),
                                                                      ),
                                                                      Padding(
                                                                        padding: const EdgeInsets.only(
                                                                            right:
                                                                                7,
                                                                            bottom:
                                                                                15,
                                                                            top:
                                                                                5),
                                                                        child:
                                                                            ElevatedButton(
                                                                          onPressed:
                                                                              () {
                                                                            Closetabledetails();
                                                                            if (showTableNo) {
                                                                              setState(() {
                                                                                showTableNo = false; // Close the details view
                                                                              });
                                                                            }
                                                                          },
                                                                          style:
                                                                              ElevatedButton.styleFrom(
                                                                            shape:
                                                                                RoundedRectangleBorder(
                                                                              borderRadius: BorderRadius.circular(2.0),
                                                                            ),
                                                                            backgroundColor:
                                                                                subcolor,
                                                                            minimumSize:
                                                                                Size(45.0, 31.0), // Set width and height
                                                                          ),
                                                                          child: Text(
                                                                              'Close',
                                                                              style: commonWhiteStyle),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ))
                                                  ]),
                                            ],
                                          )),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Wrap tablesalesproductdetails(BuildContext context,
      double desktopcontainerdwidth, double desktoptextfeildwidth) {
    return Wrap(alignment: WrapAlignment.start, children: [
      SizedBox(width: 10),
      Container(
        // color:subcolor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 0, top: 8),
              child: Text("Code", style: commonLabelTextStyle),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Responsive.isDesktop(context) ? 5 : 0, top: 8),
              child: Container(
                height: 24,
                width: Responsive.isDesktop(context)
                    ? desktopcontainerdwidth
                    : MediaQuery.of(context).size.width * 0.3,
                child: Container(
                    height: 24,
                    width: Responsive.isDesktop(context)
                        ? desktoptextfeildwidth
                        : MediaQuery.of(context).size.width * 0.2,
                    color: Colors.grey[100],
                    child: TextFormField(
                        onChanged: (newvalue) {
                          fetchproductName();
                        },
                        controller: TableCodeController,
                        focusNode: codeFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, codeFocusNode, itemFocusNode),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade300, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: Colors.black, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: textStyle)),
              ),
            ),
          ],
        ),
      ),
      SizedBox(width: 10),
      Container(
        // color:subcolor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 0, top: 8),
              child: Text("Item", style: commonLabelTextStyle),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Responsive.isDesktop(context) ? 3 : 0, top: 8),
              child: Container(
                  width: Responsive.isDesktop(context)
                      ? MediaQuery.of(context).size.width * 0.11
                      : MediaQuery.of(context).size.width * 0.3,
                  child: _buildProductnameDropdown()),
            ),
          ],
        ),
      ),
      SizedBox(width: 10),
      Container(
        // color:subcolor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 0, top: 8),
              child: Text("Amount", style: commonLabelTextStyle),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Responsive.isDesktop(context) ? 5 : 0, top: 8),
              child: Container(
                height: 24,
                width: Responsive.isDesktop(context)
                    ? desktopcontainerdwidth
                    : MediaQuery.of(context).size.width * 0.3,
                child: Row(
                  children: [
                    Icon(
                      Icons.note_alt_outlined, // Your icon here
                      size: 17,
                    ),
                    SizedBox(width: 3), // Adjust spacing between icon and text

                    Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? MediaQuery.of(context).size.width * 0.08
                            : MediaQuery.of(context).size.width * 0.255,
                        color: Colors.grey[100],
                        // color: Colors.grey[100],
                        child: TextField(
                            readOnly: true,
                            controller: TableAmountController,
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Colors.grey.shade300, width: 1.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.black, width: 1.0),
                              ),
                              contentPadding: EdgeInsets.symmetric(
                                vertical: 4.0,
                                horizontal: 7.0,
                              ),
                            ),
                            style: textStyle)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      SizedBox(width: 10),
      Container(
        // color:subcolor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 0, top: 8),
              child: Text("Quantity", style: commonLabelTextStyle),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Responsive.isDesktop(context) ? 5 : 0, top: 8),
              child: Container(
                height: 24,
                width: Responsive.isDesktop(context)
                    ? desktopcontainerdwidth
                    : MediaQuery.of(context).size.width * 0.3,
                child: Row(
                  children: [
                    Icon(
                      Icons.add_alert_rounded, // Your icon here
                      size: 17,
                    ),
                    SizedBox(width: 1), // Adjust spacing between icon and text

                    Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? MediaQuery.of(context).size.width * 0.08
                            : MediaQuery.of(context).size.width * 0.255,
                        color: Colors.grey[100],
                        // color: Colors.grey[100],
                        child: TextFormField(
                            controller: TableQuantityController,
                            focusNode: quantityFocusNode,
                            textInputAction: TextInputAction.next,
                            onFieldSubmitted: (value) {
                              String productName = TableItemController.text;
                              int quantity = int.tryParse(value) ?? 0;

                              // Check if the product's stock is available
                              salesProductList().then(
                                  (List<Map<String, dynamic>> productList) {
                                // Find the product in the list
                                Map<String, dynamic>? product =
                                    productList.firstWhere(
                                  (element) => element['name'] == productName,
                                  orElse: () => {
                                    'stock': 'no'
                                  }, // Default values if product not found
                                );

                                String stockStatus = product['stock'];
                                // print(
                                //     "stock values for the $productName is $stockStatus");

                                if (stockStatus == 'No') {
                                  // Product's stock is not available, proceed with relevant action
                                  // For example, move focus to the next field
                                  // FocusScope.of(context)
                                  //     .requestFocus(
                                  //         finaltotFocusNode);
                                } else if (stockStatus == 'Yes') {
                                  // Product's stock is available, proceed with quantity validation
                                  double stockValue = double.tryParse(
                                          product['stockvalue'].toString()) ??
                                      0;

                                  if (quantity > stockValue) {
                                    // Quantity exceeds stock value, show error message and clear quantity controller
                                    showDialog(
                                      context: context,
                                      barrierDismissible:
                                          false, // Prevent closing when tapping outside or pressing back button

                                      builder: (context) => AlertDialog(
                                        title: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text('Stock Check'),
                                            IconButton(
                                              icon: Icon(Icons.close),
                                              onPressed: () {
                                                // Close the dialog without any action
                                                Navigator.of(context).pop();
                                              },
                                            ),
                                          ],
                                        ),
                                        content: Container(
                                          width: 500,
                                          child: Text(
                                              'The entered quantity exceeds the available stock value (${stockValue}). '
                                              'Do you want to proceed by deducting this excess quantity from the stock?'),
                                        ),
                                        actions: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            children: [
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.of(context).pop();

                                                  // FocusScope.of(
                                                  //         context)
                                                  //     .requestFocus(
                                                  //         itemFocusNode);
                                                },
                                                child: Text('Yes Add'),
                                              ),
                                              TextButton(
                                                onPressed: () {
                                                  TableQuantityController.text =
                                                      stockValue
                                                          .toString(); // Set quantity to stock value

                                                  Navigator.of(context).pop();
                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          finaltotFocusNode);
                                                },
                                                child: Text('Skip'),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    );
                                  } else {
                                    // Quantity is valid, move focus to the next field
                                    _fieldFocusChange(context,
                                        quantityFocusNode, finaltotFocusNode);
                                  }
                                }
                              });
                            },

                            // onFieldSubmitted: (_) {
                            //   // Move focus to the save button
                            //   FocusScope.of(context)
                            //       .requestFocus(
                            //           addbuttonFocusNode);
                            // },
                            onChanged: (value) {
                              updateTotal();
                              updatetaxableamount();
                              updateCGSTAmount();
                              updateSGSTAmount();
                              updateFinalAmount();
                            },
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Colors.grey.shade300, width: 1.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.black, width: 1.0),
                              ),
                              contentPadding: EdgeInsets.symmetric(
                                vertical: 4.0,
                                horizontal: 7.0,
                              ),
                            ),
                            style: textStyle)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      SizedBox(width: 10),
      Container(
        // color:subcolor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 0, top: 8),
              child: Text("Total", style: commonLabelTextStyle),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Responsive.isDesktop(context) ? 5 : 0, top: 8),
              child: Container(
                height: 24,
                width: Responsive.isDesktop(context)
                    ? desktopcontainerdwidth
                    : MediaQuery.of(context).size.width * 0.3,
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktoptextfeildwidth
                      : MediaQuery.of(context).size.width * 0.2,
                  color: Colors.grey[200],
                  child: TextFormField(
                      readOnly: true,
                      controller: FinalAmtController,
                      focusNode: finaltotFocusNode,
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) {
                        // Move focus to the save button
                        FocusScope.of(context).requestFocus(addbuttonFocusNode);
                      },
                      onChanged: (newValue) {},
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.grey.shade300, width: 1.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.black, width: 1.0),
                        ),
                        contentPadding: EdgeInsets.symmetric(
                          vertical: 4.0,
                          horizontal: 7.0,
                        ),
                      ),
                      style: AmountTextStyle),
                ),
              ),
            ),
          ],
        ),
      ),
    ]);
  }

  Wrap tablesalesserventdetails(BuildContext context,
      double desktopcontainerdwidth, double desktoptextfeildwidth) {
    return Wrap(
      alignment: WrapAlignment.start,
      children: [
        SizedBox(width: 10),
        Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Text("S.Code: ", style: commonLabelTextStyle),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 5, top: 8),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.28,
                  // color: Colors.red,
                  child: Row(
                    children: [
                      Container(
                        height: 24,
                        width: Responsive.isDesktop(context)
                            ? desktoptextfeildwidth
                            : MediaQuery.of(context).size.width * 0.2,
                        color: Colors.grey[100],
                        child: TextFormField(
                            focusNode: scodeFocusNode,
                            textInputAction: TextInputAction.next,
                            onFieldSubmitted: (_) => _fieldFocusChange(
                                context, scodeFocusNode, snameFocusNode),
                            onChanged: (newvalue) {
                              fetchSName();
                            },
                            controller: SCodeController,
                            decoration: InputDecoration(
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Colors.grey.shade300, width: 1.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.black, width: 1.0),
                              ),
                              contentPadding: EdgeInsets.symmetric(
                                vertical: 4.0,
                                horizontal: 7.0,
                              ),
                            ),
                            style: textStyle),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 0),
                        child: InkWell(
                          onTap: () {
                            showDialog(
                              context: context,
                              barrierDismissible: false,
                              builder: (BuildContext context) {
                                return Dialog(
                                  child: Container(
                                    width: 1350,
                                    height: 800,
                                    padding: EdgeInsets.all(16),
                                    child: Stack(
                                      children: [
                                        StaffDetailsPage(),
                                        Positioned(
                                          right: 0.0,
                                          top: 0.0,
                                          child: IconButton(
                                            icon: Icon(Icons.cancel,
                                                color: Colors.red, size: 23),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                              fetchproductName();
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(color: subcolor),
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 6, right: 6, top: 2, bottom: 2),
                              child: Text(
                                "+",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Text("S Name", style: commonLabelTextStyle),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 5, top: 8),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.3,
                  child: Container(
                    height: 24,
                    width: Responsive.isDesktop(context)
                        ? desktoptextfeildwidth
                        : MediaQuery.of(context).size.width * 0.2,
                    color: Colors.grey[100],
                    child: TextFormField(
                        onChanged: (newvalue) {
                          fetchcode();
                        },
                        controller: SNameController,
                        focusNode: snameFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, snameFocusNode, CusnameFocusNode),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade300, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: Colors.black, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: textStyle),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Text("Customer Name", style: commonLabelTextStyle),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 5, top: 8),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.3,
                  child: Container(
                    height: 24,
                    width: Responsive.isDesktop(context)
                        ? desktoptextfeildwidth
                        : MediaQuery.of(context).size.width * 0.2,
                    color: Colors.grey[200],
                    child: TextFormField(
                        controller: TableCusNameController,
                        focusNode: CusnameFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, CusnameFocusNode, CusContactFocusNode),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade300, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: Colors.black, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: textStyle),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Text("Contact", style: commonLabelTextStyle),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.3,
                  child: Container(
                    height: 24,
                    width: Responsive.isDesktop(context)
                        ? desktoptextfeildwidth
                        : MediaQuery.of(context).size.width * 0.2,
                    color: Colors.grey[100],
                    child: TextFormField(
                        controller: TableContactController,
                        focusNode: CusContactFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, CusContactFocusNode, CusAddressFocusNode),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade300, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: Colors.black, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: textStyle),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 10),
        Container(
          // color:subcolor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 0, top: 8),
                child: Text("Address", style: commonLabelTextStyle),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 5, top: 8),
                child: Container(
                  height: 24,
                  width: Responsive.isDesktop(context)
                      ? desktopcontainerdwidth
                      : MediaQuery.of(context).size.width * 0.3,
                  child: Container(
                    height: 24,
                    width: Responsive.isDesktop(context)
                        ? desktoptextfeildwidth
                        : MediaQuery.of(context).size.width * 0.2,
                    color: Colors.grey[100],
                    child: TextFormField(
                        controller: TableAddressController,
                        focusNode: CusAddressFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, CusAddressFocusNode, codeFocusNode),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade300, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                BorderSide(color: Colors.black, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: textStyle),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildTableButton(String name, List<String> codes, String tableCode) {
    List<Widget> buttonRows = [];
    List<Widget> currentRow = [];
    int buttonsPerRow = Responsive.isDesktop(context)
        ? 5
        : Responsive.isTablet(context)
            ? 5
            : 2;

    for (int i = 0; i < codes.length; i++) {
      currentRow.add(
        Padding(
          padding: EdgeInsets.only(
              top: Responsive.isDesktop(context) ? 10 : 10,
              left: Responsive.isDesktop(context) ? 10 : 3,
              right: Responsive.isDesktop(context) ? 10 : 3,
              bottom: Responsive.isDesktop(context) ? 10 : 2),
          child: Container(
            child: Column(
              children: [
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: prefs.containsKey('table_${codes[i]}')
                        ? MaterialStateProperty.all<Color>(
                            Color.fromARGB(255, 62, 67, 85))
                        : MaterialStateProperty.all<Color>(
                            Color.fromARGB(255, 255, 255, 255)),
                    elevation: MaterialStateProperty.all<double>(
                        4), // Set elevation here
                  ),
                  onPressed: () {
                    _loadSavedData();
                    setState(() {
                      selectedCode = codes[i]; // Update selected code
                      showTableNo =
                          true; // Show the Table No container when button is clicked
                    });
                  },
                  child: Padding(
                    padding:
                        EdgeInsets.all(Responsive.isDesktop(context) ? 10 : 2),
                    child: Container(
                      child: Column(
                        children: [
                          Image.asset(
                              prefs.containsKey('table_${codes[i]}')
                                  ? 'assets/imgs/reservetable.png'
                                  : 'assets/imgs/table.png',
                              height: 25,
                              width: 25,
                              color: prefs.containsKey('table_${codes[i]}')
                                  ? Colors.white
                                  : Color.fromARGB(255, 62, 67, 85)),
                          SizedBox(height: 0),
                          Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: Text(
                              prefs.containsKey('table_${codes[i]}')
                                  ? 'Reserved'
                                  : 'Available Seat',
                              style: TextStyle(
                                  fontSize: 10,
                                  color: prefs.containsKey('table_${codes[i]}')
                                      ? Colors.white
                                      : Color.fromARGB(255, 62, 67, 85)),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: Text(
                              codes[i],
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: prefs.containsKey('table_${codes[i]}')
                                      ? Colors.white
                                      : Color.fromARGB(255, 62, 67, 85)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // Divider(height: 2, color: Colors.grey),
                // ElevatedButton(
                //   style: ButtonStyle(
                //     backgroundColor: prefs.containsKey('table_${codes[i]}')
                //         ? MaterialStateProperty.all<Color>(Colors.brown)
                //         : MaterialStateProperty.all<Color>(
                //             Color.fromARGB(255, 62, 67, 85)),
                //   ),
                //   onPressed: () {
                //     _loadSavedData();
                //     setState(() {
                //       selectedCode = codes[i]; // Update selected code
                //       showTableNo =
                //           true; // Show the Table No container when button is clicked
                //     });
                //   },
                //   child: Padding(
                //       padding: const EdgeInsets.only(
                //           left: 9, right: 9, top: 0, bottom: 4),
                //       child: Icon(
                //         prefs.containsKey('table_${codes[i]}')
                //             ? Icons.person_outline_sharp
                //             : Icons.lock_open_outlined,
                //         size: 14,
                //         color: Colors.white,
                //       )),
                // ),
              ],
            ),
          ),
        ),
      );

      // Add current row to buttonRows when the row is filled or at the end of the loop
      if ((i + 1) % buttonsPerRow == 0 || i == codes.length - 1) {
        buttonRows.add(
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: currentRow,
          ),
        );
        currentRow = []; // Reset current row
      }
    }

    return Column(
      children: [
        Text(
          name,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 16),
        if (!showTableNo)
          ...buttonRows, // Render button rows only when showTableNo is false
        SizedBox(height: 16),
      ],
    );
  }

  List<Map<String, dynamic>> salestableData = [];

  List<Map<String, dynamic>> finalsalestableData = [];

  void saveData() {
    // Check if any required field is empty
    if (SCodeController.text.isEmpty ||
        SNameController.text.isEmpty ||
        TableItemController.text.isEmpty ||
        TableAmountController.text.isEmpty ||
        TableQuantityController.text.isEmpty) {
      // Show error message
      WarninngMessage(context);
      return;
    } else if (widget.SalesPaytype.text.toLowerCase() == 'credit' &&
        TableCusNameController.text.isEmpty) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Check Details'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text(
                'Kindly enter the Customer Details , when you select Paytype Credit'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(codeFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else if (TableQuantityController.text == '0' ||
        TableQuantityController.text == '') {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Quantity Check'),
              IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
          content: Container(
            width: 330,
            child: Text('Kindly enter the quantity , Quantity must above 0'),
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    FocusScope.of(context).requestFocus(quantityFocusNode);
                  },
                  child: Text('Ok'),
                ),
              ],
            ),
          ],
        ),
      );
    } else {
      String productName = TableItemController.text;
      String amount = TableAmountController.text;
      String makingcost = TableProdutMakingCostController.text;
      String category = TableProdutCategoryController.text;

      String quantity = TableQuantityController.text;
      // Extract required details from controllers
      String totalamt = FinalAmtController.text;

      String taxable = Taxableamountcontroller.text;
      // print("final amount :${FinalAmtController.text}");

      String cgstPercentage =
          SalesGstMethodController.text.isEmpty ? "0" : CGSTperccontroller.text;

      String cgstAmount =
          SalesGstMethodController.text.isEmpty ? "0" : CGSTAmtController.text;
      String sgstPercentage =
          SalesGstMethodController.text.isEmpty ? "0" : SGSTPercController.text;
      String sgstAmount =
          SalesGstMethodController.text.isEmpty ? "0" : SGSTAmtController.text;
      bool productExists = false;

      for (var item in salestableData) {
        if (item['productName'] == productName) {
          item['quantity'] =
              (int.parse(item['quantity']) + int.parse(quantity)).toString();

          item['Amount'] =
              (double.parse(item['Amount']) + double.parse(totalamt))
                  .toString();
          item['retail'] =
              (double.parse(item['retail']) + double.parse(taxable)).toString();
          item['cgstAmt'] =
              (double.parse(item['cgstAmt']) + double.parse(cgstAmount))
                  .toString();
          item['sgstAmt'] =
              (double.parse(item['sgstAmt']) + double.parse(sgstAmount))
                  .toString();
          productExists = true;
          break;
        }
      }

      if (!productExists) {
        setState(() {
          salestableData.add({
            'productName': productName,
            'amount': amount,
            'quantity': quantity,
            "cgstAmt": cgstAmount,
            "sgstAmt": sgstAmount,
            "Amount": totalamt,
            "retail": taxable,
            "retailrate": amount,
            "cgstperc": cgstPercentage,
            "sgstperc": sgstPercentage,
            "makingcost": makingcost,
            "category": category,
          });
        });
      }

      setState(() {
        productName = '';
        TableCodeController.clear();
      });

      TableCodeController.clear();
      TableItemController.clear();
      ProductNameSelected = '';
      TableAmountController.clear();
      TableQuantityController.clear();
      FinalAmtController.clear();
    }
  }

  void lastsaveData() {
    // Check if any required field is empty
    if (selectedCode.isEmpty) {
      // Handle empty selectedCode
      return;
    }

    // Extract required details from controllers
    String totalamt = FinalAmtController.text;
    String taxable = Taxableamountcontroller.text;

    // print("final amount lasttable:${FinalAmtController.text}");
    // print("taxable  amount lasttable:${Taxableamountcontroller.text}");

    String cgstPercentage =
        SalesGstMethodController.text.isEmpty ? "0" : CGSTperccontroller.text;

    String cgstAmount =
        SalesGstMethodController.text.isEmpty ? "0" : CGSTAmtController.text;
    String sgstPercentage =
        SalesGstMethodController.text.isEmpty ? "0" : SGSTPercController.text;
    String sgstAmount =
        SalesGstMethodController.text.isEmpty ? "0" : SGSTAmtController.text;

    setState(() {
      // Iterate through salestableData and save only the required fields with the provided table number
      for (var data in salestableData) {
        finalsalestableData.add({
          'TableNo': selectedCode,
          'productName': data[
              'productName'], // Assuming 'productName' is a key in salestableData
          'amount':
              data['amount'], // Assuming 'amount' is a key in salestableData
          'quantity': data[
              'quantity'], // Assuming 'quantity' is a key in salestableData
          "cgstAmt": cgstAmount,
          "sgstAmt": sgstAmount,
          "Amount": data['Amount'],
          "retail": taxable,
          "retailrate": data['amount'],
          'cgstperc': cgstPercentage,
          'sgstperc': sgstPercentage,
          'makingcost': data['makingcost'],
          'category': data['category'],
        });
      }
    });

    // Clear salestableData after saving required data
    salestableData.clear();
  }

  Future<void> _printResult() async {
    try {
      DateTime currentDate = DateTime.now();
      DateTime currentDatetime = DateTime.now();
      String formattedDate = DateFormat('dd.MM.yyyy').format(currentDate);
      String formattedDateTime = DateFormat('hh:mm a').format(currentDatetime);
      String tableno = TableNoController.text;
      String serventName = SNameController.text;
      String date = formattedDate;
      String time = formattedDateTime;

      List<String> productDetails = [];
      for (var data in salestableData) {
        productDetails.add("${data['productName']}-${data['quantity']}");
      }
      getKitchenPrinterProducts();
      String productDetailsString = productDetails.join(",");
      print("product details : $productDetailsString");
      print(
          "$IpAddress/KitchenSalesPrint3Inch/$tableno-$serventName-$date-$time/$productDetailsString");
      final response = await http.get(Uri.parse(
          '$IpAddress/KitchenSalesPrint3Inch/$tableno-$serventName-$date-$time/$productDetailsString'));

      if (response.statusCode == 200) {
        // If the server returns a 200 OK response, print the response body.
        print('Response: ${response.body}');
      } else {
        // If the server did not return a 200 OK response, print the status code.
        print('Failed with status code: ${response.statusCode}');
      }
    } catch (e) {
      // Handle any potential errors.
      print('Error: $e');
    }
  }

  Future<List<String>> getKitchenPrinterProducts() async {
    String? cusid = await SharedPrefs.getCusId();
    final categoryUrl = '$IpAddress/Settings_ProductCategory/$cusid/';
    List<String> kitchenPrinterProducts = [];
    String? nextUrl = categoryUrl;

    // Fetch categories from all pages
    while (nextUrl != null) {
      try {
        final response = await http.get(Uri.parse(nextUrl));

        if (response.statusCode == 200) {
          final decodedData = json.decode(response.body);
          final List<dynamic> categories = decodedData['results'];

          // Collect product names where type is "KitchenPrinter"
          for (var category in categories) {
            if (category['type'] == 'KitchenPrinter') {
              kitchenPrinterProducts.add(category['cat']);
            }
          }

          nextUrl = decodedData['next'];
        } else {
          throw Exception(
              'Failed to load category data: ${response.statusCode}');
        }
      } catch (e) {
        print('Error fetching data: $e');
        throw Exception('Failed to load category data');
      }
    }

    // Print the list of KitchenPrinter products
    print('Kitchen printer category: $kitchenPrinterProducts');

    return kitchenPrinterProducts;
  }

  void addButtonPressed() {
    saveData(); // Call the saveData function to add data
    setState(() {
      // Trigger a rebuild to reflect the changes in tablesalesview
      tablesalesview();
    });
  }

  void _deleteRow(int index) {
    setState(() {
      salestableData.removeAt(index);
    });
    successfullyDeleteMessage(context);
  }

  void _deleteRowinitemtable(int index) {
    setState(() {
      finalsalestableData.removeAt(index);
    });
    successfullyDeleteMessage(context);
  }

  cleardata() {
    SCodeController.clear();
    SNameController.clear();
    TableCusNameController.clear();
    TableContactController.clear();
    TableAddressController.clear();

    TableCodeController.clear();
    TableItemController.clear();
    ProductNameSelected = '';
    TableAmountController.clear();
    TableQuantityController.clear();
    FinalAmtController.clear();
    finalsalestableData = [];
    salestableData = [];
    String tableno = TableNoController.text;

    deleteTableData(tableno);

    setState(() {
      TableCodeController.clear();
    });
  }

  Closetabledetails() {
    SCodeController.clear();
    SNameController.clear();
    TableCusNameController.clear();
    TableContactController.clear();
    TableAddressController.clear();

    TableCodeController.clear();
    TableItemController.clear();
    ProductNameSelected = '';
    TableAmountController.clear();
    TableQuantityController.clear();
    FinalAmtController.clear();
    finalsalestableData = [];
    salestableData = [];

    setState(() {
      TableCodeController.clear();
    });
  }

  Widget tablesalesview() {
    double screenHeight = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.only(
          left: 0,
          right: 0,
        ),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
            height: Responsive.isDesktop(context) ? screenHeight * 0.39 : 320,
            // height: Responsive.isDesktop(context) ? 260 : 240,
            decoration: BoxDecoration(
              color: Colors.grey[50],
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Container(
                width: Responsive.isDesktop(context)
                    ? MediaQuery.of(context).size.width * 0.3
                    : MediaQuery.of(context).size.width * 0.7,
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 0.0, right: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.fastfood,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 1),
                                  Text("Item",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.currency_exchange_outlined,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Amount",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 300.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add_box,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Qty",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.delete,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Action",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (salestableData.isNotEmpty)
                    ...salestableData.asMap().entries.map((entry) {
                      int index = entry.key;
                      Map<String, dynamic> data = entry.value;
                      var productName = data['productName'].toString();
                      var amount = data['amount'].toString();
                      var quantity = data['quantity'].toString();
                      var cgstAmt = data['cgstAmt'].toString();
                      var sgstAmt = data['sgstAmt'].toString();
                      var Amount = data['Amount'].toString();
                      var retail = data['retail'].toString();
                      var retailrate = data['retailrate'] ?? 0;

                      var cgstperc = data['cgstperc'].toString();
                      var sgstperc = data['sgstperc'] ?? 0;
                      var makingcost = data['makingcost'] ?? 0;
                      var category = data['category'] ?? 0;
                      // print("categoryyyyyyyyyyyyyyy: $category");
                      // print("tablenoooooooooooooo : $TableNo");
                      // print("111productNameaaaaaaaaaaaaaa : $productName");
                      // print("1111111naaaaaaaaaaaaaaaa : $amount");
                      // print("11111111111cgstAmtyyyyyyyyyyyyy : $cgstAmt");
                      // print("111111111111sgstAmtttttttttttttttt : $sgstAmt");
                      // print("111111111Amounttttttttttttttt : $Amount");
                      // print("111111111retailllllllllllllllll : $retail");
                      // print("1111111retailrateaaaaaaaaaaaa : $retailrate");
                      // print("11111111111111cgstperccccccccccccc : $cgstperc");
                      // print("111111111sgstpercscccccccccc : $sgstperc");

                      bool isEvenRow = salestableData.indexOf(data) % 2 == 0;
                      Color? rowColor = isEvenRow
                          ? Color.fromARGB(224, 255, 255, 255)
                          : Color.fromARGB(255, 223, 225, 226);

                      return Padding(
                        padding: const EdgeInsets.only(left: 0.0, right: 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(productName,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(amount,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(quantity,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 255.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          child: IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              _showDeleteConfirmationDialog(
                                                  index);
                                            },
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList()
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget tablesalesviewtableNo() {
    double screenHeight = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.only(
          left: 0,
          right: 0,
        ),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
            height: Responsive.isDesktop(context) ? screenHeight * 0.39 : 320,
            decoration: BoxDecoration(
              color: Colors.grey[50],
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 2,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Container(
                width: Responsive.isDesktop(context)
                    ? MediaQuery.of(context).size.width * 0.3
                    : MediaQuery.of(context).size.width * 0.7,
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 0.0, right: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: Responsive.isDesktop(context) ? 265 : 300,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.note_alt_rounded,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("T.No",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add_box,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Item",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.currency_exchange_outlined,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Amt",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.add_box,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Qty",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            height: Responsive.isDesktop(context) ? 25 : 30,
                            width: 265.0,
                            decoration: TableHeaderColor,
                            child: Center(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.delete,
                                    size: 15,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 5),
                                  Text("Action",
                                      textAlign: TextAlign.center,
                                      style: commonLabelTextStyle),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (finalsalestableData.isNotEmpty)
                    ...finalsalestableData.asMap().entries.map((entry) {
                      int index = entry.key;
                      Map<String, dynamic> data = entry.value;
                      var TableNo = data['TableNo'].toString();

                      var productName = data['productName'].toString();
                      var amount = data['amount'].toString();
                      var quantity = data['quantity'].toString();
                      var cgstAmt = data['cgstAmt'].toString();
                      var sgstAmt = data['sgstAmt'].toString();
                      var Amount = data['Amount'].toString();
                      var retail = data['retail'].toString();
                      var retailrate = data['retailrate'] ?? 0;

                      var cgstperc = data['cgstperc'].toString();
                      var sgstperc = data['sgstperc'] ?? 0;
                      var makingcost = data['makingcost'] ?? 0;
                      var category = data['category'] ?? 0;
                      // print("categoryyy11111111: $category");
                      // print("tablenoooooooooooooo : $TableNo");
                      // print("productNameaaaaaaaaaaaaaa : $productName");
                      // print("naaaaaaaaaaaaaaaa : $amount");
                      // print("cgstAmtyyyyyyyyyyyyy : $cgstAmt");
                      // print("sgstAmtttttttttttttttt : $sgstAmt");
                      // print("Amounttttttttttttttt : $Amount");
                      // print("retailllllllllllllllll : $retail");
                      // print("retailrateaaaaaaaaaaaa : $retailrate");
                      // print("cgstperccccccccccccc : $cgstperc");
                      // print("sgstpercscccccccccc : $sgstperc");
                      bool isEvenRow =
                          finalsalestableData.indexOf(data) % 2 == 0;
                      Color? rowColor = isEvenRow
                          ? Color.fromARGB(224, 255, 255, 255)
                          : Color.fromARGB(255, 223, 225, 226);

                      return Padding(
                        padding: const EdgeInsets.only(left: 0.0, right: 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(TableNo,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(productName,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(amount,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(quantity,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 255.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Container(
                                          child: IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              _showFinalsalestableDeleteConfirmationDialog(
                                                  index);
                                            },
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList()
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool?> _showDeleteConfirmationDialog(index) async {
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.delete, size: 18),
                  SizedBox(
                    width: 4,
                  ),
                  Text('Confirm Delete',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
              IconButton(
                icon: Icon(Icons.cancel, color: Colors.grey),
                onPressed: () => Navigator.of(context).pop(false),
              ),
            ],
          ),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Are you sure you want to delete this data?',
                style: TextStyle(fontSize: 13),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                _deleteRow(index!);
                Navigator.pop(context);
                successfullyDeleteMessage(context);
              },
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(2.0),
                ),
                backgroundColor: subcolor,
                minimumSize: Size(30.0, 28.0), // Set width and height
              ),
              child: Text('Delete',
                  style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ],
        );
      },
    );
  }

  Future<bool?> _showFinalsalestableDeleteConfirmationDialog(index) async {
    return await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.delete, size: 18),
                  SizedBox(
                    width: 4,
                  ),
                  Text('Confirm Delete',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                ],
              ),
              IconButton(
                icon: Icon(Icons.cancel, color: Colors.grey),
                onPressed: () => Navigator.of(context).pop(false),
              ),
            ],
          ),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Are you sure you want to delete this data?',
                style: TextStyle(fontSize: 13),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                _deleteRowinitemtable(index!);
                Navigator.pop(context);
                successfullyDeleteMessage(context);
              },
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(2.0),
                ),
                backgroundColor: subcolor,
                minimumSize: Size(30.0, 28.0), // Set width and height
              ),
              child: Text('Delete',
                  style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ],
        );
      },
    );
  }
}

class lastbillview extends StatefulWidget {
  const lastbillview({Key? key}) : super(key: key);

  @override
  State<lastbillview> createState() => _lastbillviewState();
}

class _lastbillviewState extends State<lastbillview> {
  @override
  void initState() {
    super.initState();
    fetchData();
    FinallyyyAmounttts.addListener(updateAmount);
  }

  List<Map<String, dynamic>> Purchasedetailstabledata = [];
  Future<void> fetchsalesdetails(Map<String, dynamic> data) async {
    String id = data["id"].toString(); // Convert Id to String
    final url = '$IpAddress/SalesRoundDetailsalldatas/$id';
    print("url : $url");
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final dynamic responseData = json.decode(response.body);

        if (responseData is Map<String, dynamic> &&
            responseData.containsKey('SalesDetails')) {
          try {
            String purchaseDetailsString = responseData['SalesDetails'];
            List<String> purchaseDetailsRecords = purchaseDetailsString
                .split('}{'); // Split by '}{' to separate records
            for (var record in purchaseDetailsRecords) {
              // Clean up the record by removing '{' and '}'
              record = record.replaceAll('{', '').replaceAll('}', '');
              List<String> keyValuePairs = record.split(',');
              Map<String, dynamic> purchaseDetail = {};
              for (var pair in keyValuePairs) {
                List<String> parts = pair.split(':');
                String key = parts[0].trim();
                String value = parts[1].trim();
                // Remove surrounding quotes if any
                if (value.startsWith("'") && value.endsWith("'")) {
                  value = value.substring(1, value.length - 1);
                }
                purchaseDetail[key] = value;
              }
              Purchasedetailstabledata.add({
                'Itemname': purchaseDetail['Itemname'],
                'rate': purchaseDetail['rate'],
                'qty': purchaseDetail['qty'],
                'amount': purchaseDetail['amount'],
                'retail': purchaseDetail['retail'],
              });
            }
            // Print Paymentdetailsamounts after setting state
            // print('purchase Payment Details: $Purchasedetailstabledata');
            Purchasedetails(data);
          } catch (e) {
            throw FormatException('Invalid purchasepaymentdetails format');
          }
        } else {
          throw Exception(
              'Invalid response format: purchasepaymentdetails not found');
        }
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  void Purchasedetails(Map<String, dynamic> data) {
    String timeString =
        data['time'] ?? ''; // Assuming time is present in the data

    // Parse the time string into a DateTime object
    DateTime time = DateTime.parse(timeString);

    // Format the DateTime object to display time in "02:57 PM" format
    String formattedTime = DateFormat('hh:mm a').format(time);

    Future<void> _printResult() async {
      try {
        // Parse 'dt' and 'time' strings into DateTime objects
        DateTime salesdate = DateTime.parse(data['dt']);
        DateTime salestime = DateTime.parse(data['time']);

// Format the DateTime objects as required
        String formattedDate = DateFormat('dd.MM.yyyy').format(salesdate);
        String formattedDateTime = DateFormat('hh:mm a').format(salestime);

        double totalQuantity =
            0.0; // Define total quantity variable outside the loop

        for (var data in Purchasedetailstabledata) {
          // Inside the loop, add each quantity to the totalQuantity variable
          totalQuantity += double.parse(data['qty'].toString());
        }
        String totalQuantityString = totalQuantity.toString();
        String billno = data['billno'];
        String date = formattedDate;
        String paytype = data['paytype'];
        String time = formattedDateTime;
        // String Customername = data['cusname'];
        // String CustomerContact = data['contact'];
        String Tableno = data['tableno'];
        // String tableservent = data['servent'];
        String count = data['count'];
        String totalQty = totalQuantityString;
        String totalamt = data['amount'];
        String discount = data['discount'];
        String FinalAmt = data['finalamount'];
        String Customername;
        if (data['cusname'] == "null") {
          Customername = "";
        } else {
          Customername = data['cusname'];
        }
        String CustomerContact;
        if (data['contact'] == "null") {
          CustomerContact = "";
        } else {
          CustomerContact = data['contact'];
        }

        String tableservent;
        if (data['servent'] == "null") {
          tableservent = "";
        } else {
          tableservent = data['servent'];
        }

        String sgst25;
        if (data['cgst25'] == "0.0") {
          sgst25 = "";
        } else {
          sgst25 = data['cgst25'];
        }
        String sgst6;
        if (data['cgst6'] == "0.0") {
          sgst6 = "";
        } else {
          sgst6 = data['cgst6'];
        }
        String sgst9;
        if (data['cgst9'] == "0.0") {
          sgst9 = "";
        } else {
          sgst9 = data['cgst9'];
        }
        String sgst14;
        if (data['cgst14'] == "0.0") {
          sgst14 = "";
        } else {
          sgst14 = data['cgst14'];
        }

        List<String> productDetails = [];
        for (var data in Purchasedetailstabledata) {
          // Format each product detail as "{productName},{amount}"
          productDetails.add(
              "${data['Itemname'].toString()}-${data['rate'].toString()}-${data['qty'].toString()}");
        }

        String productDetailsString = productDetails.join(',');
        // print("product details : $productDetailsString   ");
        // print(
        //     "billno : $billno   , date : $date ,  paytype : $paytype ,    time :$time    ,customername : $Customername,  customercontact : $CustomerContact  ,    table No : $Tableno,   Tableservent : $tableservent,    total count :  $count,  total qty : $totalQty,    totalamt : $totalamt,    discount amt : $discount,    finalamount:  $FinalAmt");
        print(
            "url : $IpAddress/SalesPrint3Inch/$billno-$date-$paytype-$time/$Customername-$CustomerContact/$Tableno-$tableservent/$count-$totalQty-$totalamt-$discount-$FinalAmt-$sgst25-$sgst6-$sgst9-$sgst14/$productDetailsString");

        print(
            "sgst25 : $sgst25  ,  sgst6 :   $sgst6 , sgst 9 :   $sgst9  ,   sgst14:   $sgst14");

        final response = await http.get(Uri.parse(
            '$IpAddress/SalesPrint3Inch/$billno-$date-$paytype-$time/$Customername-$CustomerContact/$Tableno-$tableservent/$count-$totalQty-$totalamt-$discount-$FinalAmt-$sgst25-$sgst6-$sgst9-$sgst14/$productDetailsString'));

        if (response.statusCode == 200) {
          // If the server returns a 200 OK response, print the response body.
          print('Response: ${response.body}');
        } else {
          // If the server did not return a 200 OK response, print the status code.
          print('Failed with status code: ${response.statusCode}');
        }
      } catch (e) {
        // Handle any potential errors.
        print('Error: $e');
      }
    }

    showDialog(
      context: context,
      builder: (context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sales Details'),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    icon: const Icon(Icons.cancel, color: Colors.red),
                    onPressed: () {
                      Purchasedetailstabledata = [];
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                Responsive.isDesktop(context)
                    ? Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'BillNo',
                                style: TextStyle(fontSize: 14),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: Responsive.isDesktop(context)
                                    ? 100
                                    : MediaQuery.of(context).size.width * 0.3,
                                child: Container(
                                  height: 27,
                                  width: 100,
                                  color: Colors.grey[200],
                                  child: TextField(
                                    readOnly: true,
                                    controller: TextEditingController(
                                        text: data['billno'] ?? ''),
                                    onChanged: (newValue) {
                                      // BillnoController.text = newValue;
                                    },
                                    decoration: InputDecoration(
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 4.0,
                                        horizontal: 7.0,
                                      ),
                                    ),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 20),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Customer Name',
                                style: TextStyle(fontSize: 14),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: Responsive.isDesktop(context)
                                    ? 150
                                    : MediaQuery.of(context).size.width * 0.25,
                                child: Container(
                                  height: 29,
                                  width: 100,
                                  color: Colors.grey[200],
                                  child: TextField(
                                    readOnly: true,
                                    controller: TextEditingController(
                                        text: data['cusname'] ?? ''),
                                    onChanged: (newValue) {
                                      // BillnoController.text = newValue;
                                    },
                                    decoration: InputDecoration(
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 4.0,
                                        horizontal: 7.0,
                                      ),
                                    ),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 20),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Time',
                                style: TextStyle(fontSize: 14),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: Responsive.isDesktop(context)
                                    ? 100
                                    : MediaQuery.of(context).size.width * 0.3,
                                child: Container(
                                  height: 27,
                                  width: 100,
                                  color: Colors.grey[200],
                                  child: TextField(
                                    readOnly: true,
                                    controller: TextEditingController(
                                        text: formattedTime ?? ''),
                                    onChanged: (newValue) {
                                      // BillnoController.text = newValue;
                                    },
                                    decoration: InputDecoration(
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 4.0,
                                        horizontal: 7.0,
                                      ),
                                    ),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 20),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Table No',
                                style: TextStyle(fontSize: 14),
                              ),
                              SizedBox(height: 5),
                              Container(
                                width: Responsive.isDesktop(context)
                                    ? 150
                                    : MediaQuery.of(context).size.width * 0.25,
                                child: Container(
                                  height: 29,
                                  width: 100,
                                  color: Colors.grey[200],
                                  child: TextField(
                                    readOnly: true,
                                    controller: TextEditingController(
                                        text: data['tableno'] ?? ''),
                                    onChanged: (newValue) {
                                      // BillnoController.text = newValue;
                                    },
                                    decoration: InputDecoration(
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.white, width: 1.0),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 4.0,
                                        horizontal: 7.0,
                                      ),
                                    ),
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    : Column(
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'BillNo',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                  SizedBox(height: 5),
                                  Container(
                                    width: Responsive.isDesktop(context)
                                        ? 100
                                        : MediaQuery.of(context).size.width *
                                            0.3,
                                    child: Container(
                                      height: 27,
                                      width: 100,
                                      color: Colors.grey[200],
                                      child: TextField(
                                        readOnly: true,
                                        controller: TextEditingController(
                                            text: data['billno'] ?? ''),
                                        onChanged: (newValue) {
                                          // BillnoController.text = newValue;
                                        },
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 7.0,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(width: 20),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Customer Name',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                  SizedBox(height: 5),
                                  Container(
                                    width: Responsive.isDesktop(context)
                                        ? 150
                                        : MediaQuery.of(context).size.width *
                                            0.25,
                                    child: Container(
                                      height: 29,
                                      width: 100,
                                      color: Colors.grey[200],
                                      child: TextField(
                                        readOnly: true,
                                        controller: TextEditingController(
                                            text: data['cusname'] ?? ''),
                                        onChanged: (newValue) {
                                          // BillnoController.text = newValue;
                                        },
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 7.0,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Time',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                  SizedBox(height: 5),
                                  Container(
                                    width: Responsive.isDesktop(context)
                                        ? 100
                                        : MediaQuery.of(context).size.width *
                                            0.3,
                                    child: Container(
                                      height: 27,
                                      width: 100,
                                      color: Colors.grey[200],
                                      child: TextField(
                                        readOnly: true,
                                        controller: TextEditingController(
                                            text: formattedTime ?? ''),
                                        onChanged: (newValue) {
                                          // BillnoController.text = newValue;
                                        },
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 7.0,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(width: 20),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Table No',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                  SizedBox(height: 5),
                                  Container(
                                    width: Responsive.isDesktop(context)
                                        ? 150
                                        : MediaQuery.of(context).size.width *
                                            0.25,
                                    child: Container(
                                      height: 29,
                                      width: 100,
                                      color: Colors.grey[200],
                                      child: TextField(
                                        readOnly: true,
                                        controller: TextEditingController(
                                            text: data['tableno'] ?? ''),
                                        onChanged: (newValue) {
                                          // BillnoController.text = newValue;
                                        },
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white,
                                                width: 1.0),
                                          ),
                                          contentPadding: EdgeInsets.symmetric(
                                            vertical: 4.0,
                                            horizontal: 7.0,
                                          ),
                                        ),
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left: 5, right: 5),
                  child: SingleChildScrollView(
                    child: Container(
                      height: Responsive.isDesktop(context) ? 350 : 350,
                      width: MediaQuery.of(context).size.width * 0.7,
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                      ),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 10.0, right: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Item Name",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Rate",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Quantity",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Total Retail",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Total Amount",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        height: 25,
                                        decoration: BoxDecoration(
                                          color: maincolor,
                                          border: Border.all(
                                            color: Colors.black,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            "Retail Rate",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (Purchasedetailstabledata.isNotEmpty)
                                ...Purchasedetailstabledata.asMap()
                                    .entries
                                    .map((entry) {
                                  int index = entry.key;
                                  Map<String, dynamic> data = entry.value;
                                  var Itemname = data['Itemname'].toString();
                                  var rate = data['rate'].toString();

                                  var retailrate = data['retail'].toString();
                                  var qty = data['qty'].toString();
                                  var amount = data['amount'].toString();

                                  bool isEvenRow = index % 2 ==
                                      0; // Using index for row color
                                  Color? rowColor = isEvenRow
                                      ? Color.fromARGB(224, 255, 255, 255)
                                      : Color.fromARGB(224, 255, 255, 255);

                                  return Padding(
                                    padding: const EdgeInsets.only(
                                      left: 10.0,
                                      right: 10,
                                      bottom: 5.0,
                                      top: 5.0,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                Itemname,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                rate,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                qty,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                retailrate,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                amount,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            height: 30,
                                            decoration: BoxDecoration(
                                              color: rowColor,
                                              border: Border.all(
                                                color: Color.fromARGB(
                                                    255, 226, 225, 225),
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                rate,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList()
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        _printResult();
                      },
                      style: ElevatedButton.styleFrom(
                        primary: subcolor,
                        padding: EdgeInsets.only(left: 7, right: 7),
                      ),
                      child: Text(
                        "Print",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        primary: subcolor,
                        padding: EdgeInsets.only(left: 7, right: 7),
                      ),
                      child: Text(
                        "Preview",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        primary: subcolor,
                        padding: EdgeInsets.only(left: 7, right: 7),
                      ),
                      child: Text(
                        "Close",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  // @override
  // void dispose() {
  //   FinallyyyAmounttts.removeListener(updateAmount);
  //   FinallyyyAmounttts.dispose();
  //   super.dispose();
  // }

  void updateAmount() {
    setState(() {}); // Update the UI when FinallyyyAmounttts changes
  }

  Future<void> fetchData() async {
    String startdt = DateFormat('yyyy-MM-dd').format(DateTime.now());
    String enddt = DateFormat('yyyy-MM-dd').format(DateTime.now());
    // Parse start and end dates
    DateTime startDate = DateFormat('yyyy-MM-dd').parse(startdt);
    DateTime endDate = DateFormat('yyyy-MM-dd').parse(enddt);

    // Add one day to the end date
    endDate = endDate.add(Duration(days: 1));

    String? cusid = await SharedPrefs.getCusId();
    // Format the dates to string
    String formattedStartDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
    String formattedEndDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
    print("startdt = $formattedStartDate end date = $formattedEndDate");
    final response = await http.get(Uri.parse(
        '$IpAddress/DatewiseSalesReport/$cusid/$formattedStartDate/$formattedEndDate/'));
    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      setState(() {
        tableData = List<Map<String, dynamic>>.from(jsonData);
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenwidth = MediaQuery.of(context).size.width;
    return Container(
        width: Responsive.isDesktop(context)
            ? screenwidth
            : MediaQuery.of(context).size.width * 0.8,
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // if (Responsive.isDesktop(context))
            //   Padding(
            //     padding: const EdgeInsets.only(left: 0, top: 3),
            //     child: Container(
            //       height: 35,
            //       width: Responsive.isDesktop(context)
            //           ? 260
            //           : MediaQuery.of(context).size.width * 0.75,
            //       color: Color.fromARGB(255, 225, 225, 225),
            //       child: Row(
            //         crossAxisAlignment: CrossAxisAlignment.start,
            //         mainAxisAlignment: MainAxisAlignment.start,
            //         children: [
            //           Padding(
            //             padding: EdgeInsets.only(
            //                 left: Responsive.isDesktop(context) ? 0 : 0,
            //                 top: 0),
            //             child: Container(
            //               width: Responsive.isDesktop(context) ? 70 : 70,
            //               height: 35,
            //               child: ElevatedButton(
            //                 onPressed: () {
            //                   // Handle form submission
            //                 },
            //                 style: ElevatedButton.styleFrom(
            //                   shape: RoundedRectangleBorder(
            //                     borderRadius: BorderRadius.circular(2.0),
            //                   ),
            //                   backgroundColor: subcolor,
            //                   minimumSize:
            //                       Size(45.0, 31.0), // Set width and height
            //                 ),
            //                 child: Text(
            //                   'RS. ',
            //                   style: TextStyle(
            //                     color: Colors.white,
            //                     fontSize: 18,
            //                   ),
            //                 ),
            //               ),
            //             ),
            //           ),
            //           Padding(
            //             padding: EdgeInsets.only(
            //                 left: Responsive.isDesktop(context) ? 20 : 20,
            //                 top: 11),
            //             child: Container(
            //               width: Responsive.isDesktop(context) ? 85 : 85,
            //               child: Container(
            //                 height: 24,
            //                 width: 100,
            //                 child: Text(
            //                   "${NumberFormat.currency(symbol: '', decimalDigits: 0).format(double.tryParse(FinallyyyAmounttts.text ?? '0') ?? 0)} /-",
            //                   style: TextStyle(
            //                     color: Colors.black,
            //                     fontSize: 16,
            //                     fontWeight: FontWeight.w700,
            //                   ),
            //                 ),
            //               ),
            //             ),
            //           ),
            //         ],
            //       ),
            //     ),
            //   ),
            // SizedBox(height: 15),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 20, left: 20),
                  child: Text(
                    "Last Bill",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            tableView(),
            SizedBox(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  // color: Colors.green,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            left: Responsive.isDesktop(context) ? 20 : 0,
                            top: 0),
                        child: Container(
                          child: ElevatedButton(
                            onPressed: () {
                              // Handle form submission
                            },
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                              ),
                              backgroundColor: subcolor,
                              minimumSize:
                                  Size(45.0, 31.0), // Set width and height
                            ),
                            child: Text(
                              'New Sales',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 15),
                Container(
                  // color: Colors.green,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            left: Responsive.isDesktop(context) ? 20 : 0,
                            top: 0),
                        child: Container(
                          child: ElevatedButton(
                            onPressed: () {
                              // Handle form submission
                            },
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                              ),
                              backgroundColor: subcolor,
                              minimumSize:
                                  Size(45.0, 31.0), // Set width and height
                            ),
                            child: Text(
                              'Printer Details',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  List<Map<String, dynamic>> tableData = [];
  double totalAmount = 0.0;

  Widget tableView() {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenwidth = MediaQuery.of(context).size.width;

    return Padding(
      padding: const EdgeInsets.only(
        left: 0,
        right: 0,
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          height: Responsive.isDesktop(context) ? screenHeight * 0.65 : 320,
          // height: Responsive.isDesktop(context) ? 380 : 240,
          width: Responsive.isDesktop(context)
              ? MediaQuery.of(context).size.width * 0.23
              : MediaQuery.of(context).size.width,

          decoration: BoxDecoration(
            color: Colors.grey[50],
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Container(
              width: Responsive.isDesktop(context)
                  ? screenwidth * 0.23
                  : MediaQuery.of(context).size.width * 0.8,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.only(left: 0.0, right: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Container(
                          height: 25,
                          decoration: TableHeaderColor,
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.notes_rounded,
                                    size: 15, color: Colors.blue),
                                SizedBox(
                                  width: 5,
                                ),
                                Text("Bill No",
                                    textAlign: TextAlign.center,
                                    style: commonLabelTextStyle),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          height: 25,
                          decoration: TableHeaderColor,
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.attach_money,
                                    size: 15, color: Colors.blue),
                                SizedBox(
                                  width: 5,
                                ),
                                Text("Amount",
                                    textAlign: TextAlign.center,
                                    style: commonLabelTextStyle),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (tableData.isNotEmpty)
                  ...tableData.asMap().entries.map((entry) {
                    int index = entry.key;

                    Map<String, dynamic> data = entry.value;
                    var id = data['id'].toString();

                    var billno = data['billno'].toString();
                    var amount = data['amount'].toString();
                    bool isEvenRow = tableData.indexOf(data) % 2 == 0;
                    Color? rowColor = isEvenRow
                        ? Color.fromARGB(224, 255, 255, 255)
                        : Color.fromARGB(255, 223, 225, 226);

                    return Padding(
                      padding: const EdgeInsets.only(left: 0.0, right: 0),
                      child: GestureDetector(
                        onTap: () {
                          // purchasePaymentDetails(data);
                          fetchsalesdetails(data);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(billno,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Container(
                                height: 30,
                                width: 265.0,
                                decoration: BoxDecoration(
                                  color: rowColor,
                                  border: Border.all(
                                    color: Color.fromARGB(255, 226, 225, 225),
                                  ),
                                ),
                                child: Center(
                                  child: Text(amount,
                                      textAlign: TextAlign.center,
                                      style: TableRowTextStyle),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList()
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class finalamount extends StatefulWidget {
  final TextEditingController finalAmount;

  const finalamount({Key? key, required this.finalAmount}) : super(key: key);

  @override
  _finalamountState createState() => _finalamountState();

  static _finalamountState? of(BuildContext context) =>
      context.findAncestorStateOfType<_finalamountState>();

  void updateFinalAmountforall(String text) {}
}

class _finalamountState extends State<finalamount> {
  TextEditingController _finalAmount = TextEditingController();

  @override
  void initState() {
    super.initState();
    _finalAmount = widget.finalAmount;
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.only(left: 0, top: 15),
      child: Container(
        width: screenWidth * 0.18,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              child: Container(
                height: 45,
                width: screenWidth * 0.15,
                color: Color.fromARGB(255, 225, 225, 225),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          left: Responsive.isDesktop(context) ? 0 : 0, top: 0),
                      child: Container(
                        width: screenWidth * 0.045,
                        height: 45,
                        child: ElevatedButton(
                          onPressed: () {
                            // Handle button action
                          },
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(2.0),
                            ),
                            backgroundColor: subcolor,
                            minimumSize: Size(45.0, 31.0),
                          ),
                          child: Text(
                            'RS. ',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: Responsive.isDesktop(context) ? 20 : 20,
                          top: 11),
                      child: Container(
                        width: screenWidth * 0.08,
                        child: Container(
                          height: 24,
                          width: 100,
                          child: Text(
                            "${NumberFormat.currency(symbol: '', decimalDigits: 0).format(double.tryParse(_finalAmount.text) ?? 0)} /-",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
