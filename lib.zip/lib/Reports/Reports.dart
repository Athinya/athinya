import 'package:flutter/material.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';
import 'package:product_restaurantapp/Reports/Others/DaySheetReport.dart';
import 'package:product_restaurantapp/Reports/Others/ProductCodeFinder.dart';
import 'package:product_restaurantapp/Reports/Others/UsageReport.dart';
import 'package:product_restaurantapp/Reports/Others/WastageReport.dart';
import 'package:product_restaurantapp/Reports/Purchase/AgentwiseReport.dart';
import 'package:product_restaurantapp/Reports/Purchase/PurchaseLedgerreport.dart';
import 'package:product_restaurantapp/Reports/Purchase/PurchaseReport.dart';
import 'package:product_restaurantapp/Reports/Purchase/RawMaterialStockReport.dart';
import 'package:product_restaurantapp/Reports/Sales/BillWiseSalesCountReport.dart';
import 'package:product_restaurantapp/Reports/Sales/DailySalesDetails.dart';
import 'package:product_restaurantapp/Reports/Sales/CustomerSalesReport.dart';
import 'package:product_restaurantapp/Reports/Sales/OrderSalesReport.dart';
import 'package:product_restaurantapp/Reports/Sales/PaymentTypeReport.dart';
import 'package:product_restaurantapp/Reports/Sales/ProductSalesCountReport.dart';
import 'package:product_restaurantapp/Reports/Sales/SalesAuditingreport.dart';
import 'package:product_restaurantapp/Reports/Sales/SalesLedgerreport.dart';
import 'package:product_restaurantapp/Reports/Sales/SalesReport.dart';
import 'package:product_restaurantapp/Reports/Sales/ServantSales.dart';
import 'package:product_restaurantapp/Reports/Sales/VendorSalesReport.dart';
import 'package:product_restaurantapp/Reports/Stock/OverAllStockReport.dart';
import 'package:product_restaurantapp/Reports/Stock/ProductStock.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({Key? key}) : super(key: key);

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  String searchText = '';

  List<Map<String, dynamic>> getFilteredData(
      List<Map<String, dynamic>> tableData, String key) {
    if (searchText.isEmpty) {
      return tableData;
    }

    return tableData
        .where((data) =>
            (data[key] ?? '').toLowerCase().contains(searchText.toLowerCase()))
        .toList();
  }

  List<Map<String, dynamic>> tableDatasales = [
    {'sales': 'Sales Report'},
    {'sales': 'Daily Sales Details'},
    {'sales': 'CustomerWise Sales Report'},
    {'sales': 'Product Sales Count'},
    {'sales': 'Billwise Sales Count'},
    {'sales': 'Payment Type'},
    {'sales': 'Servant Sales'},
    {'sales': 'Sales Ledger'},
    {'sales': 'Sales Auditing'},
    {'sales': 'Order Sales'},
    {'sales': 'Vendor Sales'},
  ];

  List<Map<String, dynamic>> tableDatapurchase = [
    {'purchase': 'Purchase Report'},
    {'purchase': 'Agentwise Report'},
    {'purchase': 'Purchase Ledger Report'},
  ];

  List<Map<String, dynamic>> tableDataOthers = [
    {'others': 'Wastage Report'},
    {'others': 'Usage Report'},
    {'others': 'DaySheet Report'},
    {'others': 'Product Code Finder'},
  ];
  List<Map<String, dynamic>> tableDataStock = [
    {'Stock': 'OverAll Stock'},
    {'Stock': 'Product Stock'},
  ];

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredSalesData =
        getFilteredData(tableDatasales, 'sales');
    List<Map<String, dynamic>> filteredPurchaseData =
        getFilteredData(tableDatapurchase, 'purchase');
    List<Map<String, dynamic>> filteredOthersData =
        getFilteredData(tableDataOthers, 'others');
    List<Map<String, dynamic>> filteredStockData =
        getFilteredData(tableDataStock, 'Stock');

    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Reports',
                style: TextStyle(
                  fontSize: 15,
                ),
              ),
              SizedBox(height: 5),
              Divider(color: Colors.grey[300], thickness: 2),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: 24,
                    width: 130,
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          searchText = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Search',
                        suffixIcon: Icon(
                          Icons.search,
                          color: Colors.grey,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.grey, width: 1.0),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.grey, width: 1.0),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        contentPadding: EdgeInsets.only(left: 10.0, right: 4.0),
                      ),
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  buildTable('Sales', filteredSalesData),
                                ],
                              ),
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  buildTable('Purchase', filteredPurchaseData),
                                  SizedBox(height: 10),
                                  buildTable('Others', filteredOthersData),
                                ],
                              ),
                            ),
                            SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  buildTable('Stock', filteredStockData),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color getSectionColor(String title) {
    switch (title) {
      case 'Sales':
        return Colors.blue.withOpacity(0.3);
      case 'Purchase':
        return Colors.purple.withOpacity(0.3);
      case 'Stock':
        return Colors.yellow.withOpacity(0.5);
      case 'Others':
        return Colors.red.withOpacity(0.3);
      default:
        return Colors.orange.withOpacity(0.3); // Default color for 'Others'
    }
  }

  Widget buildTable(String title, List<Map<String, dynamic>> data) {
    Color containerColor = getSectionColor(title); // Get color based on title

    return Container(
      margin: EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: maincolor,
            ),
          ),
          SizedBox(height: 5),
          if (data.isNotEmpty)
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: data.length,
                itemBuilder: (context, index) {
                  var value = data[index].values.first.toString();
                  bool isEvenRow = index % 2 == 0;

                  return Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        hoverColor: Colors.grey.shade200,
                        focusColor: Colors.grey.shade200,
                        onTap: () {
                          // Add navigation logic here
                          navigateToReportDetails(title, value);
                        },
                        child: Container(
                          margin: EdgeInsets.symmetric(vertical: 5),
                          padding: EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: containerColor,
                            border: Border.all(
                                color: Color.fromARGB(255, 226, 225, 225)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            value,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  String _selectedContent = ''; // Define _selectedContent here

  void _onReportSelected(String content) {
    setState(() {
      _selectedContent = content;
    });
  }

  void navigateToReportDetails(String title, String value) {
// Sales Report
    if (value == 'Sales Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: Salesreport(),
          );
        },
      );
    } else if (value == 'CustomerWise Sales Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: CustomerWiseReports(),
          );
        },
      );
    } else if (value == 'Daily Sales Details') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: DailySalesDetailsReport(),
          );
        },
      );
    } else if (value == 'Product Sales Count') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: ProductSalesCountReport(),
          );
        },
      );
    } else if (value == 'Billwise Sales Count') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: BillWiseSalesCountReport(),
          );
        },
      );
    } else if (value == 'Payment Type') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: PaymentTypeReport(),
          );
        },
      );
    } else if (value == 'Sales Ledger') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: SalesLedgerReport(),
          );
        },
      );
    } else if (value == 'Sales Auditing') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: SalesAudingReport(),
          );
        },
      );
    } else if (value == 'Servant Sales') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: ServantSalesReport(),
          );
        },
      );
    } else if (value == 'Order Sales') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: OrderSalesReport(),
          );
        },
      );
    } else if (value == 'Vendor Sales') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: VendorSalesReport(),
          );
        },
      );
    }
    //Purchase
    else if (value == 'Purchase Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: Purchasereport(),
          );
        },
      );
    } else if (value == 'Agentwise Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: AgentwisePurchasereport(),
          );
        },
      );
    } else if (value == 'Purchase Ledger Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: PurchaseLedgerReport(),
          );
        },
      );
    }
    //Others
    else if (value == 'Usage Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: UsageReport(),
          );
        },
      );
    } else if (value == 'Wastage Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: WastageReport(),
          );
        },
      );
    } else if (value == 'Product Code Finder') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: ProductCodeFinder(),
          );
        },
      );
    } else if (value == 'DaySheet Report') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: DaysheetReport(),
          );
        },
      );
    }
    //StockReports
    else if (value == 'OverAll Stock') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: AddStockDetailsReport(),
          );
        },
      );
    } else if (value == 'Product Stock') {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            child: ProductStockReport(),
          );
        },
      );
    }
  }
}
