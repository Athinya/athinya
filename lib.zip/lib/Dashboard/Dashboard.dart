import 'package:product_restaurantapp/Database/IpAddress.dart';
import 'package:product_restaurantapp/Modules/Chart.dart';
import 'package:product_restaurantapp/Modules/Responsive.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

class Dashboard extends StatefulWidget {
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: sidebartext,
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            flex: 10,
            child: Padding(
              padding: EdgeInsets.only(left: 5, top: 10),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.home,
                          size: 20,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Dashboard",
                          style: TextStyle(
                            fontSize: 14,
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    if (Responsive.isDesktop(context)) dashboarddesktopview(),
                    if (Responsive.isMobile(context) ||
                        Responsive.isTablet(context))
                      dashboardmobileTabletview()
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      // Wrap your existing SideBar widget in a Drawer
    );
  }
}

class dashboarddesktopview extends StatefulWidget {
  const dashboarddesktopview({Key? key}) : super(key: key);

  @override
  State<dashboarddesktopview> createState() => _dashboarddesktopviewState();
}

class _dashboarddesktopviewState extends State<dashboarddesktopview> {
  @override
  void initState() {
    super.initState();
    fetchSalesTotalAmount();
    fetchOrderSalesTotalAmount();
    fetchPurchaseTotalAmount();
    fetchVendorSalesTotalAmount();
  }

  int totalSalesAmount = 0;

  Future<void> fetchSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var salesFinalAmountToday = data['today_total_sales'];
      double amount = salesFinalAmountToday as double;
      totalSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalSalesAmount = totalSalesAmount;
      });
    }
  }

  int totalOrderSalesAmount = 0;

  Future<void> fetchOrderSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var OrdersalesFinalAmountToday = data['today_order_sales'];
      double amount = OrdersalesFinalAmountToday as double;
      totalOrderSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalOrderSalesAmount = totalOrderSalesAmount;
      });
    }
  }

  int totalPurchaseAmount = 0;

  Future<void> fetchPurchaseTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var purchaseFinalAmountToday = data['today_purchase_sales'];
      double amount = purchaseFinalAmountToday as double;
      totalPurchaseAmount = amount.toInt();
    }

    if (mounted) {
      setState(() {
        totalPurchaseAmount = totalPurchaseAmount;
      });
    }
  }

  int totalVendorSalesAmount = 0;

  Future<void> fetchVendorSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var VendorsalesFinalAmountToday = data['today_vendor_sales'];
      double amount = VendorsalesFinalAmountToday as double;
      totalVendorSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalVendorSalesAmount = totalVendorSalesAmount;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          flex: 3,
          child: Container(
            height: MediaQuery.of(context).size.height * 0.9,
            // color: Color.fromARGB(255, 255, 255, 255),
            child: Column(
              children: [
                Row(
                  children: [
                    Center(
                      child: Container(
                        height: 350,
                        width: MediaQuery.of(context).size.width * 0.3,
                        // color: const Color .fromARGB(255, 255, 255, 255),
                        child: buildMobileLayout(context),
                      ),
                    ),
                    Center(
                      child: Container(
                        height: 350,
                        width: MediaQuery.of(context).size.width * 0.31,
                        // color: Colors.white,
                        child: Column(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(right: 0, left: 10),
                              child: Text(
                                "Last 7 Days Income",
                                style: TextStyle(fontSize: 13),
                              ),
                            ),
                            Expanded(
                                child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 10, right: 0),
                              child: IncomeGraphDashboard(),
                            )),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: Responsive.isDesktop(context)
                          ? EdgeInsets.only(
                              right: 10,
                              left: 25,
                            )
                          : EdgeInsets.only(right: 10, left: 25, top: 15),
                      child: Text(
                        "Order Details",
                        style: TextStyle(
                          fontSize: 13,
                        ),
                      ),
                    ),
                    SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Center(
                        child: Container(
                          // height: MediaQuery.of(context).size.height * 0.6,
                          width: MediaQuery.of(context).size.width * 0.61,
                          // color: Color.fromARGB(255, 255, 255, 255),
                          child: SingleChildScrollView(
                              child: Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: DataTableExample(),
                          )),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.9,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 255, 255, 255),
              ),
              child: Column(
                children: [
                  TopSellingCardview(),
                  SizedBox(
                    height: 10,
                  ),
                  Divider(
                    color: Colors.grey[300],
                  ),
                  ExpensesChartView(),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }

  Widget buildMobileLayout(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: 8,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildCard(context, 'Today Sale', "₹ $totalSalesAmount",
                  'assets/imgs/sales.png'),
              buildCard(context, 'Today Purchase', "₹ $totalPurchaseAmount",
                  'assets/imgs/purchaseimg.png'),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildCard(context, 'Today Order Sales',
                  "₹ $totalOrderSalesAmount", 'assets/imgs/ordersales.png'),
              buildCard(context, 'Today vendor Sales',
                  "₹ $totalVendorSalesAmount", 'assets/imgs/vendorsales.png'),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildCard(
      BuildContext context, String title, String subtitle, String imagePath) {
    return Container(
      height: 145,
      width: Responsive.isMobile(context) || Responsive.isTablet(context)
          ? 250
          : MediaQuery.of(context).size.width * 0.14,
      child: Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                imagePath,
                height: 30,
                width: 30,
              ),
              SizedBox(height: 10),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 7),
              Text(
                subtitle,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class dashboardmobileTabletview extends StatefulWidget {
  const dashboardmobileTabletview({Key? key}) : super(key: key);

  @override
  State<dashboardmobileTabletview> createState() =>
      _dashboardmobileTabletviewState();
}

class _dashboardmobileTabletviewState extends State<dashboardmobileTabletview> {
  @override
  void initState() {
    super.initState();
    fetchSalesTotalAmount();
    fetchOrderSalesTotalAmount();
    fetchVendorSalesTotalAmount();
    fetchPurchaseTotalAmount();
  }

  int totalSalesAmount = 0;

  Future<void> fetchSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var salesFinalAmountToday = data['today_total_sales'];
      double amount = salesFinalAmountToday as double;
      totalSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalSalesAmount = totalSalesAmount;
      });
    }
  }

  int totalOrderSalesAmount = 0;

  Future<void> fetchOrderSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var OrdersalesFinalAmountToday = data['today_order_sales'];
      double amount = OrdersalesFinalAmountToday as double;
      totalOrderSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalOrderSalesAmount = totalOrderSalesAmount;
      });
    }
  }

  int totalVendorSalesAmount = 0;

  Future<void> fetchVendorSalesTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var VendorsalesFinalAmountToday = data['today_vendor_sales'];
      double amount = VendorsalesFinalAmountToday as double;
      totalVendorSalesAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalVendorSalesAmount = totalVendorSalesAmount;
      });
    }
  }

  int totalPurchaseAmount = 0;

  Future<void> fetchPurchaseTotalAmount() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardTodayRecordsView/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    // Assuming the JSON response is an object
    if (data is Map<String, dynamic>) {
      var purchaseFinalAmountToday = data['today_purchase_sales'];
      double amount = purchaseFinalAmountToday as double;
      totalPurchaseAmount = amount.toInt();
    }

    if (mounted) {
      // Check if the widget is still mounted before calling setState
      setState(() {
        totalPurchaseAmount = totalPurchaseAmount;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          child: Container(
            // color: const Color.fromARGB(255, 240, 240, 240),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Container(
                      // height: 340,
                      // color: const Color.fromARGB(255, 255, 255, 255),
                      child: buildMobileLayout(context)),
                ),
                TopSellingCardview(),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 1,
                  child: Container(
                    height: 400,
                    width: MediaQuery.of(context).size.width * 0.74,
                    // color: Color.fromARGB(255, 255, 255, 255),
                    child: Column(
                      children: [
                        Padding(
                          padding: Responsive.isDesktop(context)
                              ? EdgeInsets.only(
                                  right: 10,
                                  left: 10,
                                )
                              : EdgeInsets.only(right: 10, left: 10, top: 15),
                          child: Text(
                            "Order Details",
                            style: TextStyle(
                              fontSize: 13,
                            ),
                          ),
                        ),
                        SingleChildScrollView(
                            child: Padding(
                          padding: const EdgeInsets.only(top: 15, right: 8),
                          child: DataTableExample(),
                        )),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Center(
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.5,
                    // width: MediaQuery.of(context).size.width * 1,
                    color: Colors.white,
                    child: Column(
                      children: [
                        Padding(
                          padding: Responsive.isDesktop(context)
                              ? EdgeInsets.only(
                                  right: 10,
                                  left: 10,
                                )
                              : EdgeInsets.only(right: 10, left: 10, top: 15),
                          child: Text(
                            "Last 7 Days Income",
                            style: TextStyle(
                              fontSize: 13,
                            ),
                          ),
                        ),
                        Expanded(
                            child: Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: IncomeGraphDashboard(),
                        )),
                      ],
                    ),
                  ),
                ),
                Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                  child: Column(
                    children: [ExpensesChartView()],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget buildMobileLayout(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: 8,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildCard(context, 'Today Sale', "₹ $totalSalesAmount",
                  'assets/imgs/sales.png'),
              buildCard(context, 'Today Purchase', "₹ $totalPurchaseAmount",
                  'assets/imgs/purchaseimg.png'),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              buildCard(context, 'Today Order Sales',
                  "₹ $totalOrderSalesAmount", 'assets/imgs/ordersales.png'),
              buildCard(context, 'Today vendor Sales',
                  "₹ $totalVendorSalesAmount", 'assets/imgs/vendorsales.png'),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // buildCard(context, 'Today Expenses', "₹1000",
              //     'assets/imgs/expenses.png'),
              // buildCard(context, 'Today Purchase Payments', "₹1000",
              //     'assets/imgs/paymentpur.png'),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildCard(
      BuildContext context, String title, String subtitle, String imagePath) {
    return Container(
      height: 150,
      width: Responsive.isMobile(context) || Responsive.isTablet(context)
          ? MediaQuery.of(context).size.width * 0.44
          : MediaQuery.of(context).size.width * 0.170,
      child: Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                imagePath,
                height: 40,
                width: 40,
              ),
              SizedBox(height: 10),
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 7),
              Text(
                subtitle,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DataTableExample extends StatefulWidget {
  const DataTableExample({Key? key}) : super(key: key);

  @override
  State<DataTableExample> createState() => _DataTableExampleState();
}

class _DataTableExampleState extends State<DataTableExample> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(child: tableView());
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  List<Map<String, dynamic>> tableData = [];
  double totalAmount = 0.0;

  Future<void> fetchData() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardOrderSalesDetails/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var jsonData = json.decode(response.body);

    if (jsonData['order_today_details'] != null) {
      var orderSalesDetails = jsonData['order_today_details'] as List;
      tableData = List<Map<String, dynamic>>.from(orderSalesDetails);
    }

    if (mounted) {
      setState(() {
        totalAmount = tableData.isNotEmpty
            ? double.parse(tableData.first['finalamount'].toString())
            : 0.0;
      });
    }
  }

  Widget tableView() {
    return Padding(
      padding: Responsive.isDesktop(context)
          ? EdgeInsets.only(
              left: 20,
              right: 20,
            )
          : EdgeInsets.only(
              left: 20,
              right: 20,
            ),
      child: SingleChildScrollView(
        child: Container(
          height: Responsive.isDesktop(context)
              ? MediaQuery.of(context).size.height * 0.35
              : 320,
          decoration: BoxDecoration(
            color: Colors.grey[100],
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Container(
              width: Responsive.isDesktop(context)
                  ? MediaQuery.of(context).size.width * 0.60
                  : MediaQuery.of(context).size.width * 0.90,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.only(left: 0.0, right: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Container(
                          height: Responsive.isDesktop(context) ? 25 : 30,
                          width: 265.0,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            border: Border.all(
                              color: Colors.grey.shade300,
                            ),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.person,
                                  size: 15,
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  "Name",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: maincolor,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          height: Responsive.isDesktop(context) ? 25 : 30,
                          width: 265.0,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            border: Border.all(
                              color: Colors.grey.shade300,
                            ),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.phone,
                                  size: 15,
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  "Contact",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: maincolor,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          height: Responsive.isDesktop(context) ? 25 : 30,
                          width: 265.0,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            border: Border.all(
                              color: Colors.grey.shade300,
                            ),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.person,
                                  size: 15,
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  "Final",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: maincolor,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          height: Responsive.isDesktop(context) ? 25 : 30,
                          width: 265.0,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            border: Border.all(
                              color: Colors.grey.shade300,
                            ),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.delivery_dining,
                                  size: 15,
                                  color: Colors.blue,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  "Delivery",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: maincolor,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (tableData.isNotEmpty)
                  ...tableData.map((data) {
                    var cusname = data['cusname'].toString();
                    var contact = data['contact'].toString();
                    var finalamount = data['finalamount'].toString();
                    var deliverydate = data['deliverydate'].toString();

                    bool isEvenRow = tableData.indexOf(data) % 2 == 0;
                    Color? rowColor = isEvenRow
                        ? Color.fromARGB(224, 255, 255, 255)
                        : Color.fromARGB(255, 223, 225, 226);

                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 0.0, right: 0, top: 3, bottom: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Container(
                              height: 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: rowColor,
                                border: Border.all(
                                  color: Color.fromARGB(255, 226, 225, 225),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  cusname,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              height: 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: rowColor,
                                border: Border.all(
                                  color: Color.fromARGB(255, 226, 225, 225),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  contact,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              height: 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: rowColor,
                                border: Border.all(
                                  color: Color.fromARGB(255, 226, 225, 225),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  finalamount,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              height: 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: rowColor,
                                border: Border.all(
                                  color: Color.fromARGB(255, 226, 225, 225),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  deliverydate,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList()
                else ...{
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 70.0),
                        child: Column(
                          children: [
                            Image.asset(
                              'assets/imgs/delivery-man.png',
                              width: 50, // Adjust width as needed
                              height: 50, // Adjust height as needed
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Center(
                              child: Text(
                                'No orders available to delivery!!!',
                                style:
                                    TextStyle(fontSize: 15, color: Colors.grey),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )
                }
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class TopSellingCardview extends StatefulWidget {
  @override
  State<TopSellingCardview> createState() => _TopSellingCardviewState();
}

class _TopSellingCardviewState extends State<TopSellingCardview> {
  List<Map<String, dynamic>> topSellingItems = [];

  @override
  void initState() {
    super.initState();
    fetchTopSellingItems();
  }

  Future<void> fetchTopSellingItems() async {
    try {
      String? cusid = await SharedPrefs.getCusId();
      String apiUrl = '$IpAddress/DashboardTopSelling/$cusid/';
      http.Response response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        dynamic fetchedItems = data['top_selling_items'];

        if (fetchedItems is List) {
          topSellingItems = List<Map<String, dynamic>>.from(fetchedItems);
          setState(() {}); // Trigger widget rebuild after data update
        } else {
          print('Expected a List, but received: $fetchedItems');
        }
      } else {
        print(
            'Failed to fetch top selling items. Status code: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching top selling items: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 251, 251, 251),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 20.0, right: 20.0),
              child: Container(
                padding: EdgeInsets.only(left: 10, top: 6, bottom: 6),
                color: subcolor,
                child: Center(
                  child: Text(
                    'Top Selling Products',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 9.0),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (var i = 0; i < 6; i++) _buildCardWidget(i),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardWidget(int index) {
    if (index < topSellingItems.length) {
      return SmallCard(name: topSellingItems[index]['Itemname']);
    } else {
      return SmallCard(name: 'Not Available');
    }
  }
}

class SmallCard extends StatelessWidget {
  final String name;

  SmallCard({required this.name});

  @override
  Widget build(BuildContext context) {
    Color textColor = name == "Not Available" ? Colors.grey : maincolor;
    FontWeight fontWeight =
        name == "Not Available" ? FontWeight.normal : FontWeight.bold;

    return Padding(
      padding: const EdgeInsets.only(
        left: 15,
        right: 15,
        // top: 3,
      ),
      child: Card(
        elevation: 3.0,
        child: Container(
          // width: 130.0,
          height: 30.0,
          padding: EdgeInsets.all(8.0),
          child: Center(
            child: Text(name ?? "Not Available",
                style: TextStyle(
                    fontSize: 12.0, color: textColor, fontWeight: fontWeight)),
          ),
        ),
      ),
    );
  }
}
