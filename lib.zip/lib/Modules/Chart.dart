import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:product_restaurantapp/Database/IpAddress.dart';
import 'package:product_restaurantapp/Modules/Responsive.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ChartData {
  ChartData(this.date, this.amount);
  final String date;
  final double amount;
  late Color color; // Color assigned to each data point
}

class IncomeGraphDashboard extends StatefulWidget {
  const IncomeGraphDashboard({Key? key}) : super(key: key);

  @override
  State<IncomeGraphDashboard> createState() => _IncomeGraphDashboardState();
}

class _IncomeGraphDashboardState extends State<IncomeGraphDashboard> {
  List<Map<String, dynamic>> lastWeekPurchaseData = [];

  @override
  void initState() {
    super.initState();
    piechart();
  }

  Future<void> piechart() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardWeeklyRecords/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var jsonData = json.decode(response.body);

    if (jsonData['IncomeLast7DaysDetails'] != null) {
      lastWeekPurchaseData =
          List<Map<String, dynamic>>.from(jsonData['IncomeLast7DaysDetails']);
    }

    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<ChartData> lineChartDataList = lastWeekPurchaseData
        .where((data) => data['dt'] != null && data['amount_sum'] != null)
        .map((data) {
          final date = data['dt'] as String?;
          final amount =
              double.parse(data['amount_sum'] as String); // Convert to double
          if (date != null && amount != null) {
            return ChartData(date, amount);
          } else {
            return null; // Skip data with null values
          }
        })
        .whereType<ChartData>() // Filter out null values
        .toList();

    return Row(
      children: [
        if (Responsive.isDesktop(context))
          Center(
            child: Row(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.3,
                  height: MediaQuery.of(context).size.height * 0.9,
                  child: Column(
                    children: [
                      Center(
                        child: SfCartesianChart(
                          palette: <Color>[
                            subcolor, // Color for the first series
                          ],
                          primaryXAxis: CategoryAxis(
                            labelIntersectAction:
                                AxisLabelIntersectAction.rotate45,
                            labelPlacement: LabelPlacement.onTicks,
                            majorTickLines: MajorTickLines(size: 0),
                          ),
                          series: <ChartSeries>[
                            LineSeries<ChartData, String>(
                              dataSource: lineChartDataList,
                              xValueMapper: (ChartData data, _) {
                                return data.date
                                    .substring(data.date.length - 2);
                              },
                              yValueMapper: (ChartData data, _) => data.amount,
                              dataLabelSettings: DataLabelSettings(
                                  isVisible: true,
                                  color: subcolor, // Color for the circle
                                  alignment: ChartAlignment.near,
                                  labelAlignment: ChartDataLabelAlignment.auto,
                                  labelPosition: ChartDataLabelPosition.outside,
                                  textStyle: TextStyle(fontSize: 10)),
                            ),
                          ],
                          tooltipBehavior: TooltipBehavior(
                            enable: true,
                            header: '',
                            format: 'Amount: \$point.y',
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        if (Responsive.isMobile(context) || Responsive.isTablet(context))
          Center(
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.89,
                  child: Column(
                    children: [
                      Center(
                        child: SfCartesianChart(
                          palette: <Color>[
                            subcolor, // Color for the first series
                          ],
                          primaryXAxis: CategoryAxis(
                            labelIntersectAction:
                                AxisLabelIntersectAction.rotate45,
                            labelPlacement: LabelPlacement.onTicks,
                            majorTickLines: MajorTickLines(size: 0),
                          ),
                          series: <ChartSeries>[
                            LineSeries<ChartData, String>(
                              dataSource: lineChartDataList,
                              xValueMapper: (ChartData data, _) {
                                return data.date
                                    .substring(data.date.length - 2);
                              },
                              yValueMapper: (ChartData data, _) => data.amount,
                              dataLabelSettings: DataLabelSettings(
                                isVisible: true,
                                color: subcolor, // Color for the circle
                                alignment: ChartAlignment.near,
                                labelAlignment: ChartDataLabelAlignment.auto,
                                labelPosition: ChartDataLabelPosition.outside,
                              ),
                            ),
                          ],
                          tooltipBehavior: TooltipBehavior(
                            enable: true,
                            header: '',
                            format: 'Amount: \$point.y',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class ExpensesChartView extends StatefulWidget {
  const ExpensesChartView({Key? key}) : super(key: key);

  @override
  State<ExpensesChartView> createState() => _ExpensesChartViewState();
}

class _ExpensesChartViewState extends State<ExpensesChartView> {
  List<Map<String, dynamic>> lastWeekPurchaseData = [];
  List<Color> segmentColors = [
    Colors.blue,
    Color.fromARGB(255, 230, 44, 106),
    Colors.purple,
    Colors.lime,
    Color.fromRGBO(238, 100, 134, 1),
    Colors.orange,
    Colors.brown,
    Colors.teal,

    // Add more colors as needed
  ];

  @override
  void initState() {
    super.initState();
    fetchPiedata();
  }

  Future<void> fetchPiedata() async {
    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/DashboardWeeklyRecords/$cusid/';
    http.Response response = await http.get(Uri.parse(apiUrl));
    var jsonData = json.decode(response.body);

    if (jsonData['ExpensesLast7DaysDetails'] != null) {
      lastWeekPurchaseData =
          List<Map<String, dynamic>>.from(jsonData['ExpensesLast7DaysDetails']);
    }

    // Initialize color for each data point
    for (int i = 0; i < lastWeekPurchaseData.length; i++) {
      lastWeekPurchaseData[i]['color'] =
          segmentColors[i % segmentColors.length] ?? Colors.grey;
    }

    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<PieChartData> pieChartDataList = lastWeekPurchaseData
        .where((data) => data['dt'] != null && data['amount_sum'] != null)
        .map((data) {
          final date = data['dt'] as String?;
          final amount = double.parse(data['amount_sum'] as String);
          if (date != null && amount != null) {
            return PieChartData(date, amount);
          } else {
            return null;
          }
        })
        .whereType<PieChartData>()
        .toList();

    return Row(
      children: [
        if (Responsive.isDesktop(context))
          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.20,
              height: MediaQuery.of(context).size.height * 0.4,
              child: Column(
                children: [
                  Center(
                    child: Text('Last 7 Days Expense',
                        style: TextStyle(fontSize: 13)),
                  ),
                  Expanded(
                    child: Center(
                        child: pieChartDataList.isNotEmpty
                            ? SfCircularChart(
                                series: <CircularSeries>[
                                  DoughnutSeries<PieChartData, String>(
                                    dataSource: pieChartDataList,
                                    xValueMapper: (PieChartData data, _) =>
                                        data.date,
                                    yValueMapper: (PieChartData data, _) =>
                                        data.amount,
                                    dataLabelMapper: (PieChartData data, _) =>
                                        '${_getDayOfWeek(data.date)}\n\$${data.amount}',
                                    pointColorMapper:
                                        (PieChartData data, index) {
                                      final colors = [
                                        Color.fromARGB(255, 211, 66, 155),
                                        Colors.teal,
                                        Colors.lime,
                                        Colors.purple,
                                        Colors.pink,
                                        Colors.yellow,
                                        Colors.green,
                                        Colors.purpleAccent,
                                        // Add more colors as needed
                                      ];
                                      return colors[index % colors.length];
                                    },
                                    dataLabelSettings: DataLabelSettings(
                                      isVisible: true,
                                      labelPosition:
                                          ChartDataLabelPosition.outside,
                                      labelAlignment:
                                          ChartDataLabelAlignment.middle,
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 12),
                                      labelIntersectAction:
                                          LabelIntersectAction.shift,
                                    ),
                                  ),
                                ],
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 60.0),
                                    child: Column(
                                      children: [
                                        Image.asset(
                                          'assets/imgs/receiver.png',
                                          width: 100,
                                          height: 100,
                                        ),
                                        Center(
                                          child: Text(
                                            'No Expenses available!!',
                                            style: TextStyle(
                                                fontSize: 15,
                                                color: Colors.grey),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                  ),
                ],
              ),
            ),
          ),
        if (Responsive.isMobile(context) || Responsive.isTablet(context))
          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.89,
              height: MediaQuery.of(context).size.height * 0.6,
              child: Column(
                children: [
                  Center(
                    child: Text('Last 7 Days Expense',
                        style: TextStyle(fontSize: 13)),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Center(
                      child: pieChartDataList.isNotEmpty
                          ? SfCircularChart(
                              series: <CircularSeries>[
                                DoughnutSeries<PieChartData, String>(
                                  dataSource: pieChartDataList,
                                  xValueMapper: (PieChartData data, _) =>
                                      data.date,
                                  yValueMapper: (PieChartData data, _) =>
                                      data.amount,
                                  dataLabelMapper: (PieChartData data, _) =>
                                      '${_getDayOfWeek(data.date)}\n\$${data.amount}',
                                  pointColorMapper: (PieChartData data, index) {
                                    final colors = [
                                      Color.fromARGB(255, 211, 66, 155),
                                      Colors.teal,
                                      Colors.lime,
                                      Colors.purple,
                                      Colors.pink,
                                      Colors.yellow,
                                      Colors.green,
                                      Colors.purpleAccent,
                                      // Add more colors as needed
                                    ];
                                    return colors[index % colors.length];
                                  },
                                  dataLabelSettings: DataLabelSettings(
                                    isVisible: true,
                                    labelPosition:
                                        ChartDataLabelPosition.outside,
                                    labelAlignment:
                                        ChartDataLabelAlignment.middle,
                                    textStyle: TextStyle(
                                        color: Colors.black, fontSize: 12),
                                    labelIntersectAction:
                                        LabelIntersectAction.shift,
                                  ),
                                ),
                              ],
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 60.0),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                        'assets/imgs/receive-1.png',
                                        width: 100,
                                        height: 100,
                                      ),
                                      Center(
                                        child: Text(
                                          'No Expenses available!!',
                                          style: TextStyle(
                                              fontSize: 15, color: Colors.grey),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            )),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

String _getDayOfWeek(String dateString) {
  DateTime date = DateTime.parse(dateString);
  return DateFormat('EEEE').format(date);
}

class ChartExpenseData {
  ChartExpenseData(
      {required this.date, required this.amount, required this.color});

  final String date;
  final double amount;
  late Color color; // Initialize the color property

  // Other constructors and methods...
}

class ChartDataDash {
  ChartDataDash(this.x, this.y, this.color);
  final String x;
  final double y;
  final Color color;
}

class PieChartData {
  PieChartData(this.date, this.amount);
  final String date;
  final double amount;
  late Color color; // Color assigned to each data point
}
