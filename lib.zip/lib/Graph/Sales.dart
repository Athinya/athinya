import 'package:flutter/material.dart';
import 'package:product_restaurantapp/Graph/GraphDesign.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';

class SalesChart extends StatefulWidget {
  @override
  _SalesChartState createState() => _SalesChartState();
}

class _SalesChartState extends State<SalesChart> {
  String? selectedProduct = 'Last 7 Days';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Expanded(
            flex: 10,
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Sales Graph',
                      style: TextStyle(
                        fontSize: 15,
                        color: maincolor,
                      ),
                    ),
                    SizedBox(height: 40),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Select',
                          style: TextStyle(fontSize: 13),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                Radio<String>(
                                  value: 'Last 7 Days',
                                  groupValue: selectedProduct,
                                  onChanged: (String? value) {
                                    setState(() {
                                      selectedProduct = value;
                                    });
                                  },
                                ),
                                Text('Last 7 Days'),
                                Radio<String>(
                                  value: 'Last Month',
                                  groupValue: selectedProduct,
                                  onChanged: (String? value) {
                                    setState(() {
                                      selectedProduct = value;
                                    });
                                  },
                                ),
                                Text('Last Month'),
                                Radio<String>(
                                  value: 'Last year',
                                  groupValue: selectedProduct,
                                  onChanged: (String? value) {
                                    setState(() {
                                      selectedProduct = value;
                                    });
                                  },
                                ),
                                Text('Last Year'),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Divider(color: Colors.grey[300], thickness: 2),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (selectedProduct == 'Last 7 Days')
                          SalesWeekChart()
                        else if (selectedProduct == 'Last Month')
                          SalesMonthChart()
                        else if (selectedProduct == 'Last year')
                          SalesYearChart(),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
