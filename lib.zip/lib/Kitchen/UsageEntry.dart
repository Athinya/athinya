import 'dart:convert';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:http/http.dart' as http;
import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:product_restaurantapp/Database/IpAddress.dart';
import 'package:product_restaurantapp/Modules/Responsive.dart';
import 'package:product_restaurantapp/Modules/constaints.dart';
import 'package:product_restaurantapp/Purchase/Config/PurchaseProductDetails.dart';
import 'package:product_restaurantapp/Settings/AddProductsDetails.dart';
import 'package:product_restaurantapp/Settings/StaffDetails.dart';

class UsageEntryKitchen extends StatefulWidget {
  const UsageEntryKitchen({Key? key}) : super(key: key);

  @override
  State<UsageEntryKitchen> createState() => _UsageEntryKitchenState();
}

class _UsageEntryKitchenState extends State<UsageEntryKitchen> {
  String? selectedValue;
  String? selectedproduct;
  FocusNode DateFocus = FocusNode();
  TextEditingController RecordNoController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchAllPurchaseProductName();
    fetchEmployeeName();
    fetchUsageRecordNo();
    // fetchLastSno();
    _qtyController.text = "0";
    stockValueController.text = "0";
  }

  Future<void> fetchUsageRecordNo() async {
    try {
      String? cusid = await SharedPrefs.getCusId();
      if (cusid == null) {
        throw Exception('Customer ID is null');
      }

      final response =
          await http.get(Uri.parse('$IpAddress/Usageserialno/$cusid/'));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        if (jsonData != null && jsonData['serialno'] != null) {
          int currentPayno = int.parse(jsonData['serialno'].toString());
          // Add 1 to the current payno
          int nextPayno = currentPayno + 1;
          setState(() {
            RecordNoController.text = nextPayno.toString();
          });
          print("Purchase RecordNo : ${RecordNoController.text}");
        } else {
          throw Exception('Invalid JSON data');
        }
      } else {
        throw Exception('Failed to load serial number');
      }
    } catch (e) {
      print('Error fetching usage record number: $e');
    }
  }

  Future<void> postDataWithIncrementedSerialNo() async {
    int incrementedSerialNo = int.parse(
      RecordNoController.text,
    );

    String? cusid = await SharedPrefs.getCusId();
    Map<String, dynamic> postData = {
      "cusid": "$cusid",
      "serialno": incrementedSerialNo,
    };

    // Convert the data to JSON format
    String jsonData = jsonEncode(postData);

    try {
      // Send the POST request
      var response = await http.post(
        Uri.parse('$IpAddress/Usageserialnoalldata/'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonData,
      );

      // Check the response status
      if (response.statusCode == 200) {
        print('Data posted successfully');
        fetchUsageRecordNo();
      } else {
        print('Failed to post data. Error code: ${response.statusCode}');
        print('Response body: ${response.body}');
        fetchUsageRecordNo();
      }
    } catch (e) {
      // print('Failed to post data. Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Row(
        children: [
          Expanded(
            flex: 10,
            child: Container(
              color: Colors.white,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      // color: Subcolor,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 20,
                              ),
                              Text(
                                "Usage Entry",
                                style: TextStyle(
                                  fontSize: 14,
                                ),
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: 60,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Responsive.isDesktop(context)
                        ? Row(children: [
                            Expanded(flex: 8, child: LeftWidget(context)),
                            Expanded(flex: 4, child: RightWidget(context))
                          ])
                        : Column(children: [
                            RightWidget(context),
                            LeftWidget(context)
                          ]),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> tableData = [];
  double totalAmount = 0.0;
  int currentPage = 1;
  int pageSize = 10;
  bool hasNextPage = false;
  bool hasPreviousPage = false;
  int totalPages = 1;
  String searchText = '';

  List<Map<String, dynamic>> getFilteredData() {
    if (searchText.isEmpty) {
      // If the search text is empty, return the original data
      return tableData;
    }

    // Filter the data based on the search text
    List<Map<String, dynamic>> filteredData = tableData
        .where((data) => (data['prodname'] ?? '')
            .toLowerCase()
            .contains(searchText.toLowerCase()))
        .toList();

    return filteredData;
  }

  Widget LeftWidget(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: Responsive.isDesktop(context) ? 15 : 10,
        right: Responsive.isDesktop(context) ? 15 : 10,
        top: 20,
        bottom: 20,
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: Column(
          children: [
            SizedBox(height: 20),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                  ),
                  child: Text(
                    "No.Of.Product:",
                    style: TextStyle(fontSize: 12),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 15,
                  ),
                  child: Container(
                    width: Responsive.isDesktop(context) ? 70 : 70,
                    child: Container(
                      height: 27,
                      width: 100,
                      // color: Colors.grey[200],
                      child: Text(
                        tableData.length.toString(),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    right: 20.0,
                    bottom: 10.0,
                  ),
                  child: Container(
                    height: 30,
                    width: 130,
                    child: TextField(
                      onChanged: (value) {
                        setState(() {
                          searchText = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Search',
                        suffixIcon: Icon(
                          Icons.search,
                          color: Colors.grey,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(1),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.grey, width: 1.0),
                          borderRadius: BorderRadius.circular(1),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.grey, width: 1.0),
                          borderRadius: BorderRadius.circular(1),
                        ),
                        contentPadding: EdgeInsets.only(left: 10.0, right: 4.0),
                      ),
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ),
              ],
            ),
            tableView(),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(left: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      _saveUsageRound_Details_ToAPI();
                      calculateRemainingStock();
                      tableData.clear();
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2.0),
                      ),
                      backgroundColor: subcolor,
                      minimumSize: Size(45.0, 31.0), // Set width and height
                    ),
                    child: Text(
                      'Save',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        tableData.clear();
                        _employeeController.text = "";
                        selectedEmployeeName = "";
                        selectedProductName = "";
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(2.0),
                      ),
                      backgroundColor: subcolor,
                      minimumSize: Size(45.0, 31.0), // Set width and height
                    ),
                    child: Text(
                      'Refresh',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget tableView() {
    return Padding(
      padding: Responsive.isDesktop(context)
          ? EdgeInsets.only(left: 20, right: 20)
          : EdgeInsets.only(left: 0, right: 0),
      child: SingleChildScrollView(
        child: Container(
          height: Responsive.isDesktop(context) ? 430 : 320,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Container(
              width: Responsive.isDesktop(context)
                  ? MediaQuery.of(context).size.width * 0.61
                  : MediaQuery.of(context).size.width * 0.9,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 0.0, right: 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            child: Container(
                              height: Responsive.isDesktop(context) ? 25 : 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: Colors.grey[200],
                              ),
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.fastfood,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      "ProductName",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              height: Responsive.isDesktop(context) ? 25 : 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: Colors.grey[200],
                              ),
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.add_box,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      "Qty",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Flexible(
                            child: Container(
                              height: Responsive.isDesktop(context) ? 25 : 30,
                              width: 265.0,
                              decoration: BoxDecoration(
                                color: Colors.grey[200],
                              ),
                              child: Center(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.delete,
                                      size: 15,
                                      color: Colors.blue,
                                    ),
                                    SizedBox(width: 5),
                                    Text(
                                      "Delete",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (getFilteredData().isNotEmpty)
                      ...getFilteredData().map((data) {
                        var productname = data['prodname'].toString();
                        var qty = data['qty'].toString();

                        bool isEvenRow = tableData.indexOf(data) % 2 == 0;
                        int index = tableData.indexOf(data); // Access the index
                        Color? rowColor = isEvenRow
                            ? Color.fromARGB(224, 255, 255, 255)
                            : Color.fromARGB(224, 255, 255, 255);

                        return Padding(
                          padding: const EdgeInsets.only(
                            left: 0.0,
                            right: 0,
                            top: 1.0,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Container(
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: rowColor,
                                    border: Border.all(
                                      color: Color.fromARGB(255, 226, 225, 225),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      productname,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Flexible(
                                child: Container(
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: rowColor,
                                    border: Border.all(
                                      color: Color.fromARGB(255, 226, 225, 225),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      qty,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Flexible(
                                child: Container(
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: rowColor,
                                    border: Border.all(
                                      color: Color.fromARGB(255, 226, 225, 225),
                                    ),
                                  ),
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 10.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        IconButton(
                                          icon: Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                            size: 18,
                                          ),
                                          onPressed: () {
                                            _deleteTableData(index);
                                          },
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList()
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  TextEditingController _qtyController = TextEditingController();

  List<String> ProductCategoryList = [];

  Future<void> fetchAllPurchaseProductName() async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String url = '$IpAddress/PurchaseProductDetails/$cusid/';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          ProductCategoryList.addAll(results
              .where((item) => item['addstock'].toString() == 'No')
              .map<String>((item) => item['name'].toString()));

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
          print("Purchase product list : $ProductCategoryList");
        } else {
          throw Exception(
              'Failed to load categories: ${response.reasonPhrase}');
        }
      }

      //  print('All product categories: $ProductCategoryList');
    } catch (e) {
      print('Error fetching categories: $e');
      rethrow; // Rethrow the error to propagate it further
    }
  }

  Future<String?> fetchStockByName(String selectedProductName) async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String apiUrl = '$IpAddress/PurchaseProductDetails/$cusid/';
      int page = 1;
      bool hasMorePages = true;
      String url = '$apiUrl?page=$page';
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final List<dynamic> results = data['results'];

        // Find the result with the matching product name
        final Map<String, dynamic>? productData = results.firstWhere(
          (item) => item['name'].toString() == selectedProductName,
          orElse: () => null,
        );

        if (productData != null) {
          return productData['stock'].toString();
        }

        page++;
        hasMorePages = data['next'] != null;
      } else {
        throw Exception('Failed to fetch stock: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error fetching stock: $e');
    }
    return null;
  }

  void calculateRemainingStock() {
    // Assuming tableData is a List<Map<String, dynamic>>
    for (var i = 0; i < tableData.length; i++) {
      var rowData = tableData[i];
      String productName = rowData['prodname'];

      // Check if 'qty' field exists and is not null
      if (rowData.containsKey('qty') && rowData['qty'] != null) {
        // Try to parse 'qty' as an integer
        int? qty = rowData['qty'] is int
            ? rowData['qty']
            : int.tryParse(rowData['qty'].toString());

        if (qty != null) {
          // Fetch product ID through an API call
          fetchProductIdByName(productName).then((productId) {
            if (productId != null) {
              fetchStockByName(productName).then((stock) {
                if (stock != null) {
                  double remainingStock = double.parse(stock) - qty;
                  print('Remaining Stock for $productName: $remainingStock');

                  // Call the updateStockInApi function with the required arguments
                  updateStockInApi(productId, remainingStock);
                } else {
                  print('Failed to fetch stock for product: $productName');
                }
              });
            } else {
              print('Failed to fetch product ID for product: $productName');
            }
          });
        } else {
          print('Error: Unable to parse qty for product: $productName');
        }
      } else {
        print('Error: qty is null or not present for product: $productName');
      }
    }
  }

  Future<int?> fetchProductIdByName(String productName) async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String apiUrl = '$IpAddress/PurchaseProductDetails/$cusid/';
      http.Response response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        Map<String, dynamic> responseData = json.decode(response.body);

        var product = responseData['results'].firstWhere(
          (item) => item['name'] == productName,
          orElse: () => null,
        );

        if (product != null) {
          return product['id'];
        } else {
          // print('No product found with name: $productName');
          return null;
        }
      } else {
        print(
            'Failed to fetch product list. Status code: ${response.statusCode}');
        //  print('Response Body: ${response.body}');
        return null;
      }
    } catch (e) {
      // print('Error fetching product list: $e');
      return null;
    }
  }

  Future<void> updateStockInApi(int productId, double remainingStock) async {
    try {
      String apiUrl = '$IpAddress/PurchaseProductDetailsalldatas/$productId/';

      Map<String, dynamic> requestData = {
        'stock': remainingStock.toString(),
      };

      http.Response response = await http.put(
        Uri.parse(apiUrl),
        body: json.encode(requestData),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        print('Stock updated successfully for product $productId');
      } else {
        print(
            'Failed to update stock for product $productId. Status code: ${response.statusCode}');
        //  print('Response Body: ${response.body}');
      }
    } catch (e) {
      print('Error updating stock: $e');
    }
  }

  TextEditingController ProductCategoryController = TextEditingController();
  TextEditingController stockValueController = TextEditingController();
  String? selectedProductName;

  FocusNode ProdNameFocus = FocusNode();

  List<String> EmployeeNameList = [];

  Widget ProductNamedropdown() {
    ProductCategoryController.text = selectedProductName ?? '';

    return TypeAheadFormField<String?>(
      textFieldConfiguration: TextFieldConfiguration(
        focusNode: ProdNameFocus,
        textInputAction: TextInputAction.next,
        onSubmitted: (_) =>
            _fieldFocusChange(context, ProdNameFocus, _qtyfocus),
        controller: ProductCategoryController,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey, width: 1.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey, width: 1.0),
          ),
          contentPadding: EdgeInsets.only(bottom: 10, left: 5),
          labelStyle: TextStyle(fontSize: 12),
          suffixIcon: Icon(
            Icons.keyboard_arrow_down,
            size: 18,
          ),
        ),
        style: TextStyle(fontSize: 12, color: Colors.black),
      ),
      suggestionsCallback: (pattern) {
        return ProductCategoryList.where(
                (item) => item.toLowerCase().contains(pattern.toLowerCase()))
            .toList();
      },
      itemBuilder: (context, String? suggestion) {
        return ListTile(
          dense: true,
          title: Text(
            suggestion ?? '',
            style: TextStyle(
              fontSize: 11,
              color: Colors.black,
            ),
          ),
        );
      },
      onSuggestionSelected: (String? suggestion) async {
        setState(() {
          selectedProductName = suggestion!;
          ProductCategoryController.text = suggestion;
        });
        try {
          String? stock = await fetchStockByName(suggestion!);

          if (stock != null) {
            setState(() {
              selectedProductName = suggestion;
              ProductCategoryController.text =
                  suggestion ?? ' ${selectedProductName ?? ''}';
              stockValueController.text = stock;
              FocusScope.of(context).requestFocus(_qtyfocus);
            });
          } else {
            print('Failed to fetch stock for product: $suggestion');
          }
        } catch (e) {
          print('Error in onSuggestionSelected: $e');
        }
      },
      suggestionsBoxDecoration: SuggestionsBoxDecoration(
        constraints: BoxConstraints(maxHeight: 150),
      ),
    );
  }

  void clearProductSelection() {
    setState(() {
      selectedProductName = null;
      ProductCategoryController.clear();
    });
  }

  void successfullySavedMessage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.green,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.check_circle_rounded, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'Successfully Saved',
                style: TextStyle(fontSize: 12, color: Colors.white),
              ),
            ],
          ),
        );
      },
    );

    // Close the dialog automatically after 2 seconds
    Future.delayed(Duration(seconds: 1), () {
      Navigator.of(context).pop();
    });
  }

  void _saveUsageRound_Details_ToAPI() async {
    String? qty = _qtyController.text;

    if (tableData.isEmpty || qty == null || selectedEmployeeName == null) {
      showEmptyWarning();
      return;
    }

    List<Map<String, dynamic>> UsageDetailsData = [];
    String recordno = RecordNoController.text;
    print("post record no datas : $recordno");
    for (var i = 0; i < tableData.length; i++) {
      var rowData = tableData[i];

      String productName = rowData['prodname'];
      int qty = int.parse(rowData['qty'].toString());

      UsageDetailsData.add({
        'billno': recordno,
        'dt': _DateController.text,
        'employee': selectedEmployeeName,
        'productname': productName,
        'qty': qty,
      });
    }

    String UsageDetailsJson = json.encode(UsageDetailsData);

    String? cusid = await SharedPrefs.getCusId();
    String apiUrl = '$IpAddress/UsageRound_Detailsalldata/';
    Map<String, dynamic> postData = {
      "cusid": cusid,
      'billno': recordno,
      'dt': _DateController.text,
      'employee': selectedEmployeeName,
      'count': tableData.length.toString(),
      'UsageDetails': UsageDetailsJson,
    };

    try {
      http.Response response = await http.post(
        Uri.parse(apiUrl),
        body: json.encode(postData),
        headers: {'Content-Type': 'application/json'},
      );

      if (mounted) {
        // Check if the widget is still mounted before updating the state
        if (response.statusCode == 201) {
          print('Data saved successfully');
          postDataWithIncrementedSerialNo();
          successfullySavedMessage();
          // incrementAndInsert();
          _employeeController.text = "";
          selectedEmployeeName = '';
          _qtyController.text = "0";
        } else {
          print('Failed to save data. Status code: ${response.statusCode}');
        }
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  FocusNode _qtyfocus = FocusNode();
  void _AddTabledata() async {
    setState(() {
      String? qty = _qtyController.text;
      if (selectedProductName == null || selectedEmployeeName == null) {
        showEmptyWarning();
        return;
      }
      if (qty.isEmpty || qty == "0") {
        showQuantityWarning();
        _qtyfocus.requestFocus();

        return;
      }
      tableData.add({
        'prodname': selectedProductName,
        'qty': _qtyController.text,
      });
      selectedProductName = "";
      _qtyController.text = "0";
      stockValueController.text = "0";
    });
  }

  void _deleteTableData(int index) {
    setState(() {
      if (index >= 0 && index < tableData.length) {
        tableData.removeAt(index);
      }
    });
  }

  void showEmptyWarning() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.yellow,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.warning, color: maincolor),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'Kindly check your stock details..!!!',
                style: TextStyle(fontSize: 12, color: maincolor),
              ),
            ],
          ),
        );
      },
    );

    // Close the dialog automatically after 2 seconds
    Future.delayed(Duration(seconds: 1), () {
      Navigator.of(context).pop();
    });
  }

  void showQuantityWarning() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.yellow,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.warning, color: maincolor),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'Kindly check your usage qty...!!!',
                style: TextStyle(fontSize: 12, color: maincolor),
              ),
            ],
          ),
        );
      },
    );

    // Close the dialog automatically after 2 seconds
    Future.delayed(Duration(seconds: 1), () {
      Navigator.of(context).pop();
    });
  }

  Future<void> fetchEmployeeName() async {
    String? cusid = await SharedPrefs.getCusId();
    try {
      String url = '$IpAddress/StaffDetails/$cusid';
      bool hasNextPage = true;

      while (hasNextPage) {
        final response = await http.get(Uri.parse(url));

        if (response.statusCode == 200) {
          final Map<String, dynamic> data = jsonDecode(response.body);
          final List<dynamic> results = data['results'];

          EmployeeNameList.addAll(
              results.map<String>((item) => item['serventname'].toString()));

          hasNextPage = data['next'] != null;
          if (hasNextPage) {
            url = data['next'];
          }
        } else {
          throw Exception(
              'Failed to load categories: ${response.reasonPhrase}');
        }
      }

      //   print('All product categories: $EmployeeNameList');
    } catch (e) {
      print('Error fetching categories: $e');
      rethrow; // Rethrow the error to propagate it further
    }
  }

  TextEditingController _employeeController = TextEditingController();
  String? selectedEmployeeName;
  FocusNode EmployeeFocus = FocusNode();
  Widget EmployeeDropdown() {
    _employeeController.text = selectedEmployeeName ?? '';

    return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
      return TypeAheadFormField<String?>(
        textFieldConfiguration: TextFieldConfiguration(
          focusNode: EmployeeFocus,
          textInputAction: TextInputAction.next,
          onSubmitted: (_) =>
              _fieldFocusChange(context, EmployeeFocus, DateFocus),
          controller: _employeeController,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 1.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey, width: 1.0),
            ),
            contentPadding: EdgeInsets.only(bottom: 10, left: 5),
            labelStyle: TextStyle(fontSize: 12),
            suffixIcon: Icon(
              Icons.keyboard_arrow_down,
              size: 18,
            ),
          ),
          style: TextStyle(fontSize: 12, color: Colors.black),
        ),
        suggestionsCallback: (pattern) {
          return EmployeeNameList.where(
                  (item) => item.toLowerCase().contains(pattern.toLowerCase()))
              .toList();
        },
        itemBuilder: (context, String? suggestion) {
          return ListTile(
            dense: true,
            title: Text(
              suggestion ?? '',
              style: TextStyle(
                fontSize: 11,
                color: Colors.black,
              ),
            ),
          );
        },
        onSuggestionSelected: (String? suggestion) async {
          setState(() {
            selectedEmployeeName = suggestion!;
            _employeeController.text = suggestion;
            FocusScope.of(context).requestFocus(DateFocus);
          });
        },
        suggestionsBoxDecoration: SuggestionsBoxDecoration(
          constraints: BoxConstraints(maxHeight: 150),
        ),
      );
    });
  }

  Widget _buildEmployeeNameDropdown() {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Row(
        children: [
          Icon(Icons.person),
          SizedBox(width: 3),
          Container(
            width: 130,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 5),
                Container(height: 23, width: 150, child: EmployeeDropdown()),
              ],
            ),
          ),
          SizedBox(width: 3),
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: InkWell(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      child: StaffDetailsPage(),
                    );
                  },
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  color: subcolor,
                ),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 6, right: 6, top: 2, bottom: 2),
                  child: Text(
                    "+",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductNameDropdown() {
    return Padding(
      padding: const EdgeInsets.only(top: 0.0),
      child: Row(
        children: [
          Icon(Icons.fastfood_sharp),
          SizedBox(width: 3),
          Container(
            width: 130,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 5),
                Container(height: 23, width: 150, child: ProductNamedropdown()),
              ],
            ),
          ),
          SizedBox(width: 3),
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: InkWell(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      child: PurchaseProductDetails(),
                    );
                  },
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  color: subcolor,
                ),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 6, right: 6, top: 2, bottom: 2),
                  child: Text(
                    "+",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQtyText(String label) {
    return Row(
      children: [
        Icon(Icons.production_quantity_limits),
        Padding(
          padding: EdgeInsets.all(
            0.0,
          ),
          child: Text(
            label,
            style: TextStyle(fontSize: 12),
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(right: 10, top: 5),
              child: Row(
                children: [
                  Container(
                    width: Responsive.isDesktop(context) ? 50 : 80,
                    child: Container(
                      height: 23,
                      width: 50,
                      child: TextField(
                        onSubmitted: (value) {
                          _AddTabledata();
                        },
                        keyboardType: TextInputType.number,
                        controller: _qtyController,
                        focusNode: _qtyfocus,
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade100, width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade100, width: 1.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: 4.0,
                            horizontal: 7.0,
                          ),
                        ),
                        style: TextStyle(
                            color: maincolor,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  TextEditingController _DateController = TextEditingController(
      text: DateFormat('yyyy-MM-dd').format(DateTime.now()));

  late DateTime selectedDate;
  Widget RightWidget(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          left: Responsive.isDesktop(context) ? 15 : 40,
          right: Responsive.isDesktop(context) ? 15 : 40,
          top: 20,
          bottom: 20),
      child: Container(
        decoration: BoxDecoration(color: Colors.grey[100]
            // borderRadius: BorderRadius.circular(20),
            // border: Border.all(
            //   color: const Color.fromARGB(255, 171, 171, 171),
            //   width: 1,
            // ),
            ),
        child: Padding(
          padding: EdgeInsets.only(
            top: 25,
            bottom: 30,
            left: Responsive.isDesktop(context) ? 40 : 30,
            right: Responsive.isDesktop(context) ? 40 : 30,
          ),
          child: Wrap(
            alignment: WrapAlignment.start,
            runSpacing: Responsive.isDesktop(context) ? 17 : 10,
            children: [
              Container(
                child: Padding(
                  padding: const EdgeInsets.only(left: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Text(
                          'RecordNo',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        height: 30,
                        width: 70,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(width: 5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  RecordNoController.text,
                                  style: TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                            SizedBox(width: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                InkWell(
                                  onTap: () {
                                    ShowBillnoIncreaeMessage();
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: subcolor,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 6, right: 6, top: 2, bottom: 2),
                                      child: Text(
                                        "+",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  // color: Subcolor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            left: Responsive.isDesktop(context) ? 10 : 10,
                            top: 8),
                        child: Text(
                          "Employee Name",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, bottom: 8.0, top: 6.0, right: 6.0),
                        child: Row(
                          children: [
                            _buildEmployeeNameDropdown(),
                            SizedBox(
                              width: 2,
                            ),
                            Container(
                              color: subcolor,
                              child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 6, right: 6, top: 2, bottom: 2),
                                  child: Icon(
                                    Icons.refresh,
                                    size: 14,
                                    color: Colors.white,
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                // color: Subcolor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          left: Responsive.isDesktop(context) ? 10 : 10,
                          top: 8),
                      child: Text(
                        "Date",
                        style: TextStyle(fontSize: 13),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 15, top: 8),
                      child: Container(
                        width: Responsive.isDesktop(context)
                            ? 180
                            : MediaQuery.of(context).size.width * 0.4,
                        child: Container(
                          height: 25,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: Colors.grey)),
                          child: Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.calendar_month,
                                  color: Colors.grey,
                                ),
                                SizedBox(width: 8),
                                Expanded(
                                  child: DateTimePicker(
                                    onFieldSubmitted: (_) => _fieldFocusChange(
                                        context, DateFocus, ProdNameFocus),
                                    controller: _DateController,
                                    focusNode: DateFocus,
                                    firstDate: DateTime(2000),
                                    lastDate: DateTime(2100),
                                    dateLabelText: '',
                                    onChanged: (val) {
                                      setState(() {
                                        selectedDate = DateTime.parse(val);
                                      });
                                      print(val);
                                    },
                                    validator: (val) {
                                      print(val);
                                      return null;
                                    },
                                    onSaved: (val) {
                                      print(val);
                                    },
                                    style: TextStyle(fontSize: 13),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  // color: Subcolor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            left: Responsive.isDesktop(context) ? 10 : 10,
                            top: 8),
                        child: Text(
                          "Product Name",
                          style: TextStyle(fontSize: 13),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, bottom: 8.0, top: 6.0, right: 6.0),
                        child: Row(
                          children: [
                            _buildProductNameDropdown(),
                            SizedBox(
                              width: 2,
                            ),
                            Container(
                              color: subcolor,
                              child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 6, right: 6, top: 2, bottom: 2),
                                  child: Icon(
                                    Icons.refresh,
                                    size: 14,
                                    color: Colors.white,
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          left: Responsive.isDesktop(context) ? 20 : 15,
                          top: 8),
                      child: Row(
                        children: [
                          _buildQtyText('Qty : '),
                          SizedBox(width: 5),
                          ElevatedButton(
                            onPressed: () {
                              _AddTabledata();
                            },
                            style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                              ),
                              backgroundColor: subcolor,
                              minimumSize:
                                  Size(45.0, 31.0), // Set width and height
                            ),
                            child: Text(
                              'Add',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 33,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 15, left: 25.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      // color: Subcolor,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Stock Value: ',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                stockValueController
                                    .text, // Accessing the controller from the state
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  void ShowBillnoIncreaeMessage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.question_mark_rounded, color: maincolor),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'Do you want increase your addstock billno ?',
                style: TextStyle(fontSize: 12, color: maincolor),
              ),
            ],
          ),
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: () {
                    // incrementAndInsert();
                    Navigator.of(context).pop(true);
                  },
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.0),
                    ),
                    backgroundColor: maincolor,
                    minimumSize: Size(30.0, 20.0), // Set width and height
                  ),
                  child: Text('Yes',
                      style: TextStyle(color: sidebartext, fontSize: 11)),
                ),
                SizedBox(width: 5),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.0),
                    ),
                    backgroundColor: maincolor,
                    minimumSize: Size(30.0, 23.0), // Set width and height
                  ),
                  child: Text('No',
                      style: TextStyle(color: sidebartext, fontSize: 11)),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  void _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }
}
