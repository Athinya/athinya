import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:product_restaurantapp/Database/IpAddress.dart';
import 'package:product_restaurantapp/LoginAndReg/OnboardingScreen.dart';
import 'package:product_restaurantapp/Modules/Style.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:product_restaurantapp/LoginAndReg/RegForm.dart';
import 'package:product_restaurantapp/Modules/Responsive.dart';

class LoginScreen extends StatefulWidget {
  final String email;

  final String password;

  LoginScreen({required this.email, required this.password});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  FocusNode EmailFocusNode = FocusNode();
  FocusNode PasswordFocusNode = FocusNode();
  FocusNode LoginButtonFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _emailController.text = widget.email;
    _passwordController.text = widget.password;
  }

  Future<void> _login() async {
    String apiUrl = '$IpAddress/Settings_Passwordalldatas/';
    String role = '';

    if (_formKey.currentState!.validate()) {
      final email = _emailController.text;
      final password = _passwordController.text;

      try {
        bool hasNextPage = true;
        bool isValidUser = false;

        while (hasNextPage) {
          final response = await http.get(
            Uri.parse(apiUrl),
            headers: <String, String>{
              'Content-Type': 'application/json; charset=UTF-8',
            },
          );

          if (response.statusCode == response.statusCode) {
            final Map<String, dynamic> data = jsonDecode(response.body);
            final List<dynamic> results = data['results'];

            for (var user in results) {
              if (user['email'] == email && user['password'] == password) {
                isValidUser = true;
                String cusid = user['cusid'];
                role = user['role'];

                await saveCusId(cusid);
                await saveEmail(email);
                await saveRole(role);

                break;
              }
            }

            hasNextPage = data['next'] != null;
            if (hasNextPage) {
              apiUrl = data['next'];
            }

            if (isValidUser) {
              break;
            }
          } else {
            print('Failed to connect to the server: ${response.statusCode}');
            _showErrorDialog('Failed to connect to the server');
            return;
          }
        }

        if (isValidUser) {
          print('Login with $role successful');
          await _storeLoginState();
          await logreports("Login Form: Login");
          successfullyLoginMessage(role);
        } else {
          _showErrorDialog('Invalid email or password');
        }
      } catch (e) {
        print('An error occurred: $e');
        _showErrorDialog('An unexpected error occurred');
      }
    }
  }

  Future<void> saveCusId(String cusid) async {
    await SharedPrefs.saveCusId(cusid);
  }

  Future<void> saveEmail(String email) async {
    await SharedPrefs.saveEmail(email);
  }

  Future<void> saveRole(String role) async {
    await SharedPrefs.saveRole(role);
  }

  Future<void> _storeLoginState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', true);
  }

  void successfullyLoginMessage(String role) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.check_circle_rounded, color: Colors.green),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                'Login with $role Successfully !!',
                style: TextStyle(fontSize: 13, color: Colors.black),
              ),
            ],
          ),
        );
      },
    );

    Future.delayed(Duration(seconds: 1), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => OnboardingScreen()),
      );
    });
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          content: Row(
            children: [
              IconButton(
                icon: Icon(Icons.warning, color: Colors.yellow),
                onPressed: () => Navigator.of(context).pop(false),
              ),
              Text(
                message,
                style: TextStyle(fontSize: 13, color: Colors.black),
              ),
            ],
          ),
        );
      },
    );

    Future.delayed(Duration(seconds: 1), () {
      Navigator.of(context).pop();
    });
  }

  void _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/imgs/Login.jpg'),
            fit: BoxFit.cover,
          ),
          color: Colors.white,
        ),
        child: Padding(
          padding: Responsive.isDesktop(context)
              ? EdgeInsets.only(
                  left: 500.0, right: 500.0, top: 80.0, bottom: 50.0)
              : EdgeInsets.all(20),
          child: Center(
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Welcome to Restaurant',
                        style: HeadingStyle,
                      ),
                      const SizedBox(height: 30),
                      TextFormField(
                        controller: _emailController,
                        focusNode: EmailFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, EmailFocusNode, PasswordFocusNode),
                        decoration: InputDecoration(
                          labelText: 'Email',
                          prefixIcon: const Icon(Icons.email),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                          }
                          if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                            return 'Please enter a valid email';
                          }
                          return null;
                        },
                        style: commonLabelTextStyle,
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _passwordController,
                        focusNode: PasswordFocusNode,
                        textInputAction: TextInputAction.next,
                        onFieldSubmitted: (_) => _fieldFocusChange(
                            context, PasswordFocusNode, LoginButtonFocusNode),
                        decoration: InputDecoration(
                          labelText: 'Password',
                          prefixIcon: const Icon(Icons.lock),
                          suffixIcon: InkWell(
                            onTap: () {
                              setState(() {
                                _obscureText = !_obscureText;
                              });
                            },
                            child: Icon(
                              _obscureText
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              color: Colors.black,
                              size: 20,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        obscureText: _obscureText, // Use _obscureText here
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your password';
                          }

                          return null;
                        },
                        style: commonLabelTextStyle,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        focusNode: LoginButtonFocusNode,
                        onPressed: () {
                          _login();
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.redAccent,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 40, vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text('Login', style: commonWhiteStyle),
                      ),
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: () {
                          // Navigate to register screen
                        },
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('Don\'t have an account?',
                                    style: commonLabelTextStyle),
                                InkWell(
                                  onTap: () {
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.2,
                                          child: Dialog(
                                            child: RegistrationDialog(),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: Text(
                                    'Register',
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Color.fromARGB(255, 30, 151, 34),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      '*',
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Row(
                                  children: [
                                    Text('Kindly note the email & password',
                                        style: textStyle),
                                  ],
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
